<?php

require_once 'globals.php';


if($quanxian == 2){   //如果是用户访问就跳出提示
echo "<script>alert('您没有权限访问本页面');location.href='index.php';</script>";
}


$yingyong = isset($_POST['yingyong']) ? addslashes($_POST['yingyong']): '' ;
$type = isset($_POST['type']) ? addslashes($_POST['type']) : 'TK';
$num = isset($_POST['num']) ? intval($_POST['num']) : 1;
$out = isset($_POST['out']) ? intval($_POST['out']) : 0;
$submit = isset($_POST['submit']) ? addslashes($_POST['submit']) : '';
if($submit){
	$str = '';
	for($i=1;$i<=$num;$i++){
		$key=getcode();
		$sql="INSERT INTO `kami`(`kami`, `type`, `yingyong`,`date`) VALUES ('$key','$type','$yingyong','0')";
		$query=$db->query($sql);
		$str .= $key . "\r\n";
	}
	if($out == 1){
		header("Content-Type: application/octet-stream");
		header("Content-Disposition: attachment; filename={$type}_kami.txt");
		echo "==============卡密开始================\r\n\r\n";
		echo $str;
		echo "\r\n\r\n==============卡密结束================";
		exit;
	}else{
		include_once 'header.php';
		echo "<script> alert('生成成功');parent.location.href='adm_kami.php'; </script>";
	}
}else{
	include_once 'header.php';
}

function getcode(){
	$str = null;
	//$strPol = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
	$strPol = "abcdefghjkmnpqrstuvwxyz0123456789";
	$max = strlen($strPol)-1;
	for($i=0;$i<5;$i++){
		$str.=$strPol[rand(0,$max)];
	}
	return $str;
}

?>

<title>卡密生成</title>

			<div class="tpl-content-wrapper">

				<div class="tpl-portlet-components">
					<div class="portlet-title">
						<div class="caption font-green bold">
							<i class="am-icon-credit-card"></i>卡密生成
						</div>
					</div>
					<div class="tpl-block">
						<div class="am-g">
							<div class="tpl-form-body tpl-form-line">
								<form class="am-form tpl-form-line-form am-text-nowrap" action="" method="post" id="addimg" name="addimg">
									<div id="post">
									
										<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="type" id="type_label" class="am-form-label">卡密类型：</label>
											<div class="" style="flex:1;">
												<select name="type" id="type" data-am-selected="{searchBox: 1}" style="display: none;;flex:1">
													<option value="TK">天卡</option>
													<option value="ZK">周卡</option>
													<option value="YK">月卡</option>
													<option value="BNK">半年卡</option>
													<option value="NK">年卡</option>
													<!-- <option value="YJK">永久卡</option> -->
												</select>
											</div>
										</div>
										
										<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="num" id="num_label" class="am-form-label">生成个数：</label>
											<div class="" style="flex:1;">
												<input type="text" class="tpl-form-input" name="num" value="1" placeholder="请输入生成的个数" id="num" maxlength="3" style="width:200px;flex:1">
											</div>
										</div>
										
										<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="yingyong" id="yingyong_label" class="am-form-label">绑定应用：</label>
											<div class="" style="flex:1;">
												<input type="text" class="tpl-form-input" name="yingyong" placeholder="不绑定应用请留空" id="yingyong" maxlength="20" style="width:200px;flex:1">
											</div>
										</div>
										
										<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label class="am-form-label" for="out_label">是否导出：</label>
											<div class="" style="flex:1;">
												<input type="checkbox" name="out" id="out" value="1"></input>
												<label for="out" id="out_label">生成卡密后直接导出</label>
											</div>
										</div>
										<div class="am-form-group" id="post_button">
											<div class="am-u-sm-centered">
												<input type="submit" name="submit" value="生成卡密" class="am-btn am-btn-primary" style="display:block; margin:0 auto;"></input>
											</div>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
<?php
include_once 'footer.php';
?>