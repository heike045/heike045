<?php

require_once '../include/global.php';
require_once 'userdata.php';

$action = isset($_GET['action']) ? addslashes($_GET['action']) : '';

//登录验证
if ($action == 'login') {
	$username = isset($_POST['user']) ? addslashes(trim($_POST['user'])) : '';
	$password = isset($_POST['pw']) ? addslashes(trim($_POST['pw'])) : '';
	
    if($username == '' || $password == ''){
		header('Location:./login.php?err=1');
		exit;
	}
	
	if($username == $user && $password == $pass){
		setcookie('SEVEN_AUTH', $cookie, time() + 88888, '/');
		
		$user_perm_level = 1;
		session_start();
		$_SESSION['user_perm_level'] = $user_perm_level;
		
		
		header('Location:./');
		exit;
	}
	
	elseif($username == $yhu && $password == $yhs){      //多一个用户登录
		setcookie('SEVEN_AUTH', $cookie, time() + 88888, '/');
		
		$user_perm_level = 2;
		session_start();
		$_SESSION['user_perm_level'] = $user_perm_level;
		
		
		header('Location:./');
		exit;
	}
	
	else
	{
		header('Location:./login.php?err=2');
		exit;
	}
}
//退出
if ($action == 'logout') {
	setcookie('SEVEN_AUTH', ' ', time() - 88888, '/');
	header('Location:./login.php');
	exit;
}

$SEVEN_AUTH = isset($_COOKIE['SEVEN_AUTH']) ? addslashes(trim($_COOKIE['SEVEN_AUTH'])) : '';
if($SEVEN_AUTH == $cookie){
	$islogin = true;
}else{
	$islogin = false;
}

if (!$islogin) {
	header('Location:./login.php?err=3');
	exit;
}
