<?php

include '../include/config.php';
	
$connect = new mysqli($host, $mysql_user, $mysql_pwd, $db_name, $db_port);

if ($connect->connect_error) {
   die("连接失败: " . $connect->connect_error);
}
	
	
$sql = "SELECT * FROM denglu ";
$rows=$connect->query($sql)->fetch_array();

if(!empty($rows)){
	$user = $rows['username'];  //管理员账号
	$pass = $rows['password'];  //管理员密码
}


$sql = "SELECT * FROM denglu ";
$rows=$connect->query($sql)->fetch_array();

if(!empty($rows)){
	$yhu = $rows['yonghu'];  //用户账号
	$yhs = $rows['yonghumima'];  //用户密码
}


$cookie = 'be32ad36f2ce69513311c82139bb3a2d2631';


?>

