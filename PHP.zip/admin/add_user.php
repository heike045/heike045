<?php

require_once 'globals.php';
include_once 'header.php';

if($quanxian == 2){   //如果是账号访问就跳出提示
echo "<script>alert('您没有权限访问本页面');location.href='index.php';</script>";
}


$user = isset($_POST['user']) ? addslashes($_POST['user']) : '';
$password = isset($_POST['password']) ? addslashes($_POST['password']) : '';
$dianshu = isset($_POST['dianshu']) ? addslashes($_POST['dianshu']) : '';
$regdate = time();
$vip = strtotime(isset($_POST['vip']) ? addslashes($_POST['vip']) : '');
if($user != '' && $password != '' && $dianshu != '' && $vip != ''){
	$sql="select * from user where user='$user'";
	$query=$db->query($sql);
	$have=$db->fetch_array($query);
	if($have){
		echo "<script>alert('账号名已存在');</script>";
	}else{
		$pass = $password;
		$dshu = $dianshu;
		$sql="INSERT INTO `user`(`user`, `password`, `dianshu`, `regdate`, `lock`,`vip`) VALUES ('$user','$pass','$dianshu','$regdate','n','$vip')";
		$query=$db->query($sql);
		if($query){
			echo "<script> alert('添加成功');parent.location.href='adm_user.php'; </script>";
		}
	}
}
?>
			<div class="tpl-content-wrapper">
				


				<div class="tpl-portlet-components">
					<div class="portlet-title">
						<div class="caption font-green bold">
							<span class="fa fa-user-plus">&nbsp;</span>添加账号
						</div>
					</div>
					
						<div class="am-g">
							<div class="tpl-form-body tpl-form-line">
							
								<form class="am-form tpl-form-line-form am-text-nowrap"  action="" method="post" id="addimg" name="addimg">
									<div id="post">
									
										<div class="am-form-group">
											
											<div class="am-form-group" style="display:flex;justify-content: flex-start;">
												<label for="num" id="num_label" class="am-form-label">账号名称：</label>
												<input style="max-width:200px;flex:1" type="text" class="tpl-form-input" name="user" value="" id="user"></input>
												
											</div>
										</div>
										
										<div class="am-form-group">
											
											<div class="am-form-group" style="display:flex;justify-content: flex-start;">
												<label for="num" id="num_label" class="am-form-label">账号密码：</label>
												<input style="max-width:200px;flex:1" type="text" class="tpl-form-input"  name="password" value="" id="password" ></input>
												
											</div>
										</div>
										
										<div class="am-form-group">
											
											<div class="am-form-group" style="display:flex;justify-content: flex-start;">
												<label for="num" id="num_label" class="am-form-label">验证点数：</label>
												<input style="max-width:200px;flex:1" type="text" class="tpl-form-input"  name="dianshu" value="" id="dianshu" ></input>
												
											</div>
										</div>

										<div class="am-form-group">
											
											<div class="am-form-group" style="display:flex;justify-content: flex-start;">
												<label for="num" id="num_label" class="am-form-label">到期时间：</label>
												<input style="max-width:120px;flex:1" type="text" class="am-form-field tpl-form-no-bg" name="vip" value="" id="vip" data-am-datepicker="" readonly="" placeholder="点击选择到期时间"></input>
												
											</div>
										</div>
				
										<div class="am-form-group" id="post_button">
											
												<input type="submit" name="submit" value="添加账号" class="am-btn am-btn-primary" ></input>
											
										</div>
									</div>
								</form>
								
							</div>
						</div>
					</div>
				</div>
			</div>
			

			
			
			
			
			
			
			
			
			
			
			
<?php
include_once 'footer.php';
?>