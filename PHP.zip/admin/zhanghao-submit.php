<?php

//连接数据库,把文件存到数据库中  
include '../include/zhconfig.php';

if(!$conn) die("error : mysql connect failed");


if($_GET['action'] == 'deleteAll'){
    $sth = $conn->prepare("delete from zhanghao");
    $result= $sth->execute();
	//echo "<script>alert('删除所有数据成功!');location.href='".$_SERVER["HTTP_REFERER"]."';</script>"; 
	echo "<script> alert('删除所有数据成功');parent.location.href='zhanghao-index.php'; </script>";
}

if($_GET['action'] == 'deleysy'){
    $sth = $conn->prepare("delete from zhanghao where status = 1");
    $result= $sth->execute();
	//echo "<script>alert('删除已使用数据成功!');location.href='".$_SERVER["HTTP_REFERER"]."';</script>"; 
	echo "<script> alert('删除已使用数据成功');parent.location.href='zhanghao-index.php'; </script>";
}

if(is_uploaded_file($_FILES['myfile']['tmp_name'])) {
    //有了上传文件了
    $myfile=$_FILES["myfile"];
    //设置超时限制时间,缺省时间为 30秒,设置为0时为不限时
    $time_limit=60;
    set_time_limit($time_limit); //
    //把文件内容读到字符串中
    $fp=fopen($myfile['tmp_name'], "rb");
    if(!$fp) die("file open error");



    //输出文本中所有的行，直到文件结束为止。
    while(! feof($fp))
    {
		$a  = trim(fgets($fp)); //使用trim()函数删除空格
		
		
		// 添加判断，如果行为空白行，则跳过
    if (empty($a)) {
        continue;
    }
		
        $tmpArr = explode('----',$a);
        if(empty($tmpArr[0]) || empty($tmpArr[1])){
            continue;
        }
		$tmpa = $tmpArr[0];
		$tmpb = $tmpArr[1];
        $sth = $conn->prepare("insert into zhanghao 
    (`username`,`password`) 
    values ('$tmpa','$tmpb')");

        $result= $sth->execute();
    }


	echo "<script>alert('上传成功!');location.href='zhanghao-index.php';</script>"; 
}
else {
	echo "<script> alert('你没有上传任何文件');parent.location.href='zhanghao-index.php'; </script>";
}



?>

