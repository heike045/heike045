<?php

include '../include/pzconfig.php';
require_once 'header.php';



if($quanxian == 2){   //如果是用户访问就跳出提示
echo "<script>alert('您没有权限访问本页面');location.href='index.php';</script>";
}


$current_page = empty($_GET['page']) ? 0 : $_GET['page'];
$page         = $current_page;
if ($current_page != 0) {
    $page = $current_page + 4;
}

//编写查询sql语句  键值为：canshu
$sql = "SELECT * FROM `canshu`  order by id desc limit 1";
//执行查询操作、处理结果集
$result = mysqli_query($link, $sql);
if (!$result) {
    exit('查询sql语句执行失败。错误信息：' . mysqli_error($link));  // 获取错误信息
}
$data = mysqli_fetch_array($result, MYSQLI_ASSOC);
if(empty($data)){
    $data['canshu1'] = '';
    $data['canshu2'] = '';
	$data['canshu3'] = '';
	$data['canshu4'] = '';
	$data['canshu5'] = '';
	$data['canshu6'] = '';
	$data['canshu7'] = '';
	$data['canshu8'] = '';
	$data['canshu9'] = '';
	$data['canshu10'] = '';
}
?>

<title>云端参数</title>

			<div class="tpl-content-wrapper">

				<div class="tpl-portlet-components">
					<div class="portlet-title">
						<div class="caption font-green bold">
							<i class="fa fa-mixcloud"></i>   云端参数
						</div>
					</div>
					
				
						<div class="am-g">
							
								<form class="am-form tpl-form-line-form am-text-nowrap" action="canshu-sava.php" method="post" id="addimg" name="addimg">
									<div id="post">
									
																			<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="num" id="num_label" class="am-form-label">参数一 ：</label>
											<div class="" style="flex:1;">
												<input type="text" class="tpl-form-input" name="f" value="<?php echo $data['canshu1'];?>" style="max-width:300px;flex:1">
											</div>
										</div>
										
										<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="num" id="num_label" class="am-form-label">参数二 ：</label>
											<div class="" style="flex:1;">
												<input type="text" class="tpl-form-input" name="g" value="<?php echo $data['canshu2'];?>" style="max-width:300px;flex:1">
											</div>
										</div>
									

									
										<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="num" id="num_label" class="am-form-label">参数三 ：</label>
											<div class="" style="flex:1;">
												<input type="text" class="tpl-form-input" name="h" value="<?php echo $data['canshu3'];?>" style="max-width:300px;flex:1">
											</div>
										</div>
									
									
										<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="num" id="num_label" class="am-form-label">参数四 ：</label>
											<div class="" style="flex:1;">
												<input type="text" class="tpl-form-input" name="i" value="<?php echo $data['canshu4'];?>" style="max-width:300px;flex:1">
											</div>
										</div>
									
										<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="num" id="num_label" class="am-form-label">参数五 ：</label>
											<div class="" style="flex:1;">
												<input type="text" class="tpl-form-input" name="j" value="<?php echo $data['canshu5'];?>" style="max-width:300px;flex:1">
											</div>
										</div>
									
										<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="num" id="num_label" class="am-form-label">参数六 ：</label>
											<div class="" style="flex:1;">
												<input type="text" class="tpl-form-input" name="k" value="<?php echo $data['canshu6'];?>" style="max-width:300px;flex:1">
											</div>
										</div>
									
										<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="num" id="num_label" class="am-form-label">参数七 ：</label>
											<div class="" style="flex:1;">
												<input type="text" class="tpl-form-input" name="l" value="<?php echo $data['canshu7'];?>" style="max-width:300px;flex:1">
											</div>
										</div>
									
										<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="num" id="num_label" class="am-form-label">参数八 ：</label>
											<div class="" style="flex:1;">
												<input type="text" class="tpl-form-input" name="m" value="<?php echo $data['canshu8'];?>" style="max-width:300px;flex:1">
											</div>
										</div>
										
										<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="num" id="num_label" class="am-form-label">参数九 ：</label>
											<div class="" style="flex:1;">
												<input type="text" class="tpl-form-input" name="n" value="<?php echo $data['canshu9'];?>" style="max-width:300px;flex:1">
											</div>
										</div>
										
										<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="num" id="num_label" class="am-form-label">参数十 ：</label>
											<div class="" style="flex:1;">
												<input type="text" class="tpl-form-input" name="o" value="<?php echo $data['canshu10'];?>" style="max-width:300px;flex:1">
											</div>
										</div>
									

										
										<div class="am-form-group" style="display:flex;justify-content: flex-start;" id="post_button">
											<div class="am-u-sm-centered">
												<input type="submit" name="button" id="button" value="提交参数" class="am-btn am-btn-primary" style="display:block; margin:0 auto;"></input>
											</div>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>

<?php
include_once 'footer.php';
?>