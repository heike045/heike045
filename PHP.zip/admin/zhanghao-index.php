<?php

require_once 'globals.php';
include_once 'header.php';


$sql="select * from zhanghao where 1";
$queryc=$db->query($sql);
$nums=$db->num_rows($queryc);
$enums=100000;  //每页显示的条目数 
$page=isset($_GET['page']) ? intval($_GET['page']) : 1;
$url="zhanghao-index.php?page=";
$bnums=($page-1)*$enums;

$id = isset($_POST['id']) ? $_POST['id'] : '';
if($id){
	$ids = '';
	foreach ($id as $value) {
		$ids .= $value.",";
	}
	$ids = rtrim($ids, ",");
	$sql="DELETE FROM `zhanghao` WHERE `id` in ($ids)";
	$query=$db->query($sql);
	if($query){
		echo "<script>alert('删除成功');</script>";
	}
}



//导出数据库指定内容
if (isset($_POST['daochu'])) { 
	echo "<script>window.location.href='zhanghao-daochu.php'; </script>";
}
//导出数据库指定内容

//导出数据库指定内容
if (isset($_POST['daochuwsy'])) { 
	echo "<script>window.location.href='zhanghao-daochu2.php'; </script>";
}
//导出数据库指定内容
?>

<title>账号管理</title>

			<div class="tpl-content-wrapper">
				<div class="tpl-portlet-components">
					<div class="portlet-title">
						<div class="caption font-green bold">
							<i class="fa fa-table"></i>   账号管理
						</div>
					</div>
					<div class="tpl-block">
						<div class="am-g">




<table>

<form enctype='multipart/form-data' name='myform' action='zhanghao-submit.php' method='post'>

        <INPUT TYPE = "hidden" NAME = "MAX_FILE_SIZE" VALUE ="1000000">
<div class="am-u-sm-centered" style="display:flex;justify-content: center;">
		<input name='myfile' type='file' style="display:block;max-width:250px;flex:1;">
		<input name='submit' value='上传'  type='submit' style="display:block;" class="am-btn am-btn-primary">
</div>

</form>

</table>

<p>   





<div class="am-u-sm-centered" style="display:flex;justify-content: center;">
    <form action="zhanghao-submit.php?action=deleteAll" method="post">
        <input style="display:flex;justify-content: center;" type='button' value="删除所有" id="scsy" onclick="delall()" class="am-btn am-btn-primary">
    </form>
	
	<form action="zhanghao-submit.php?action=deleysy" method="post" >
        <input style="margin-left:10px;" type='button' value="删除已使用" id="scysy" onclick="del()" class="am-btn am-btn-primary">
    </form>
</div>



<p>



<div class="am-u-sm-centered" style="display:flex;justify-content: center;">	
	<form action="" method="post" target="_blank">
		<input style="display:flex;justify-content: center;" name="daochu" type='submit' value="导出已使用" class="am-btn am-btn-primary">
	</form>

	<form action="" method="post" target="_blank">
		<input style="margin-left:10px;" name="daochuwsy" type='submit' value="导出未使用" class="am-btn am-btn-primary">
	</form>
</div>




<p>









						<div class="header">
							<div class="am-u-sm-12">
<div class="refresh">   <!--局部刷新这里的内容开始-->
								<form action="" method="post" name="form_log" id="form_log">
									<div class="am-scrollable-horizontal">
										<table width="100%" id="adm_log_list" class="am-table am-table-hover table-main am-text-nowrap">
											<thead>
												<tr>

													<th>账号</th>
													<th>密码</th>
													<th>状态</th>
												</tr>
											</thead>
											<tbody>
												<?php
												$username = isset($_POST['username']) ? addslashes(trim($_POST['username'])) : '';
												if($username != ''){
													$sql="select * from zhanghao where username='$username' order by id desc limit $bnums,$enums";
												}else{
													$sql="select * from zhanghao where 1 order by id desc limit $bnums,$enums";
												}
												$query=$db->query($sql);
												while($rows=$db->fetch_array($query)){
												?>
												<tr>
												
													<td><?php echo $rows['username']; ?></td>
													<td><?php echo $rows['password']; ?></td>
													<!-- <th>   <td><?php echo $rows['status']; ?></td>   </th> -->
													
													<td><?php if($rows['status']=='0'):?><font color=green>未使用
														<?php elseif($rows['status']=='1'):?><font color=Blue>已使用
													    <?php else: ?><font color=red>异常<?php endif; ?></font></td>
												</tr>
												<?php
												}
												?>
											</tbody>
										</table>
									</div>
									
</div>   <!--局部刷新这里的内容结束-->	
									
										

							<?php if($username == ''): ?>
							<div class="page" style="text-align:center;"><?php echo pagination($nums,$enums,$page,$url); ?></div>
							<?php endif; ?>
							
						</div>
					</div>
				</div>
			</div>
			
			
<script>
function checkAll() {
	var code_Values = document.getElementsByTagName("input");
	var all = document.getElementById("all");
	if (code_Values.length) {
		for (i = 0; i < code_Values.length; i++) {
			if (code_Values[i].type == "checkbox") {
				code_Values[i].checked = all.checked;
			}
		}
	} else {
		if (code_Values.type == "checkbox") {
			code_Values.checked = all.checked;
		}
	}
}
function delsubmit(){
	var delform = document.getElementById("form_log");
	delform.submit();
}
</script>
			
<script>
function delall() {
//console.log($("#btndelete").val());
if (!confirm('确认要删除吗？')) {
return false;
}
else {
$("#scsy").prop("type","submit");
}
}
function del() {
//console.log($("#btndelete").val());
if (!confirm('确认要删除吗？')) {
return false;
}
else {
$("#scysy").prop("type","submit");
}
}
</script>	

   <!--局部刷新方法开始-->		
<script src="layer/jquery.min.js"></script>


   <!--局部刷新方法结束-->	
			
			
<?php
include_once 'footer.php';
?>