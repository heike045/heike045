<?php

include '../include/pzconfig.php';


if($quanxian == 2){   //如果是用户访问就跳出提示
echo "<script>alert('您没有权限访问本页面');location.href='index.php';</script>";
}


$current_page = empty($_GET['page']) ? 0 : $_GET['page'];
$page         = $current_page;
if ($current_page != 0) {
    $page = $current_page + 4;
}

//编写查询sql语句  键值为：canshu
$sql = "SELECT * FROM `canshu`  order by id desc limit 1";
//执行查询操作、处理结果集
$result = mysqli_query($link, $sql);
if (!$result) {
    exit('查询sql语句执行失败。错误信息：' . mysqli_error($link));  // 获取错误信息
}
$data = mysqli_fetch_array($result, MYSQLI_ASSOC);
if(empty($data)){
    $data['canshu1'] = '';
    $data['canshu2'] = '';
	$data['canshu3'] = '';
	$data['canshu4'] = '';
	$data['canshu5'] = '';
	$data['canshu6'] = '';
	$data['canshu7'] = '';
	$data['canshu8'] = '';
	$data['canshu9'] = '';
	$data['canshu10'] = '';
}
?>

<!doctype html>     
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		
		<meta name="description" content="index">
		<meta name="keywords" content="index">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="renderer" content="webkit">
		<meta http-equiv="Cache-Control" content="no-siteapp" />
		<link rel="icon" type="image/png" href="assets/img/favicon.ico">
		<link rel="apple-touch-icon-precomposed" href="assets/img/favicon.ico">
		<meta name="apple-mobile-web-app-title" content="Amaze UI" />
		<link rel="stylesheet" href="assets/css/amazeui.min.css" />
		<link rel="stylesheet" href="assets/css/admin.css">
		<link rel="stylesheet" href="assets/css/app.css">
		<link rel="stylesheet" href="assets/css/font-awesome.min.css">
		<script src="assets/js/echarts.min.js"></script>
        <style type="text/css"> 
          i.fa {
            width: 2rem;
            font-size: 2rem;
            text-align: center;
          }
        </style>
	</head>




			<div class="tpl-content-wrapper">

				<div class="tpl-portlet">
					
					
				
						<div class="am-g">
							
								<form class="am-form tpl-form-line-form am-text-nowrap" action="canshu-sava.php" method="post" id="addimg" name="addimg">
									<div id="post">
									
											<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="num" id="num_label" class="am-form-label">直播间ID ：</label>
											<div class="" style="flex:1;">
												<input type="text" class="tpl-form-input" name="f" value="<?php echo $data['canshu1'];?>" style="max-width:150px;flex:1">
											</div>
											
										</div>
										
										<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="num" id="num_label" class="am-form-label">发言间隔 ：</label>
											<div class="" style="flex:1;">
												<input type="text" class="tpl-form-input" name="g" value="<?php echo $data['canshu2'];?>" style="max-width:150px;flex:1">
											</div>
										</div>
									
										<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="num" id="num_label" class="am-form-label">发言轮数 ：</label>
											<div class="" style="flex:1;">
												<input type="text" class="tpl-form-input" name="h" value="<?php echo $data['canshu3'];?>" style="max-width:150px;flex:1">
											</div>
										</div>
									
											<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="num" id="num_label" class="am-form-label">心心点赞 ：</label>
											<div class="" style="flex:1;">
												<input type="text" class="tpl-form-input" name="k" value="<?php echo $data['canshu6'];?>" style="max-width:150px;flex:1">
											</div>
										</div>
									
										<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="num" id="num_label" class="am-form-label">发言参数 ：</label>
											<div class="" style="flex:1;">
												
												<select name="i" data-am-selected="{searchBox: 0}" >
													<option value="<?php echo $data['canshu4'];?>">当前选择：<?php echo $data['canshu4'];?></option>
													<option value="1">1</option>
													<option value="2">2</option>
													<option value="3">3</option>
												</select>
												
											</div>
										</div>
										
									
									
										<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="num" id="num_label" class="am-form-label">是否关注 ：</label>
											<div class="" style="flex:1;">
												
												<select name="j" data-am-selected="{searchBox: 0}" >
													<option value="<?php echo $data['canshu5'];?>">当前选择：<?php echo $data['canshu5'];?></option>
													<option value="是">是</option>
													<option value="否">否</option>
												</select>
												
											</div>
										</div>
									
									
									
									
									
										<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="num" id="num_label" class="am-form-label">是否心心 ：</label>
											<div class="" style="flex:1;">
												
												<select name="l" data-am-selected="{searchBox: 0}" >
													<option value="<?php echo $data['canshu7'];?>">当前选择：<?php echo $data['canshu7'];?></option>
													<option value="是">是</option>
													<option value="否">否</option>
												</select>
												
												
											</div>
										</div>
										
										
									<!--
										<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="num" id="num_label" class="am-form-label">参数八 ：</label>
											<div class="" style="flex:1;">
												<input type="text" class="tpl-form-input" name="m" value="<?php echo $data['canshu8'];?>" style="max-width:300px;flex:1">
											</div>
										</div>
										
										<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="num" id="num_label" class="am-form-label">参数九 ：</label>
											<div class="" style="flex:1;">
												<input type="text" class="tpl-form-input" name="n" value="<?php echo $data['canshu9'];?>" style="max-width:300px;flex:1">
											</div>
										</div>
										
										<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="num" id="num_label" class="am-form-label">参数十 ：</label>
											<div class="" style="flex:1;">
												<input type="text" class="tpl-form-input" name="o" value="<?php echo $data['canshu10'];?>" style="max-width:300px;flex:1">
											</div>
										</div>
									-->

										
										<div class="am-form-group" style="display:flex;justify-content: flex-start;" id="post_button">
											<div class="am-u-sm-centered">
												<input type="submit" name="button" id="button" value="保存参数" class="am-btn am-btn-primary" style="display:block; margin:0 auto;"></input>
											</div>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>

</div>



<?php
include_once 'footer.php';
?>