<?php
require_once 'globals.php';
// 导出数据库指定内容
$sql = "SELECT * FROM `zhanghao` WHERE `status` = '0'";
$result = $db->query($sql);

if ($result->num_rows > 0) {
    // 设置文件名和MIME类型
    $filename = '导出未使用.txt';
    header('Content-type: text/plain');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    // 打开输出流，将结果写入文件
    $fp = fopen('php://output', 'w');
    while($row = $result->fetch_assoc()) {
        // 使用trim()和preg_replace()去除空格和制表符
        $line = preg_replace('/\s+/', ' ', trim($row["username"]. "----" . $row["password"]));
        fwrite($fp, $line . "\n");
    }
    fclose($fp);
    exit; // 获取完了就退出，不再显示原网页内容

} else {
    echo "没有未使用的账号";
}
?>
