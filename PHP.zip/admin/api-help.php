<?php

include '../include/pzconfig.php';
include_once 'header.php';

if($quanxian == 2){   //如果是用户访问就跳出提示
echo "<script>alert('您没有权限访问本页面');location.href='index.php';</script>";
}

//获取外网IP
$file = file_get_contents('http://ip6.me/');
$pos = strpos( $file, '+3' ) + 3;
$ip = substr( $file, $pos, strlen( $file ) );
$pos = strpos( $ip, '</' );
$ip = substr( $ip, 0, $pos );
//获取外网IP


?>

<title>Api接口说明</title>


			<div class="tpl-content-wrapper">
			


				<div class="tpl-portlet-components">
					<div class="portlet-title">
						<div class="caption font-green bold">
							<i class="fa fa-code"></i>   Api接口说明
						</div>
					</div>
					
						<div class="am-g">


设备控制接口说明：
<br>
提交设备状态到云端：http://<?php echo $ip; ?>/admin/api/kz-api/tj-api.php?username=设备名称&fenzu=分组名称&password=消息内容&mingling=命令1&mingling2=命令2&shijian=2022-05-16 12:11:07&status=1
<br>
读取云端指定设备状态：http://<?php echo $ip; ?>/admin/api/kz-api/dq.php?username=设备名称
<br>
读取云端指定分组设备的状态：http://<?php echo $ip; ?>/admin/api/kz-api/dqzdz.php?username=设备名称&fenzu=分组名称
<br>
<br>
设备监控接口说明：
<br>
POST上传base64图片：http://<?php echo $ip; ?>/admin/api/jk-api/post-mini.php?ID=设备名称.txt&username=转Base64后的图片
<br>
<br>
通用配置接口说明：
<br>
读取指定值：http://<?php echo $ip; ?>/admin/api/pz-api/dq.php?zhidingcanshu=gxnr
<br>
<br>
云端参数接口说明：
<br>
读取指定参数：http://<?php echo $ip; ?>/admin/api/cs-api/dq.php?zdcs=参数值----------------（例子参数值：canshu1到canshu10）
<br>
修改指定参数：http://<?php echo $ip; ?>/admin/api/cs-api/xg.php?zdcs=参数值&xgnr=修改的内容
<br>
<br>
数据管理接口说明：
<br>
添加一条新数据：http://<?php echo $ip; ?>/admin/api/sjk-api/tj.php?name=账号&fenzu=组别&dt1=数据1&dt2=数据2&dt3=数据3&dt4=数据4&dt5=数据5&dt6=数据6&dt7=数据7&dt8=数据8&dt9=数据9&dt10=数据10
<br>
读取指定账号数据：http://<?php echo $ip; ?>/admin/api/sjk-api/dq.php?name=账号
<br>
修改指定账号数据：http://<?php echo $ip; ?>/admin/api/sjk-api/xg.php?name=账号&dt1=数据1&dt2=数据2&dt3=数据3&dt4=数据4&dt5=数据5&dt6=数据6&dt7=数据7&dt8=数据8&dt9=数据9&dt10=数据10
<br>
读取指定组别下的账号数据：http://<?php echo $ip; ?>/admin/api/sjk-api/dq-fenzu.php?name=账号&fenzu=组别
<br>
修改指定组别下的账号数据：http://<?php echo $ip; ?>/admin/api/sjk-api/xg-fenzu.php?name=账号&fenzu=组别&dt1=数据1&dt2=数据2&dt3=数据3&dt4=数据4&dt5=数据5&dt6=数据6&dt7=数据7&dt8=数据8&dt9=数据9&dt10=数据10
<br>
<br>
账号管理接口说明：
<br>
读取指定账号的参数：http://<?php echo $ip; ?>/admin/api/zh-api/dq.php?username=账号
<br>
一次读取一个账号密码并标记为已使用：http://<?php echo $ip; ?>/admin/api/zh-api/dq-api.php 
<br>
提交新数据或者修改数据状态：http://<?php echo $ip; ?>/admin/api/zh-api/tj-api.php?username=账号&password=密码&status=0----------------状态0为未使用 1为已使用 2为异常
<br>
一次读取一个指定分组的账号密码并标记为已使用：http://<?php echo $ip; ?>/admin/api/zh-api/fenzu-dq-api.php?fenzu=分组名称
<br>
提交指定分组新数据或者修改数据状态：http://<?php echo $ip; ?>/admin/api/zh-api/fenzu-tj-api.php?fenzu=分组名称&username=账号&password=密码&status=0----------------状态0为未使用 1为已使用 2为异常 
<br>
<br>
图库管理接口说明：
<br>
读取一张云端图片：http://<?php echo $ip; ?>/admin/api/tp-api/dq.php-------返回格式：图片名字----图片下载地址,会读取一张JPG图片,然后改成PNG(标记为已经使用过,不会再读取)
<br>
上传图片到upload目录下：uploadFile("http://<?php echo $ip; ?>/admin/api/tp-api/sc.php?name="..本地SD目录下的图片名,"/sdcard/"..本地SD目录下的图片名)
<br>
<br>
文件管理接口说明：
<br>
上传文件到wenjian目录下：uploadFile("http://<?php echo $ip; ?>/admin/api/wj-api/sc.php?name="..本地SD目录下的文件名,"/sdcard/"..本地SD目录下的文件名)


			
<?php
include_once 'footer.php';
?>