<?php

require_once 'globals.php';
include_once 'header.php';

if($quanxian == 2){   //如果是用户访问就跳出提示
echo "<script>alert('您没有权限访问本页面');location.href='index.php';</script>";
}


$sql="select * from user where 1";
$queryc=$db->query($sql);
$nums=$db->num_rows($queryc);
$enums=3000;  //每页显示的条目数 
$page=isset($_GET['page']) ? intval($_GET['page']) : 1;
$av_url = $_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"]);
 $url="adm_user.php?page=";
$bnums=($page-1)*$enums;

$ids = isset($_POST['ids']) ? $_POST['ids'] : '';
if($ids){
	$idss = '';
	foreach ($ids as $value) {
		$idss .= $value.",";
	}
	$idss = rtrim($idss, ",");
	$sql="DELETE FROM `user` WHERE `uid` in ($idss)";
	$query=$db->query($sql);
	if($query){
		echo "<script>alert('删除成功');</script>";
	}
}
?>

<title>账号验证</title>

			<div class="tpl-content-wrapper">

				<div class="tpl-portlet-components">
					<div class="portlet-title">
						<div class="caption font-green bold">
							<i class="am-icon-user">&nbsp;</i>   账号验证
						</div>
					</div>
					<div class="tpl-block">
						<div class="am-g">

							
								
								<form action="adm_user.php" method="post" name="suer" id="suer">
									<div class="am-u-sm-centered" style="display:flex;justify-content: center;">
									<input type="text" class="am-input-group-label" name="user" placeholder="请输入账号" style="max-width:130px;flex:1;"></input>
									<input class="am-btn am-btn-primary" value="搜索账号" type="submit"></input>
									<input style="margin-left:10px;" type=button value=添加账号 onclick="window.location.href='add_user.php'" class="am-btn am-btn-primary">
									</div>
								</form>	
								
								
							
							<div class="am-u-sm-12">
								<form action="" method="post" name="form_log" id="form_log">
									<div class="am-scrollable-horizontal">
										<table width="100%" id="adm_log_list" class="am-table am-table-hover table-main am-text-nowrap">
											<thead>
												<tr>
													<th class="table-check">
														<input type="checkbox" onclick="checkAll();" class="ids" id="all"></input>
													</th>
													
													
													<th>账号</th>
													<th>密码</th>
													<th>验证点数</th>
													<th>到期时间</th>
													<th>注册时间</th>
													<!-- <th>状态</th>  -->

												</tr>
											</thead>
											<tbody>
												<?php
												$user = isset($_POST['user']) ? addslashes(trim($_POST['user'])) : '';
												if($user != ''){
												$sql="select * from user where user='$user' order by uid desc limit $bnums,$enums";
												}else{
												$sql="select * from user where 1 order by uid desc limit $bnums,$enums";
												}
												$query=$db->query($sql);
												while($rows=$db->fetch_array($query)){
												?>
												<tr>
													<td>
														<input type="checkbox" name="ids[]" value="<?php echo $rows['uid']; ?>" class="ids"></input>
													</td>
													
													
													<td><?php echo $rows['user']; ?></td>
													<td><?php echo $rows['password']; ?></td>
													<td><?php echo $rows['dianshu']; ?></td>
													<td><?php if($rows['vip']=='999999999'){
													echo '永久会员'; 
													}else{
													if($rows['vip']>time()) echo gmdate("Y-m-d H:i:s",$rows['vip']+8*3600);
													}
													?></td>
													
													<td><?php echo gmdate("Y-m-d H:i:s",$rows['regdate']+8*3600); ?></td>
													
													
													<!--  <td><?php if($rows['lock']=='y'):?><font color=red>禁用<?php else: ?><font color=green>正常<?php endif; ?></font></td> -->

												</tr>
												<?php
												}
												?>
											</tbody>
										</table>
									</div>
									<div class="list_footer">
										<small>选中项：</small> <a href="javascript:void(0);" onclick="delsubmit()" class="am-badge am-badge-danger am-round">删除</a>
									</div>
								</form>
							</div>
							<?php if($user == ''): ?>
							<div class="page" style="text-align:center;"><?php echo pagination($nums,$enums,$page,$url); ?></div>
							<?php endif; ?>
							<div style="height:60px;"></div>
						</div>
					</div>
				</div>
			</div>
			<script>
			function checkAll() {
				var code_Values = document.getElementsByTagName("input");
				var all = document.getElementById("all");
				if (code_Values.length) {
					for (i = 0; i < code_Values.length; i++) {
						if (code_Values[i].type == "checkbox") {
							code_Values[i].checked = all.checked;
						}
					}
				} else {
					if (code_Values.type == "checkbox") {
						code_Values.checked = all.checked;
					}
				}
			}
			function delsubmit(){
				var delform = document.getElementById("form_log");
				delform.submit();
			}
			</script>
<?php
include_once 'footer.php';
?>