<?php

require_once 'globals.php';
include_once 'header.php';

$sql="select * from kongzhi where 1";
$queryc=$db->query($sql);
$nums=$db->num_rows($queryc);
$enums=50;  //每页显示的条目数 
$page=isset($_GET['page']) ? intval($_GET['page']) : 1;
$url="kongzhi-index.php?page=";
$bnums=($page-1)*$enums;

$id = isset($_POST['id']) ? $_POST['id'] : '';
$username = isset($_POST['username']) ? addslashes(trim($_POST['username'])) : '';
$fenzu = isset($_POST['fenzu']) ? addslashes(trim($_POST['fenzu'])) : '';

if($id){
	$ids = '';
	
	foreach ($id as $value) {
		$ids .= $value.",";
	}
	
	$ids = rtrim($ids, ",");
	
	if($_POST['uptype']=='del'){
		$sql="DELETE FROM `kongzhi` WHERE `id` in ($ids)";
		echo "<script>alert('已删除');</script>";
	}

	if($_POST['uptype']=='zhixingdaima'){
		$daimanr = $_POST['products'];
		$sql="UPDATE `kongzhi` set ewai='$daimanr' WHERE `id` in ($ids)";
		$query=$db->query($sql);
		$sql="UPDATE `kongzhi` set mingling='执行代码' WHERE `id` in ($ids)";
		echo "<script>alert('已发送批量执行代码指令');</script>";
	}

	if($_POST['uptype']=='zhixing'){
		$xuanze = $_POST['xuanze'];
		$sql="UPDATE `kongzhi` set mingling='$xuanze' WHERE `id` in ($ids)";
		echo "<script>alert('已发送指令：批量$xuanze');</script>";
	}

	if($_POST['uptype']=='zhibojian'){
		$sql="UPDATE `kongzhi` set mingling='执行进直播间' WHERE `id` in ($ids)";
		echo "<script>alert('已发送批量进直播间指令');</script>";
	}
	
	
	if($_POST['uptype']=='star'){
		$sql="UPDATE `kongzhi` set mingling='运行' WHERE `id` in ($ids)";
		echo "<script>alert('已发送批量运行指令');</script>";
	}
	if($_POST['uptype']=='stop'){
		$sql="UPDATE `kongzhi` set mingling='停止' WHERE `id` in ($ids)";
		echo "<script>alert('已发送批量停止指令');</script>";
	}
	if($_POST['uptype']=='zanting'){
		$sql="UPDATE `kongzhi` set mingling='暂停' WHERE `id` in ($ids)";
		echo "<script>alert('已发送批量暂停指令');</script>";
	}
	if($_POST['uptype']=='huifu'){
		$sql="UPDATE `kongzhi` set mingling='恢复' WHERE `id` in ($ids)";
		echo "<script>alert('已发送批量恢复指令');</script>";
	}
	if($_POST['uptype']=='gengxin'){
		$sql="UPDATE `kongzhi` set mingling='更新脚本' WHERE `id` in ($ids)";
		echo "<script>alert('已发送批量更新指令');</script>";
	}
	if($_POST['uptype']=='shanping'){
		$sql="UPDATE `kongzhi` set mingling='闪屏提示' WHERE `id` in ($ids)";
		echo "<script>alert('已发送批量闪屏指令');</script>";
	}
	if($_POST['uptype']=='xiping'){
		$sql="UPDATE `kongzhi` set mingling='执行熄屏' WHERE `id` in ($ids)";
		echo "<script>alert('已发送批量熄屏指令');</script>";
	}
	if($_POST['uptype']=='jiesuo'){
		$sql="UPDATE `kongzhi` set mingling='执行解锁' WHERE `id` in ($ids)";
		echo "<script>alert('已发送批量解锁指令');</script>";
	}
	

	if($_POST['uptype']=='zhixingrenwu'){
		//判断复选框有没有勾选
		if(isset($_POST["dianzan"]) && $_POST["dianzan"]=="yes"){
		$bianliang = $bianliang.'点赞/';
		}
		if(isset($_POST["guanzhu"]) && $_POST["guanzhu"]=="yes"){
		$bianliang = $bianliang.'关注/';
		}
		if(isset($_POST["shoucang"]) && $_POST["shoucang"]=="yes"){
		$bianliang = $bianliang.'收藏/';
		}
		if(isset($_POST["pinglun"]) && $_POST["pinglun"]=="yes"){
		$bianliang = $bianliang.'评论/';
		}
		//判断复选框有没有勾选
		$sql="UPDATE `kongzhi` set ewai='$bianliang' WHERE `id` in ($ids)";
		$query=$db->query($sql);
		$sql="UPDATE `kongzhi` set mingling='执行任务了' WHERE `id` in ($ids)";
		echo "<script>alert('已发送批量执行任务指令');</script>";
	}

$query=$db->query($sql);

}


?>



<!DOCTYPE html>
<html>

<body ondragstart="return false"></body>  <!-- 禁止图片拖拽 -->

<title>设备控制</title>

		<div class="tpl-content-wrapper">
	
		
		
			<div class="tpl-portlet-components">
				<div class="portlet-title">
					<div class="caption font-green bold">
						<i class="fa fa-th-large"></i>   设备控制
					</div>
				</div>
				
					<div class="am-g">
					


						<form action="kongzhi-index.php" method="post" name="skami" id="skami">
							<div class="am-u-sm-centered" style="display:flex;justify-content: center;">
									<input type="text" class="am-input-group-label" name="username" placeholder="输入设备名称" style="max-width:130px;flex:1;"></input>
									<input class="am-btn am-btn-primary" value="搜索设备" type="submit" ></input>
							</div>
						</form>
					
<p>   
					
						<form action="kongzhi-index.php" method="post" name="skami" id="skami">
							<div class="am-u-sm-centered" style="display:flex;justify-content: center;">
									<input type="text" class="am-input-group-label" name="fenzu" placeholder="输入分组名称" style="max-width:130px;flex:1;"></input>
									<input class="am-btn am-btn-primary" value="搜索分组" type="submit" ></input>
							</div>
						</form>
					
<p> 	





<form action="" method="post" name="form_log" id="form_log">	

												
												
<div class="am-u-sm-centered" style="flex-wrap: wrap;display:flex;justify-content:center;">
	<select name="products">
	<option selected=”selected”>请选择上传的代码文件</option>

	<?php
	$dir = dirname(__FILE__)."/upload/wenjian/"; 
	$a = scandir($dir);
	$b = scandir($dir,1);


	foreach ($a as $v) {
		   
			if(pathinfo($v, PATHINFO_EXTENSION) !== 'txt'){
				continue;
			}
			$v = (string)$v;
			if(strpos($v,'.')){  
	?>

	<option value="<?php echo $v;?>"   ><?php echo $v;?></option>

	<?php
	continue;
			}else{
				continue;
			}
	}
	?>


	</select>
	<input type='button'  onclick="delsubmit('zhixingdaima')" value="选中执行代码" class="am-btn am-btn-primary">
</div>

<p> 




	
	<div class="am-u-sm-centered" style="flex-wrap: wrap;display:flex;justify-content:center;">
		
		<input style="margin-top:10px;padding-right:9px;padding-left:9px;border:0px;outline:none;background-color:#24b746;" type='button' onclick="delsubmit('star')" value="选中运行" class="am-btn am-btn-primary">
		<input style="margin-top:10px;margin-left:10px;padding-right:9px;padding-left:9px;border:0px;outline:none;background-color:#dd541c;" type='button'  onclick="delsubmit('stop')" value="选中停止" class="am-btn am-btn-primary">
		<input style="margin-top:10px;margin-left:10px;padding-right:9px;padding-left:9px;border:0px;outline:none;background-color:#f0ad4e;" type='button'  onclick="delsubmit('zanting')" value="选中暂停" class="am-btn am-btn-primary">
		<input style="margin-top:10px;margin-left:10px;padding-right:9px;padding-left:9px;border:0px;outline:none;background-color:#673edc;" type='button'  onclick="delsubmit('huifu')" value="选中恢复" class="am-btn am-btn-primary">
		<input style="margin-top:10px;margin-left:10px;padding-right:9px;padding-left:9px;border:0px;outline:none;background-color:#bb6e43;" type='button'  onclick="delsubmit('gengxin')" value="更新脚本" class="am-btn am-btn-primary">
		<input style="margin-top:10px;margin-left:10px;padding-right:9px;padding-left:9px;" type='button'  onclick="delsubmit('shanping')" value="选中闪屏" class="am-btn am-btn-primary">
		
		<!--
		<select name="xuanze" data-am-selected="{searchBox:0}" >
			<option value="">点击选择</option>
			<option value="运行">运行</option>
			<option value="停止">停止</option>
			<option value="暂停">暂停</option>
			<option value="恢复">恢复</option>
			<option value="执行熄屏">执行熄屏</option>
			<option value="执行解锁">执行解锁</option>
			<option value="闪屏提示">闪屏提示</option>
			<option value="更新脚本">更新脚本</option>
			<input type='button'  onclick="delsubmit('zhixing')" value="选中执行操作" class="am-btn am-btn-primary">
		</select>
		-->
		
	</div>
<p>  

	<!--
	<div class="am-u-sm-centered" style="flex-wrap: wrap;display:flex;justify-content:center;">
	<!--
	<label>
	<input type="checkbox" name="guanzhu" value="yes"/>关注&nbsp;
	</label>
	<label>
	<input type="checkbox" name="dianzan" value="yes"/>点赞&nbsp;
	</label>
	<label>
	<input type="checkbox" name="shoucang" value="yes"/>收藏&nbsp;
	</label>
	<label>
	<input type="checkbox" name="pinglun" value="yes"/>评论&nbsp;
	</label>
	<input style="margin-left:10px;padding-right:9px;padding-left:9px;background-color:#0067e6;border:0px;" type='button'  onclick="delsubmit('zhixingrenwu')" value="选中执行任务" class="am-btn am-btn-primary">
	-->

	<!--
	<input style="margin-left:10px;padding-right:9px;padding-left:9px;background-color:#f4241c;border:0px;" type="button"  onclick="canshushezhi()" value="参数设置" class="am-btn am-btn-primary"/>
	<input style="margin-left:10px;padding-right:9px;padding-left:9px;background-color:#0067e6;border:0px;" type='button'  onclick="delsubmit('zhibojian')" value="选中进直播间" class="am-btn am-btn-primary">
	<input style="margin-left:10px;padding-right:9px;padding-left:9px;background-color:#d3211c;border:0px;" type='button'  onclick="delsubmit('fayan')" value="选中发言" class="am-btn am-btn-primary">
	<input style="margin-left:10px;padding-right:9px;padding-left:9px;background-color:#dd541c;border:0px;" type='button'  onclick="delsubmit('shezhi')" value="选中开关设置" class="am-btn am-btn-primary">
	
	</div>
	
<p>  
	-->
	
	<div class="am-u-sm-centered" >
		<input type='hidden' name='uptype' value='' id="uptype">&nbsp; <a onclick="delsubmit('del')" class="am-badge am-badge-danger am-round">选中删除</a>
		<input type='hidden'>&nbsp; <a class="am-badge am-round" href=''>刷新页面</a>
	</div>


			<div class="header">
						<div class="am-u-sm-12">
								<div class="am-scrollable-horizontal" style="display:flex">
								

<table id="adm_log_list" class="am-table am-table-hover am-text-nowrap" style="padding:0;width:10px!important">
	
	<thead>
		<tr>
			<th class="table-check">
				<input type="checkbox" onclick="checkAll();" class="ids" id="all"></input>
			</th>
		</tr>
	</thead>
	
	<tbody>

		<?php
		$username = isset($_POST['username']) ? addslashes(trim($_POST['username'])) : '';
		$fenzu = isset($_POST['fenzu']) ? addslashes(trim($_POST['fenzu'])) : '';
		
		if($username != ''){
			$sql="select * from kongzhi where username='$username' order by id desc limit $bnums,$enums";
		}else{
			$sql="select * from kongzhi where 1 order by id desc limit $bnums,$enums";
		}
		if($fenzu != ''){
			$sql="select * from kongzhi where fenzu='$fenzu' order by id desc limit $bnums,$enums";
		}
		
		$query=$db->query($sql);
		while($rows=$db->fetch_array($query)){
		?>

		<tr>
			
			<td>
				<input type="checkbox" name="id[]" value="<?php echo $rows['id']; ?>" class="idss"></input>
			</td>

		</tr>
		
		<?php
		}
		?>

	</tbody>
	
</table>



<div class="refresh" style="width:100%">  <!--局部刷新这里的内容开始-->
		<div class="header">
		<table width="100%" id="adm_log_list" class="am-table am-table-hover am-text-nowrap"  style="padding:0">
			<thead>
				<tr>
					<th>分组</th>
					<th>设备名称</th>
					<th>连接状态</th>
					<th>运行日志</th>
					<th>更新时间</th>
					<th class="table-check">脚本控制</th>
				</tr>
			</thead>
			

			<tbody>
			
				<?php
				$username = isset($_POST['username']) ? addslashes(trim($_POST['username'])) : '';
				$fenzu = isset($_POST['fenzu']) ? addslashes(trim($_POST['fenzu'])) : '';
				
				if($username != ''){
					$sql="select * from kongzhi where username='$username' order by id desc limit $bnums,$enums";
				}else{
					$sql="select * from kongzhi where 1 order by id desc limit $bnums,$enums";
				}
				if($fenzu != ''){
					$sql="select * from kongzhi where fenzu='$fenzu' order by id desc limit $bnums,$enums";
				}
				
				$query=$db->query($sql);
				while($rows=$db->fetch_array($query)){
				?>

				<tr>
					<td><?php echo $rows['fenzu']; ?></td>
					<td><?php echo $rows['username']; ?></td>
					
					
					<td>
					<?php 
					$time = time();
					$rowtime = strtotime($rows['shijian']);
					if($time-$rowtime>300):     //如果超过300秒没有更新  页面就判定为未连接
					?>
					<font color=red>未连接</font>
					
					<?php 
					elseif($rows['status']=='0'):
					?>
					<font color=Blue>已断开</font>  
					
					<?php 
					elseif($rows['status']=='1'):
					?>
					<font color=green>已连接</font>  
					
					<?php endif; ?>
					</td>
					
					<td><?php echo $rows['password']; ?></td>
					<td><?php echo $rows['shijian']; ?></td>
					

<td>
<input style="border:0px;outline:none;background-color:#24b746" class="am-btn-secondary am-round am-btn am-btn-xs" type="button" value="运行" onclick="yunxing(<?php echo $rows['id']; ?>,'<?php echo $rows['username']; ?>')" />
<input style="border:0px;outline:none;background-color:#dd541c" class="am-btn-secondary am-round am-btn am-btn-xs" type="button" value="停止" onclick="tingzhi(<?php echo $rows['id']; ?>,'<?php echo $rows['username']; ?>')" />
<input style="border:0px;outline:none;background-color:#f0ad4e" class="am-btn-secondary am-round am-btn am-btn-xs" type="button" value="暂停" onclick="zanting(<?php echo $rows['id']; ?>,'<?php echo $rows['username']; ?>')" />
<input style="border:0px;outline:none;background-color:#1688e9" class="am-btn-secondary am-round am-btn am-btn-xs" type="button" value="恢复" onclick="huifu(<?php echo $rows['id']; ?>,'<?php echo $rows['username']; ?>')" />
&nbsp;
&nbsp;
<input class="am-btn-secondary am-round am-btn am-btn-xs" type="button" value="远程控制" onclick="tanchu(<?php echo $rows['id']; ?>,'<?php echo $rows['username']; ?>','<?php echo $rows['fenzu']; ?>')" />		
</td>						
				</tr>
											
		<?php
		}
		?>
											
			</tbody>
										
		</table>
</div>

								

						<?php if($username == ''): ?>
						<div class="page" style="text-align:center;"><?php echo pagination($nums,$enums,$page,$url); ?></div>
						<?php endif; ?>
						
					</div>
				</div>
</div>
				

				
				
			</div>
		</div>
</form>




<link href="assets/css/index.css" rel="stylesheet" type="text/css">
<div data-am-widget="gotop" class="am-gotop am-gotop-fixed">
<div class="OnlineService_Box">
	<div class="OnlineService_Top"><a href="#">返回顶部</a></div>
</div>
</div>				




</body>
</html>





<script src="layer/jquery.min.js"></script>
<script src="layer/layer.js"></script>


<script>
		function checkAll() {
			var code_Values = document.getElementsByClassName("idss");
			var all = document.getElementById("all");
			if (code_Values.length) {
				for (i = 0; i < code_Values.length; i++) {
					if (code_Values[i].type == "checkbox") {
						code_Values[i].checked = all.checked;
					}
				}
			} else {
				if (code_Values.type == "checkbox") {
					code_Values.checked = all.checked;
				}
			}
		}
		function delsubmit(type){
			$("#uptype").val(type);
			var delform = document.getElementById("form_log");
			delform.submit();
		}
</script>


<script type="text/javascript">

<!--局部刷新方法开始-->		
//$(function(){
//	setInterval(function () { $(".refresh").load(location.href + " .refresh"); }, 5000);       <!--5000毫秒刷新一次-->	
//})



<!--弹出层方法开始-->	
function tanchu(id,name,fenzu){

//点击控制后先运行一下这个开启监控
var httpRequest = new XMLHttpRequest();//第一步：建立所需的对象
httpRequest.open('GET', "kongzhi-kongzhi.php?id=" + $(id)[0] + "&username=" + $(name).selector + "&mingling=开启监控", true);//第二步：打开连接  将请求参数写在url中  ps:"./Ptest.php?name=test&nameone=testone"
httpRequest.send();//第三步：发送请求  将请求参数写在URL中
//点击控制后先运行一下这个开启监控

console.log($(id)[0])    //打印ID
console.log($(name).selector)   //打印设备名称
console.log($(fenzu).selector)   //打印分组


	layer.open({
	type: 1,
	title: $(name).selector + "----" + $(fenzu).selector ,  //窗口标题
	shadeClose: true,
	shade: false,
	skin: 'demo-class',
	closeBtn: 1,  //隐藏关闭按钮
	anim: 0, //弹出动画
	scrollbar: false, //关闭窗口滚动条
	resize: false,  //设置窗口为不能拉伸
	maxmin: true, //开启最大化最小化按钮
	offset: 't',   //弹出层在顶部
	btnAlign: 'c',  //按钮居中
	id: $(name).selector + "----" + $(fenzu).selector ,   //定义同样ID的窗口只能打开一个

	//显示图片
	content: '<div id="img' + $(name).selector + "----" + $(fenzu).selector +'" > <img id="change' + $(name).selector + "----" + $(fenzu).selector +'" src="api/jk-api/upload/' + $(name).selector + "----" + $(fenzu).selector + '.jpg?rand= ' + new Date + '" /> </div>' ,

	//显示按钮
	btn: ['退出', '输入', '≡', '⌂', '<'], //可以无限个按钮

	yes: function (index) {
	console.log("退出控制")

	var httpRequest = new XMLHttpRequest();//第一步：建立所需的对象
	httpRequest.open('GET', "kongzhi-kongzhi.php?id=" + $(id)[0] + "&username=" + $(name).selector + "&mingling=停止监控", true);//第二步：打开连接  将请求参数写在url中  ps:"./Ptest.php?name=test&nameone=testone"
	httpRequest.send();//第三步：发送请求  将请求参数写在URL中

	layer.close(index);  //点击执行后退出当前界面
	},

	//右上角关闭按钮触发的回调
	cancel: function(index){ 
	console.log("关闭窗口")

	var httpRequest = new XMLHttpRequest();//第一步：建立所需的对象
	httpRequest.open('GET', "kongzhi-kongzhi.php?id=" + $(id)[0] + "&username=" + $(name).selector + "&mingling=停止监控", true);//第二步：打开连接  将请求参数写在url中  ps:"./Ptest.php?name=test&nameone=testone"
	httpRequest.send();//第三步：发送请求  将请求参数写在URL中

	layer.close(index)  //点击执行后退出当前界面
	},

	btn2: function (index) {
	console.log("开始输入")

	layer.prompt({
	formType: 2,
	value: '',
	title: '请输入要传输到手机的内容',
	area: ['400px', '100px'] //自定义文本域宽高
	}, function(value, index, elem){
	//alert(value); //得到value

	var httpRequest = new XMLHttpRequest();     //第一步：建立所需的对象
	httpRequest.open('GET', "kongzhi-kongzhi.php?id=" + $(id)[0] + "&username=" + $(name).selector + "&mingling=输入内容" + "&str=" + value, true);
	httpRequest.send();    //第三步：发送请求  将请求参数写在URL中

	layer.close(index); //执行后退出当前窗口
	});

	return false //开启该代码可禁止点击该按钮关闭
	},

	btn3: function (index) {
	console.log("菜单")

	var httpRequest = new XMLHttpRequest();//第一步：建立所需的对象
	httpRequest.open('GET', "kongzhi-kongzhi.php?id=" + $(id)[0] + "&username=" + $(name).selector + "&mingling=点击菜单按键", true);//第二步：打开连接  将请求参数写在url中  ps:"./Ptest.php?name=test&nameone=testone"
	httpRequest.send();//第三步：发送请求  将请求参数写在URL中

	return false //开启该代码可禁止点击该按钮关闭
	},

	btn4: function (index) {
	console.log("桌面")

	var httpRequest = new XMLHttpRequest();//第一步：建立所需的对象
	httpRequest.open('GET', "kongzhi-kongzhi.php?id=" + $(id)[0] + "&username=" + $(name).selector + "&mingling=点击桌面按键", true);//第二步：打开连接  将请求参数写在url中  ps:"./Ptest.php?name=test&nameone=testone"
	httpRequest.send();//第三步：发送请求  将请求参数写在URL中

	return false //开启该代码可禁止点击该按钮关闭
	},

	btn5: function (index) {
	console.log("后退")

	var httpRequest = new XMLHttpRequest();//第一步：建立所需的对象
	httpRequest.open('GET', "kongzhi-kongzhi.php?id=" + $(id)[0] + "&username=" + $(name).selector + "&mingling=点击后退按键", true);//第二步：打开连接  将请求参数写在url中  ps:"./Ptest.php?name=test&nameone=testone"
	httpRequest.send();//第三步：发送请求  将请求参数写在URL中

	return false //开启该代码可禁止点击该按钮关闭
	}

	});


	//循环获取新图片更新src
	setInterval(function(){
	var change = document.getElementById("change" + $(name).selector + "----" + $(fenzu).selector)
	if(!!change){
	console.log('执行中')
	change.setAttribute("src","api/jk-api/upload/" + $(name).selector + "----" + $(fenzu).selector + ".jpg?rand=" + new Date() );
	}else{

	}
	},10);

	//获取鼠标位置
	var x1,y1,x2,y2

	object =$("#img"+ $(name).selector + "----" + $(fenzu).selector).get(0);
	console.log(object)
	object.onmousedown=function(xx){
	console.log('鼠标点击')
	x1 = xx.offsetX
	y1 = xx.offsetY

	}
	object.onmouseup=function(xx){
		console.log('鼠标松开')
		x2 = xx.offsetX
		y2 = xx.offsetY

		let x1y1x2y2 = x1+','+y1+','+x2+','+y2

		console.log(x1y1x2y2)

		//window.open ("kongzhi-kongzhi.php?id=" + $(id)[0] + "&username=" + $(name).selector + "&mingling=执行点击命令" + "&str=" + x1y1x2y2 ,'newwindow','height=1,width=1,outerHeight=0,outerWidth=0,top=0,left=0,toolbar=no,menubar=no,scrollbars=no,z-look=no,alwaysLowered=yes,resizable=no,location=no, status=no');
		var httpRequest = new XMLHttpRequest();//第一步：建立所需的对象
		httpRequest.open('GET', "kongzhi-kongzhi.php?id=" + $(id)[0] + "&username=" + $(name).selector + "&mingling=执行点击命令" + "&str=" + x1y1x2y2, true);//第二步：打开连接  将请求参数写在url中  ps:"./Ptest.php?name=test&nameone=testone"
		httpRequest.send();//第三步：发送请求  将请求参数写在URL中
	}
	
}


function yunxing(id,name){
var httpRequest = new XMLHttpRequest();//第一步：建立所需的对象
httpRequest.open('GET', "kongzhi-kongzhi.php?id=" + $(id)[0] + "&username=" + $(name).selector + "&mingling=运行", true);//第二步：打开连接  将请求参数写在url中  ps:"./Ptest.php?name=test&nameone=testone"
httpRequest.send();//第三步：发送请求  将请求参数写在URL中

layer.msg('已发送启动指令');
}

function tingzhi(id,name){
var httpRequest = new XMLHttpRequest();//第一步：建立所需的对象
httpRequest.open('GET', "kongzhi-kongzhi.php?id=" + $(id)[0] + "&username=" + $(name).selector + "&mingling=停止", true);//第二步：打开连接  将请求参数写在url中  ps:"./Ptest.php?name=test&nameone=testone"
httpRequest.send();//第三步：发送请求  将请求参数写在URL中

layer.msg('已发送停止指令');
}

function zanting(id,name){
var httpRequest = new XMLHttpRequest();//第一步：建立所需的对象
httpRequest.open('GET', "kongzhi-kongzhi.php?id=" + $(id)[0] + "&username=" + $(name).selector + "&mingling=暂停", true);//第二步：打开连接  将请求参数写在url中  ps:"./Ptest.php?name=test&nameone=testone"
httpRequest.send();//第三步：发送请求  将请求参数写在URL中

layer.msg('已发送暂停指令');
}

function huifu(id,name){
var httpRequest = new XMLHttpRequest();//第一步：建立所需的对象
httpRequest.open('GET', "kongzhi-kongzhi.php?id=" + $(id)[0] + "&username=" + $(name).selector + "&mingling=恢复", true);//第二步：打开连接  将请求参数写在url中  ps:"./Ptest.php?name=test&nameone=testone"
httpRequest.send();//第三步：发送请求  将请求参数写在URL中

layer.msg('已发送恢复指令');
}

function canshushezhi(id,name){
	layer.open({
	  type: 2,
	  title: '参数设置',
	  area: ['400px', '590px'],
	  resize:false,
	  scrollbar: false,
	  content: 'tanchu-canshu.php' ,
	  btn: ['退出设置'] ,
	  btnAlign: 'c'
	});     

}
</script>	



<?php
include_once 'footer.php';
?>