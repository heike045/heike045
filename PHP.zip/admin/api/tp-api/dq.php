<?php

	$suiji = mt_rand(0.1,0.5);
	sleep($suiji);

//获取外网IP
$file = file_get_contents('http://ip6.me/');
$pos = strpos( $file, '+3' ) + 3;
$ip = substr( $file, $pos, strlen( $file ) );
$pos = strpos( $ip, '</' );
$ip = substr( $ip, 0, $pos );
//获取外网IP



$dir = "../../upload/";

foreach (glob('../../upload/*.jpg') as $txt){

$dqmz = basename($txt);   //读取文件名字

$array=array('.jpg'=>'');   //替换.jpg成空白1

$qchz=strtr($dqmz,$array); //替换.jpg成空白2

echo $qchz."----http://$ip/admin/upload/".$qchz.".png";

$file = $dir.$dqmz;	

if(file_exists($file)){
	if(rename($file,$dir.$qchz.'.png')){
		//echo $file.' 重命名成功！';
	}else{
		//echo $file.' 重命名失败！';
	}
	}else{
	//echo '不存在！';
}


break;   //退出foreach循环

}



?>