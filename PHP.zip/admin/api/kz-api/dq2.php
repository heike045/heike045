<?php

// 连接数据库
include '../../../include/config.php';
$conn = mysqli_connect($host,$mysql_user,$mysql_pwd,$db_name);
$username = $_GET["username"]; //用户名
$fenzu = $_GET["fenzu"]; //用户名

// 查询数据库
$sql = "select * from kongzhi where username='{$username}' and fenzu='{$fenzu}' ";
$result = mysqli_query($conn, $sql);

// 读取一条记录
$row = mysqli_fetch_assoc($result);

if(empty($row)){
	 echo "无此设备";
}else{
	// 显示记录
	echo "{$row['mingling2']}";    //获取username后返回usernamedi底下的password值内容
}

// 关闭数据库连接
mysqli_close($conn);

?>