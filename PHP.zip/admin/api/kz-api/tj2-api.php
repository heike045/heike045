<?php

	include '../../../include/config.php';

    $username = $_GET["username"]; //用户名
    $password = $_GET["password"]; //日志
    $shijian  = date("Y-m-d H:i:s"); //获取服务器本地时间
    $mingling = $_GET["mingling"]; //命令
    $status   = $_GET["status"] ?? 0; //状态
    $mingling2 = $_GET["mingling2"]; //命令2
	$fenzu     = $_GET["fenzu"]; //分组
	
    //连接数据库
    $connect = mysqli_connect($host, $mysql_user, $mysql_pwd, $db_name, $db_port);
	
    if (mysqli_connect_errno()) {
        die("连接失败: " . mysqli_connect_error());
    }
	
	$sql = "select * from kongzhi where username='{$username}' and fenzu='{$fenzu}' ";

    $res = mysqli_fetch_row(mysqli_query($connect, $sql));
    if (empty($res)) {
        //数据库没有该值，插入数据库
        $upsql = "insert into kongzhi (username,password,shijian,mingling,status,mingling2,fenzu) values ('{$username}','{$password}','{$shijian}',{$status},'{$fenzu}')"; 
    } else {
        //如来有数据，更新status的值
		$upsql = "update kongzhi set password='{$password}' , shijian='{$shijian}' , status='{$status}' where username='{$username}' and fenzu='{$fenzu}'";
    }
	

	
	
    $update_res = mysqli_query($connect, $upsql);

	mysqli_close($connect);

	echo "提交成功";

?>
