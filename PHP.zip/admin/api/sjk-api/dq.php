<?php

// 连接数据库
include '../../../include/config.php';
$conn = mysqli_connect($host, $mysql_user, $mysql_pwd, $db_name);

if ($conn === false) {
  die ("连接数据库失败");
}



$name = $_GET["name"]; // 数据名

// 校验输入参数
if (empty($name)) {
    echo "请输入用数据名";
    exit;
}

// 使用mysqli预处理语句可以有效防止SQL注入
$sql = "SELECT * FROM student WHERE name=?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "s", $name);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

// 判断结果集是否为空
$row = mysqli_fetch_assoc($result);
if (empty($row)){
	 echo "无此数据";
} else {
    // 显示记录，注意语法（rd to row）
	echo "{$row['dt1']}----{$row['dt2']}----{$row['dt3']}----{$row['dt4']}----{$row['dt5']}----{$row['dt6']}----{$row['dt7']}----{$row['dt8']}----{$row['dt9']}----{$row['dt10']}";
}

// 关闭数据库连接
mysqli_stmt_close($stmt);
mysqli_close($conn);

?>
