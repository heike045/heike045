<?php
    /*
     * 数据库配置
     */
	include '../../../include/config.php';
	
    $name = $_GET["name"]; 
	$fenzu = $_GET["fenzu"]; 
    $dt1 = $_GET["dt1"]; 
    $dt2 = $_GET["dt2"];
	$dt3 = $_GET["dt3"];
	$dt4 = $_GET["dt4"];
	$dt5 = $_GET["dt5"];
	$dt6 = $_GET["dt6"];
	$dt7 = $_GET["dt7"];
	$dt8 = $_GET["dt8"];
	$dt9 = $_GET["dt9"];
	$dt10 = $_GET["dt10"];

    //连接数据库
    $connect = mysqli_connect($host, $mysql_user, $mysql_pwd, $db_name, $db_port);
    if (!$connect) {
        die("连接数据库失败: " . mysqli_connect_error());
    }

	$sql = "select * from student where name='{$name}' and fenzu='{$fenzu}' ";
    $res = mysqli_query($connect, $sql)->fetch_row();
    if (empty($res)) {
        //数据库没有该值，插入数据库
        $upsql = "insert into student (name,fenzu,dt1,dt2,dt3,dt4,dt5,dt6,dt7,dt8,dt9,dt10) values ('{$name}','{$fenzu}','{$dt1}','{$dt2}','{$dt3}','{$dt4}','{$dt5}','{$dt6}','{$dt7}','{$dt8}','{$dt9}','{$dt10}')"; 
		echo "提交完成";
    } else {
    // 数据库已经存在该值，给出已有数据的提示
    echo "已经存在该名称的数据，请勿重复提交";
	exit();
}
    $update_res = mysqli_query($connect, $upsql);

	mysqli_close($connect);
?>
