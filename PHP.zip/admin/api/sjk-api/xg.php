<?php

	include "../../../include/config.php";
	
    $name = $_GET["name"]; 
    $dt1 = $_GET["dt1"]; 
    $dt2 = $_GET["dt2"];
	$dt3 = $_GET["dt3"];
	$dt4 = $_GET["dt4"];
	$dt5 = $_GET["dt5"];
	$dt6 = $_GET["dt6"];
	$dt7 = $_GET["dt7"];
	$dt8 = $_GET["dt8"];
	$dt9 = $_GET["dt9"];
	$dt10 = $_GET["dt10"];

    //连接数据库
    $connect = mysqli_connect($host, $mysql_user, $mysql_pwd, $db_name, $db_port);
    if (!$connect) {
        die("连接数据库失败: " . mysqli_connect_error());
    }
	
    $sql = "select * from student where name='{$name}'";
    $res = mysqli_query($connect, $sql)->fetch_row();
    if (empty($res)) {
    } else {
        //如来有数据，更新dt2的值
		$upsql = "update student set dt1='{$dt1}', dt2='{$dt2}', dt3='{$dt3}', dt4='{$dt4}', dt5='{$dt5}', dt6='{$dt6}', dt7='{$dt7}', dt8='{$dt8}', dt9='{$dt9}', dt10='{$dt10}' where name='{$name}'";
		echo "修改成功";
	}
    $update_res = mysqli_query($connect, $upsql);

	mysqli_close($connect);
?>
