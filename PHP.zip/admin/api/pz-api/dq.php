<?php

include '../../../include/config.php';
$conn = mysqli_connect($host,$mysql_user,$mysql_pwd,$db_name);

if ($conn === false) {
  die("连接数据库失败: " . mysqli_connect_error());
}


$zhidingcanshu = $_GET["zhidingcanshu"];

$sql = "SELECT * FROM peizhi ";
$result = mysqli_query($conn, $sql);

if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    echo "{$row[$zhidingcanshu]}";
    $strSql = "update peizhi set id = {$row['id']}";
    mysqli_query($conn, $strSql);
} else {
     echo "云端暂无可用配置";
}

mysqli_close($conn);


?>
