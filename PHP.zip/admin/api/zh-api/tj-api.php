<?php
    /*
     * 数据库配置
     */
	include '../../../include/config.php';
	
    $username = $_GET["username"]; //用户名
    $password = $_GET["password"]; //密码
    $status   = $_GET["status"] ?? 0; //状态

	$username = str_replace("!!!!","%2B",$username);
	$username = str_replace("????","%2F",$username);

    //连接数据库
    $connect = mysqli_connect($host, $mysql_user, $mysql_pwd, $db_name, $db_port);
    if (mysqli_connect_errno()) {
        die("连接数据库失败: " . mysqli_connect_error());
    }
	$sql = "select * from zhanghao where username='{$username}'";
    
    $res = mysqli_query($connect, $sql)->fetch_row();
    if (empty($res)) {
        //数据库没有该值，插入数据库
        $upsql = "insert into zhanghao (username,password,status) values ('{$username}','{$password}',{$status})"; 
		echo "提交完成";
    } else {
        //如来有数据，更新status的值
		$upsql = "update zhanghao set password='{$password}', status={$status} where username='{$username}'";
		echo "修改完成";
    }
    $update_res = mysqli_query($connect, $upsql);

	mysqli_close($connect);

	
?>
