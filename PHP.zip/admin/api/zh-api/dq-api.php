<?php

// 连接数据库
include '../../../include/config.php';
$conn = mysqli_connect($host,$mysql_user,$mysql_pwd,$db_name);

// 锁表
$sql = "lock table zhanghao write";  
$result = mysqli_query($conn, $sql);

// 查询数据库
$sql = "SELECT * FROM zhanghao WHERE status = 0";
$result = mysqli_query($conn, $sql);

// 读取一条记录
$row = mysqli_fetch_assoc($result);

if(empty($row)){
	 echo "已无可用账号密码";
}else{
	// 显示记录
	echo "{$row['username']}----{$row['password']}";

	// 修改记录status值
	$sql = "update zhanghao set status = 1 where id = {$row['id']}";
	$result = mysqli_query($conn, $sql);

	// 解锁表
	$sql = "UNLOCK table";
	$result = mysqli_query($conn, $sql);
}

// 关闭数据库连接
mysqli_close($conn);

?>