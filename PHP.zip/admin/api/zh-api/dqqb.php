<?php

// 连接数据库
include '../../../include/config.php';
$conn = mysqli_connect($host,$mysql_user,$mysql_pwd,$db_name);

$status = $_GET["status"]; 

// 锁表
$sql = "lock table zhanghao write";  
$result = mysqli_query($conn, $sql);

// 查询数据库
$sql = "SELECT * FROM zhanghao WHERE status = $status";
$result = mysqli_query($conn, $sql);


//检查查询是否成功
if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}

//输出查询结果
while ($row = mysqli_fetch_assoc($result)) {
    echo "账号: " . $row["username"] . "----密码: " . $row["password"] . "<br>";
}


// 解锁表
	$sql = "UNLOCK table";
	$result = mysqli_query($conn, $sql);


// 关闭数据库连接
mysqli_close($conn);

?>