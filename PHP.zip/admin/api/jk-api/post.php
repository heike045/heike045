﻿<?php
//从POST中获取参数

$ID = $_POST["ID"];

$username = str_replace("%20", "+",$_POST['username']);


$hint = file_put_contents("upload/".$ID, $username);  //接受base64并且保存成txt

$base64_code = file_get_contents("upload/".$ID);   //把内容读取到字符串

$thkg=array(' '=>'+');   //把空格转换成+号1

$base64_code=strtr($base64_code,$thkg);    //把空格转换成+号2


$base64_name = basename("upload/".$ID);   //读取txt名字

$array=array('.txt'=>'');   //替换.txt成空白1

$base64_name=strtr($base64_name,$array); //替换.txt成空白2


$hint2 = file_put_contents("upload/".$base64_name.".jpg".$imageSrc, base64_decode($base64_code));   //base64转图片并保存

unlink("upload/".$ID);  //删除文件




