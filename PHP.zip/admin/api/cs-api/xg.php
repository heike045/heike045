<?php
	include '../../../include/config.php';

	$zdcs = $_GET["zdcs"]; 
	$xgnr = $_GET["xgnr"]; 

	// 连接数据库
	$conn = mysqli_connect($host, $mysql_user, $mysql_pwd, $db_name, $db_port);
	if (!$conn) {
	    die("连接数据库失败: " . mysqli_connect_error());
	}
	
	$sql = "SELECT * FROM canshu WHERE $zdcs='{$zdcs}'";
	
	$res = mysqli_query($conn, $sql)->fetch_row();
	if (empty($res)) {
		$upsql = "UPDATE canshu SET $zdcs='{$zdcs}' , $zdcs='{$xgnr}' WHERE id='1'";
		echo "修改成功";
	}
	
	$update_res = mysqli_query($conn, $upsql);

	mysqli_close($conn);
?>
