<?php

// 连接数据库
include '../../../include/config.php';
$conn = mysqli_connect($host,$mysql_user,$mysql_pwd,$db_name);

if ($conn === false) {
  die("连接数据库失败: " . mysqli_connect_error());
}


$zdcs = $_GET["zdcs"]; 

// 查询数据库
$sql = "select * from canshu ";
$result = mysqli_query($conn, $sql);

// 读取一条记录
$row = mysqli_fetch_assoc($result);

if(empty($row)){
	 echo "没有找到匹配的记录";
}else{
	// 显示记录
	echo "{$row[$zdcs]}";  
}


// 关闭数据库连接
mysqli_close($conn);

?>

