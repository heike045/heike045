<?php

require_once 'globals.php';
include_once 'header.php';


if (isset($_POST['qingkong'])) { 

$src = 'upload/';

$d = new RecursiveDirectoryIterator($src);
$i = new RecursiveIteratorIterator($d);
foreach ($i as $name => $file) {
if (!is_dir($name)) {
	

unlink($name); //删除旧目录下的文件

echo "<script>alert('清空图库完成!');location.href='".$_SERVER["HTTP_REFERER"]."';</script>"; 

	}
	}

}

?>



<?php  
  
if(isset($_FILES['files'])){  
    $res =  upload_multiple_file($_FILES['files'],"upload/");    //上传路径
    echo $res;  
    }  
  
  
function upload_multiple_file($file,$file_dir) {  
  
    $overwrite=0;  
    $allowed_file_type= array("jpg", "jpeg", "png");    //上传类型
    $max_file_size = 2097152;      //限制上传大小2M   //1048576 = 1MB
  
     foreach($_FILES['files']['name'] as $fkey=> $fname){  
        
         $ext = pathinfo($fname, PATHINFO_EXTENSION);  
           if (!in_array($ext, $allowed_file_type)) {  
             
                return "不支持此文件类型上传";  
			    //echo "<script> alert('不支持此文件类型上传'); </script>";
                break;  
           }  
        
       
     }  
  
    foreach($_FILES['files']['tmp_name'] as $key => $tmp_name ){  
          
                  
        $file_name = $_FILES['files']['name'][$key];  
          
          
        $file_size =$_FILES['files']['size'][$key];  
          
          
        $file_tmp_name =$_FILES['files']['tmp_name'][$key];  
          
          
        $file_type=$_FILES['files']['type'][$key];  
  
          
        if($file_size >0) {  
            if($file_size > $max_file_size){  
              
                $fsize=$max_file_size/1048576; 
                return  '文件大小必须小于： '.$fsize.' MB';  
				//echo "<script> alert('超过限制文件大小');</script>";
                break;  
            
            }  
        }  
          
       
        if(is_dir($file_dir)==false){  
              
              $status =  mkdir("$file_dir", 0700);    
                 
               if($status < 1){  
                       
                     return "无法创建目录： $file_dir ";  
					 //echo "<script> alert('无法创建目录');</script>";
                       
                }                
              
        }  
              
        if(is_dir($file_dir)){  
              
            if($overwrite < 1){  
                
                move_uploaded_file($file_tmp_name,"$file_dir/".$file_name);  
               
            }  
               
        }  
             
        //  $file_upload_query="INSERT into user_uploads (`u_id`,`file_name`,`file_type`) VALUES('$user_id','$file_name','$file_size','$file_type'); ";  
        //mysql_query($file_upload_query);        
          
      
   }  
      
		echo "<script> alert('图片上传成功');</script>";
      
}  
  
?>  




<title>图库管理</title>


				<div class="tpl-content-wrapper">
				<div class="tpl-portlet-components">
					<div class="portlet-title">
						<div class="caption font-green bold">
							<i class="fa fa-area-chart"></i>   图库管理
						</div>
					</div>
			
<div class="tpl-block">
<div class="am-g">




    <form action="" method="POST" enctype="multipart/form-data">
<div class="am-u-sm-centered" style="display:flex;justify-content: center;">
		<input name='files[]' type='file' multiple style="display:block;max-width:250px;flex:1;">
		<input value='上传' type='submit' style="display:block;" class="am-btn am-btn-primary" >
</div>
    </form>

<p>  


<form action="" method="POST" enctype="multipart/form-data">
	<div class="am-u-sm-centered" style="display:flex;justify-content: center;">
		<input type="button" name="qingkong" value="清空图库" id="scsy" onclick="delall()" class="am-btn am-btn-primary" style="display:block;"></input>
	</div>
</form>

<p> 

<div class="header">
							<div class="am-u-sm-12">


									<div class="am-scrollable-horizontal">
										<table width="100%" id="adm_log_list" class="am-table am-table-hover table-main am-text-nowrap">
											<thead>
												<tr>
													<th>图片名</th>
													<th>操作</th>
												</tr>
											</thead>
											
<tbody>
											
<?php
$dir = dirname(__FILE__)."/upload/";  //要读取的文件夹
// 以升序排序 - 默认
$a = scandir($dir);
// 以降序排序
$b = scandir($dir,1);
//print_r($b);

foreach ($a as $v) {
       
        if($v === '.' || $v === '..'){
            continue;
        }
        $v = (string)$v;//转化成字符串
        if(strpos($v,'.')){											
?>			
											
												<tr>
												
<td>
<?php

            
			echo "<li><div><a target='_blank' href='upload/".$v."'>".$v." </a>";
?>
</td>	
			
<td>
<?php
echo '<a href="tupian-zddel.php?wjm='.$v.'">删除</a></div></h3></li>';
            continue;
        }else{
            
            continue;
        }
        
}

?>
</td>
												</tr>
												
</tbody>
										</table>
									</div>
									
</div>   
									
										

						
							
						</div>

</div>

</div>

						
</div>
			


<script>
function delall() {
//console.log($("#btndelete").val());
if (!confirm('确认要清空图库吗？')) {
return false;
}
else {
$("#scsy").prop("type","submit");
}
}
</script>	

<?php
include_once 'footer.php';
?>