<?php

session_start();

$user_perm_level = $_SESSION['user_perm_level'];

switch($user_perm_level){   //判断登陆用户的权限，跳转到对应的导航栏

  case 1:

	$quanxian = '1';    //定义权限为管理员
	
    break;

  case 2:

	$quanxian = '2';    //定义权限为用户

    break;
	
}

?>

<?php if(!$islogin) {exit('error!');} ?>


<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		
		<meta name="description" content="index">
		<meta name="keywords" content="index">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="renderer" content="webkit">
		<meta http-equiv="Cache-Control" content="no-siteapp" />
		<link rel="icon" type="image/png" href="assets/img/favicon.ico">
		<link rel="apple-touch-icon-precomposed" href="assets/img/favicon.ico">
		<meta name="apple-mobile-web-app-title" content="Amaze UI" />
		<link rel="stylesheet" href="assets/css/amazeui.min.css" />
		<link rel="stylesheet" href="assets/css/admin.css">
		<link rel="stylesheet" href="assets/css/app.css">
		<link rel="stylesheet" href="assets/css/font-awesome.min.css">
		<script src="assets/js/echarts.min.js"></script>
        <style type="text/css"> 
          i.fa {
            width: 2rem;
            font-size: 2rem;
            text-align: center;
          }
        </style>
	</head>
	<body data-type="index">
		<header class="am-topbar am-topbar-inverse admin-header">
			<div class="am-topbar-brand">

			</div>
			<div class="am-icon-list tpl-header-nav-hover-ico am-fl am-margin-right tpl-header-switch-button"></div>
			<button class="am-topbar-btn am-topbar-toggle am-btn am-btn-sm am-btn-success am-show-sm-only" data-am-collapse="{target: '#topbar-collapse'}">
				<span class="am-sr-only">导航切换</span> <span class="am-icon-bars"></span>
			</button>
			
			
			
			
			<div class="am-collapse am-topbar-collapse" id="topbar-collapse">
				<ul class="am-nav am-nav-pills am-topbar-nav am-topbar-right admin-header-list tpl-header-list">
					<li class="am-dropdown" data-am-dropdown data-am-dropdown-toggle>
					<!--
				<li>
						<a class="am-dropdown-toggle tpl-header-list-link" href="api-help.php">
							<span class="tpl-header-list-user-nick">Api接口说明</span>
						</a>
				</li>
					-->
					
					
				<li>
						<a class="am-dropdown-toggle tpl-header-list-link" href="login-xg.php">
							<span class="tpl-header-list-user-nick">修改密码</span>
						</a>
				</li>
						
				<li>
						<a class="am-dropdown-toggle tpl-header-list-link" href="./?action=logout">
							<span class="tpl-header-list-user-nick">退出登陆</span>
						</a>
				</li>
						
						

				</ul>
			</div>
		</header>
		<div class="tpl-page-container tpl-page-header-fixed">
			<div class="left-sidebar">
			
				<div class="tpl-left-nav-title">导航</div>
				
				<div class="tpl-left-nav-list">
					<ul class="tpl-left-nav-menu">
					
						
						<li class="tpl-left-nav-item">
							<a href="index.php" class="nav-link tpl-left-nav-link-list<?php if($_SERVER['PHP_SELF']=='/admin/index.php'){ echo ' active';} ?>">
								<i class="fa fa-home" aria-hidden="true"></i>
								<span>设备总览</span>
							</a>
						</li>
						 
						<li class="tpl-left-nav-item">
							<a href="kongzhi-index.php" class="nav-link tpl-left-nav-link-list<?php if($_SERVER['PHP_SELF']=='/admin/kongzhi-index.php'){ echo ' active';} ?>">
								<i class="fa fa-th-large" aria-hidden="true"></i>
								<span>设备控制</span>
							</a>
						</li>
						
						<!--
						<li class="tpl-left-nav-item">
							<a href="jiankong-index.php" class="nav-link tpl-left-nav-link-list<?php if($_SERVER['PHP_SELF']=='/admin/jiankong-index.php'){ echo ' active';} ?>">
								<i class="fa fa-eye" aria-hidden="true"></i>
								<span>设备监控</span>
								<i class="tpl-left-nav-content tpl-badge-danger"></i>
							</a>
						</li>
						-->
						
						<li class="tpl-left-nav-item">
							<a href="peizhi-index.php" class="nav-link tpl-left-nav-link-list<?php if($_SERVER['PHP_SELF']=='/admin/peizhi-index.php'){ echo ' active';} ?>">
								<i class="fa fa-cog" aria-hidden="true"></i>
								<span>热更配置</span>
								<i class="tpl-left-nav-content tpl-badge-danger"></i>
							</a>
						</li>
						
						<li class="tpl-left-nav-item">
							<a href="canshu-index.php" class="nav-link tpl-left-nav-link-list<?php if($_SERVER['PHP_SELF']=='/admin/canshu-index.php'){ echo ' active';} ?>">
								<i class="fa fa-mixcloud" aria-hidden="true"></i>
								<span>云端参数</span>
								<i class="tpl-left-nav-content tpl-badge-danger"></i>
							</a>
						</li>
						
						<li class="tpl-left-nav-item">
							<a href="shujuku-index.php" class="nav-link tpl-left-nav-link-list<?php if($_SERVER['PHP_SELF']=='/admin/shujuku-index.php'){ echo ' active';} ?>">
								<i class="fa fa-globe" aria-hidden="true"></i>
								<span>数据管理</span>
								<i class="tpl-left-nav-content tpl-badge-danger"></i>
							</a>
						</li>
							
						<li class="tpl-left-nav-item">
							<a href="zhanghao-index.php" class="nav-link tpl-left-nav-link-list<?php if($_SERVER['PHP_SELF']=='/admin/zhanghao-index.php'){ echo ' active';} ?>">
								<i class="fa fa-table" aria-hidden="true"></i>
								<span>账号管理</span>
								<i class="tpl-left-nav-content tpl-badge-danger"></i>
							</a>
						</li>
						
						<li class="tpl-left-nav-item">
							<a href="wenjian-index.php" class="nav-link tpl-left-nav-link-list<?php if($_SERVER['PHP_SELF']=='/admin/wenjian-index.php'){ echo ' active';} ?>">
								<i class="fa fa-file" aria-hidden="true"></i>
								<span>文件管理</span>
								<i class="tpl-left-nav-content tpl-badge-danger"></i>
							</a>
						</li>
						
						<li class="tpl-left-nav-item">
							<a href="tupian-index.php" class="nav-link tpl-left-nav-link-list<?php if($_SERVER['PHP_SELF']=='/admin/tupian-index.php'){ echo ' active';} ?>">
								<i class="fa fa-area-chart" aria-hidden="true"></i>
								<span>图库管理</span>
								<i class="tpl-left-nav-content tpl-badge-danger"></i>
							</a>
						</li>
					
						<li class="tpl-left-nav-item">
							<a href="adm_user.php" class="nav-link tpl-left-nav-link-list<?php if($_SERVER['PHP_SELF']=='/admin/adm_user.php'){ echo ' active';} ?>">
								<i class="fa am-icon-user" aria-hidden="true"></i>
								<span>账号验证</span>
							</a>
						</li>
						
						<li class="tpl-left-nav-item">
							<a href="kami-index.php" class="nav-link tpl-left-nav-link-list<?php if($_SERVER['PHP_SELF']=='/admin/kami-index.php'){ echo ' active';} ?>">
								<i class="fa fa-credit-card-alt" aria-hidden="true"></i>
								<span>卡密验证</span>
								<i class="tpl-left-nav-content tpl-badge-danger"></i>
							</a>
						</li>

						<li class="tpl-left-nav-item">
							<a href="miyao-index.php" class="nav-link tpl-left-nav-link-list<?php if($_SERVER['PHP_SELF']=='/admin/miyao-index.php'){ echo ' active';} ?>">
								<i class="fa fa-users" aria-hidden="true"></i>
								<span>前台用户</span>
							</a>
						</li>
						
						<li class="tpl-left-nav-item">
							<a href="../user/index.php" target="_blank" class="nav-link tpl-left-nav-link-list<?php if($_SERVER['PHP_SELF']=='../user/index.php'){ echo ' active';} ?>">
								<i class="fa fa-share" aria-hidden="true"></i>
								<span>前台入口</span>
							</a>
						</li>
						
					</ul>
				</div>
			</div>