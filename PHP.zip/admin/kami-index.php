<?php

require_once 'globals.php';
include_once 'header.php';

if($quanxian == 2){   //如果是用户访问就跳出提示
echo "<script>alert('您没有权限访问本页面');location.href='index.php';</script>";
}




$sql1 = "select count(*) from kami ";
$data1 = $db->query($sql1);
$rows1=$db->fetch_array($data1);

$sql2 = "select count(*) from kami where new='n '";
$data2 = $db->query($sql2);
$rows2=$db->fetch_array($data2);

$sql3 = "select count(*) from kami where new='y '";
$data3 =$db->query($sql3);
$rows3=$db->fetch_array($data3);

$domain = $_SERVER['SERVER_NAME'];
$serverapp = $_SERVER['SERVER_SOFTWARE'];
$mysql_ver = $db->getMysqlVersion();
$php_ver = PHP_VERSION;
$uploadfile_maxsize = ini_get('upload_max_filesize');
if(function_exists("imagecreate")){
	if(function_exists('gd_info')){
		$ver_info = gd_info();
		$gd_ver = $ver_info['GD Version'];
	}else{
		$gd_ver = '支持';
	}
}else{
	$gd_ver = '不支持';
}
?>

<title>卡密验证</title>

			<div class="tpl-content-wrapper">
				<div class="tpl-portlet-components">
					<div class="portlet-title">
						<div class="caption font-green bold">
							<i class="fa fa-credit-card"></i>   卡密验证
						</div>
					</div>


<div class="am-g">

				<div class="row">


					<div class="am-u-lg-3 am-u-md-6 am-u-sm-12">
						<a href="add_kami.php">
							<div class="dashboard-stat blue">
								<div class="visual">
									<i class="am-icon-users"></i>
								</div>
								<div class="details">
									<div class="number"><?php echo $rows1['count1(*)'] ;?></div>
									<div class="desc">卡密生成</div>
								</div>
								<span class="more">卡密生成
								</span>
							</div>
						</a>
					</div>



					<div class="am-u-lg-3 am-u-md-6 am-u-sm-12">
						<a href="adm_kami.php">
							<div class="dashboard-stat red">
								<div class="visual">
									<i class="am-icon-credit-card"></i>
								</div>
								<div class="details">
									<div class="number"><?php echo $rows1['count(*)'] ;?></div>
									<div class="desc">卡密总数</div>
								</div>
								<span class="more">>>卡密管理<<
									<i class="m-icon-swapright m-icon-white"></i>
								</span>
							</div>
						</a>
					</div>
					
					
					<div class="am-u-lg-3 am-u-md-6 am-u-sm-12">
						<a href="out_kami.php">
							<div class="dashboard-stat purple">
								<div class="visual">
									<i class="am-icon-credit-card"></i>
								</div>
								<div class="details">
									<div class="number"><?php echo $rows3['count(*)'] ;?></div>
									<div class="desc">未使用卡密</div>
								</div>
								<span class="more">>>卡密导出<<
									<i class="m-icon-swapright m-icon-white"></i>
								</span>
							</div>
						</a>
					</div>
					
					
					<div class="am-u-lg-3 am-u-md-6 am-u-sm-12">
						<a href="del_kami.php">
							<div class="dashboard-stat green">
								<div class="visual">
									<i class="am-icon-credit-card"></i>
								</div>
								<div class="details">
									<div class="number"><?php echo $rows2['count(*)'];?></div>
									<div class="desc">已使用卡密</div>
								</div>
								<span class="more">>>卡密清理<<
									<i class="m-icon-swapright m-icon-white"></i>
								</span>
							</div>
						</a>
					</div>
					
					
					
				</div>




<?php
include_once 'footer.php';
?>