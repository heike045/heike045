<?php

include '../include/pzconfig.php';
include_once 'header.php';

$sql="select * from kongzhi where 1";
$queryc=$db->query($sql);
$nums=$db->num_rows($queryc);
$enums=100000;  //每页显示的条目数 
$page=isset($_GET['page']) ? intval($_GET['page']) : 1;
$url="index.php?page=";
$bnums=($page-1)*$enums;


//编写查询数量sql语句
$sql = 'SELECT COUNT(*) FROM `kongzhi`';
//执行查询操作、处理结果集
$n = mysqli_query($link, $sql);
if (!$n) {
    exit('查询数量sql语句执行失败。错误信息：'.mysqli_error($link));  // 获取错误信息
}
$num = mysqli_fetch_assoc($n);

//将一维数组的值转换为一个字符串
$num = implode($num);

?>

<title>设备总览</title>


			<div class="tpl-content-wrapper">
			


				<div class="tpl-portlet-components">
					<div class="portlet-title">
						<div class="caption font-green bold">
							<i class="fa fa-home"></i>   设备总览
						</div>
					</div>
					
						<div class="am-g">
						
						
						
		
						
						
<style>
    .number {
        display: flex;
        align-items: center;
        justify-content: center;
        flex-wrap: wrap;
    }    
    .number li {
        padding:2px 8px;
        border-radius:5px;
        color:#ffffff;
        font-size:16px;
        font-weight:bold;
        margin-right:5px;
		margin-top:8px;
    }
    .number li.green {background-color:#35cb62}
    .number li.red {background-color:#e84641}
    .number li.blue {background-color:#25a1f7}
</style>

<div class="refresh">   <!--局部刷新这里的内容开始-->




<div class="am-btn  am-u-sm-centered" >
			<label for="num" id="num_label" class="am-form-label">总设备数：<?php echo $num;?> 台</label>
</div>		



                                                <ul class="number">
												<?php
												$username = isset($_POST['username']) ? addslashes(trim($_POST['username'])) : '';
												if($username != ''){
													$sql="select * from kongzhi where username='$username' order by username asc limit $bnums,$enums";
												}else{
													$sql="select * from kongzhi where 1 order by username asc limit $bnums,$enums";
												}
												$query=$db->query($sql);
                                                $time = time();
												while($rows=$db->fetch_array($query)){

                                                    $rowtime = strtotime($rows['shijian']);
                                                    $yew = 'green';
                                                    if($time-$rowtime>300){    //如果超过300秒没有更新  页面就判定为未连接
                                                        $yew = 'red';
                                                    }
												    if($rows['password']=='领取奖励结束'){
                                                        $yew = 'blue';
                                                    }
												?>

                                        
                                                    <li class="<?php echo $yew;?>"><?php echo $rows['username']; ?></li>
												
										
												<?php
												}
												?>
    

                                                 </ul>
										
</div>   <!--局部刷新这里的内容结束-->	
									
									

						</div>
					</div>
				</div>
				
				
				
				
			<script>
			function checkAll() {
				var code_Values = document.getElementsByTagName("input");
				var all = document.getElementById("all");
				if (code_Values.length) {
					for (i = 0; i < code_Values.length; i++) {
						if (code_Values[i].type == "checkbox") {
							code_Values[i].checked = all.checked;
						}
					}
				} else {
					if (code_Values.type == "checkbox") {
						code_Values.checked = all.checked;
					}
				}
			}
			function delsubmit(){
				var delform = document.getElementById("form_log");
				delform.submit();
			}
			</script>
			
			
			
			
			
   <!--局部刷新方法开始-->		
<script src="layer/jquery.min.js"></script>

<script type="text/javascript">
    $(function(){
        setInterval(function () { $(".refresh").load(location.href + " .refresh"); }, 10000);       <!--2000毫秒刷新一次-->	
    })
</script>	
   <!--局部刷新方法结束-->	
		
		
			
			
<?php
include_once 'footer.php';
?>