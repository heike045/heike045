<?php

require_once 'globals.php';

if($quanxian == 2){   //如果是用户访问就跳出提示
echo "<script>alert('您没有权限访问本页面');location.href='index.php';</script>";
}


$submit = isset($_POST['submit']) ? addslashes($_POST['submit']) : '';
if($submit){
	$sql="DELETE FROM `kami` WHERE `new`='n'";
	$query=$db->query($sql);
	if($query){
		echo "<script>alert('清理已使用卡密成功');location.href='adm_kami.php';</script>";
	}
}


$submit2 = isset($_POST['submit2']) ? addslashes($_POST['submit2']) : '';
if($submit2){
	$sql="DELETE FROM `kami` WHERE `new`='y'";
	$query=$db->query($sql);
	if($query){
		echo "<script>alert('清理未使用卡密成功');location.href='adm_kami.php';</script>";
	}
}



require_once 'header.php';

?>


<title>卡密清理</title>

			<div class="tpl-content-wrapper">

				<div class="tpl-portlet-components">
					<div class="portlet-title">
						<div class="caption font-green bold">
							<i class="am-icon-credit-card"></i>卡密清理
						</div>
					</div>
					
					<div style="height:20px;"></div>	
					
					<form action="" method="post" id="addimg" name="addimg">
						<div id="post">
							<div class="am-form-group" id="post_button">
								<div class="am-u-sm-centered">
									<input type="button" name="submit" value="清理已使用卡密" class="am-btn am-btn-primary" id="yykm" onclick="delall()" style="display:block; margin:0 auto;"></input>
								</div>
								
								<div style="height:30px;"></div>	
								
								<div class="am-u-sm-centered">
									<input type="button" name="submit2" value="清理未使用卡密" class="am-btn am-btn-primary" id="wykm" onclick="del()" style="display:block; margin:0 auto;"></input>
								</div>
							</div>
						</div>
					</form>
					
					
				</div>
			</div>
			
			
<script>
function delall() {
//console.log($("#btndelete").val());
if (!confirm('确认要删除已使用卡密吗？')) {
return false;
}
else {
$("#yykm").prop("type","submit");
}
}
function del() {
//console.log($("#btndelete").val());
if (!confirm('确认要删除未使用卡密吗？')) {
return false;
}
else {
$("#wykm").prop("type","submit");
}
}
</script>	


			
<?php
include_once 'footer.php';
?>