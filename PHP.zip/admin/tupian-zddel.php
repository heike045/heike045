<?php

require_once 'globals.php';

$wjm = $_GET["wjm"]; //设备名

unlink ('upload/'.$wjm);

echo "<script>alert('删除图片完成！');location.href='".$_SERVER["HTTP_REFERER"]."';</script>"; 


?>