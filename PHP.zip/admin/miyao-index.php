<?php

require_once 'globals.php';
include_once 'header.php';


if($quanxian == 2){   //如果是用户访问就跳出提示
echo "<script>alert('您没有权限访问本页面');location.href='index.php';</script>";
}

$sql="select * from miyao where 1";
$queryc=$db->query($sql);
$nums=$db->num_rows($queryc);
$enums=3000;  //每页显示的条目数 
$page=isset($_GET['page']) ? intval($_GET['page']) : 1;
$av_url = $_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"]);
 $url="miyao-index.php?page=";
$bnums=($page-1)*$enums;

$ids = isset($_POST['ids']) ? $_POST['ids'] : '';


function deleteDir($dir)
{
	if (!$handle = @opendir($dir)) {
		return false;
	}
	while (false !== ($file = readdir($handle))) {
		if ($file !== "." && $file !== "..") {       //排除当前目录与父级目录
			$file = $dir . '/' . $file;
			if (is_dir($file)) {
				deleteDir($file);
			} else {
				@unlink($file);
			}
		}
	}
	@rmdir($dir);
}


if ($ids) {
    $idss = '';
    foreach ($ids as $value) {
        $idss .= $value.",";
    }
    $idss = rtrim($idss, ",");

    $sql = "SELECT `id`, `username` FROM `miyao` WHERE `id` in ($idss)";
    $query = $db->query($sql);
    if ($query) {
        $results = array();
while ($row = mysqli_fetch_assoc($query)) {
    $results[] = $row;
}
        foreach ($results as $result) {
            $id = $result['id'];
            $username = $result['username'];

			$sql="DELETE FROM `miyao` WHERE `id` in ($id)";
			$query=$db->query($sql);

			$sql="DROP TABLE `$username` ;";  //删除云数据
			$queryc=$db->query($sql);
			
			$path1 = "../admin/upload/wenjian/".$username ; //删除文件夹
			$path2 = "../admin/upload/".$username ; //删除文件夹
			deleteDir($path1); //删除文件夹
			deleteDir($path2); //删除文件夹
			
			echo "<script>alert('用户删除成功!');location.href='".$_SERVER["HTTP_REFERER"]."';</script>"; 
			
        }
    }
}


?>

<title>前台用户</title>

			<div class="tpl-content-wrapper">

				<div class="tpl-portlet-components">
					<div class="portlet-title">
						<div class="caption font-green bold">
							
							<i class="fa fa-users">&nbsp;</i>   前台用户
						</div>
					</div>
					<div class="tpl-block">
						<div class="am-g">

							
								
								<form action="miyao-index.php" method="post" name="suer" id="suer">
									<div class="am-u-sm-centered" style="display:flex;justify-content: center;">
									<input type="text" class="am-input-group-label" name="username" placeholder="请输入用户名" style="max-width:130px;flex:1;"></input>
									<input class="am-btn am-btn-primary" value="搜索用户" type="submit"></input>
									<input style="margin-left:10px;" type=button value=添加用户 onclick="window.location.href='miyao-add.php'" class="am-btn am-btn-primary">
									</div>
								</form>	
								
							
							<div class="am-u-sm-12">
								<form action="" method="post" name="form_log" id="form_log">
									<div class="am-scrollable-horizontal">
										<table width="100%" id="adm_log_list" class="am-table am-table-hover table-main am-text-nowrap">
											<thead>
												<tr>
													<th class="table-check">
														<input type="checkbox" onclick="checkAll();" class="ids" id="all"></input>
													</th>
													
													
													<th>登录秘钥</th>
													
													<th>分组权限</th>
													

												</tr>
											</thead>
											<tbody>
												<?php
												$username = isset($_POST['username']) ? addslashes(trim($_POST['username'])) : '';
												if($username != ''){
												$sql="select * from miyao where username='$username' order by id desc limit $bnums,$enums";
												}else{
												$sql="select * from miyao where 1 order by id desc limit $bnums,$enums";
												}
												$query=$db->query($sql);
												while($rows=$db->fetch_array($query)){
												?>
												<tr>
													<td>
														<input type="checkbox" name="ids[]" value="<?php echo $rows['id']; ?>" class="ids"></input>
													</td>
													<td><?php echo $rows['username']; ?></td>
													
													<td><?php echo $rows['quanxian']; ?></td>
													
												</tr>
												<?php
												}
												?>
											</tbody>
										</table>
									</div>
									<div class="list_footer">
										<small>选中项：</small> <a href="javascript:void(0);" onclick="delsubmit()" class="am-badge am-badge-danger am-round">删除</a>
									</div>
								</form>
							</div>
							<?php if($username == ''): ?>
							<div class="page" style="text-align:center;"><?php echo pagination($nums,$enums,$page,$url); ?></div>
							<?php endif; ?>
							<div style="height:60px;"></div>
						</div>
					</div>
				</div>
			</div>
			<script>
			function checkAll() {
				var code_Values = document.getElementsByTagName("input");
				var all = document.getElementById("all");
				if (code_Values.length) {
					for (i = 0; i < code_Values.length; i++) {
						if (code_Values[i].type == "checkbox") {
							code_Values[i].checked = all.checked;
						}
					}
				} else {
					if (code_Values.type == "checkbox") {
						code_Values.checked = all.checked;
					}
				}
			}
			function delsubmit(){
				var delform = document.getElementById("form_log");
				delform.submit();
			}
			</script>
<?php
include_once 'footer.php';
?>

