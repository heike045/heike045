<?php

require_once 'globals.php';



$src = 'upload/wenjian/';

$d = new RecursiveDirectoryIterator($src);
$i = new RecursiveIteratorIterator($d);
foreach ($i as $name => $file) {
if (!is_dir($name)) {


unlink($name); //删除旧目录下的文件

}
}

echo "<script>alert('清空文件完成！');location.href='".$_SERVER["HTTP_REFERER"]."';</script>"; 


?>