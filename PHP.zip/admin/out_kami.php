<?php

require_once 'globals.php';


if($quanxian == 2){   //如果是用户访问就跳出提示
echo "<script>alert('您没有权限访问本页面');location.href='index.php';</script>";
}


$type = isset($_POST['type']) ? addslashes($_POST['type']) : 'TK';
$new = isset($_POST['new']) ? addslashes($_POST['new']) : 'y';
$submit = isset($_POST['submit']) ? addslashes($_POST['submit']) : '';
if($submit){
	$sql="select * from kami where `type`='$type' and `new`='$new'";
	$query=$db->query($sql);
	header("Content-Type: application/octet-stream");
	header("Content-Disposition: attachment; filename={$type}_kami.txt");
	echo "==============卡密开始================\r\n\r\n";
	while($rows=$db->fetch_array($query)){
		echo $rows['kami']."\r\n";
	}
	echo "\r\n\r\n==============卡密结束================";
	exit;
}else{
	require_once 'header.php';
}
?>

<title>卡密导出</title>

			<div class="tpl-content-wrapper">

				<div class="tpl-portlet-components">
					<div class="portlet-title">
						<div class="caption font-green bold">
							<span class="am-icon-credit-card"></span>卡密导出
						</div>
					</div>
					<div class="tpl-block">
						<div class="am-g">
							<div class="tpl-form-body tpl-form-line">
								<form class="am-form tpl-form-line-form am-text-nowrap" action="" method="post" id="addimg" name="addimg">
									<div id="post">
									
									
										<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="type" id="type_label" class="am-form-label">卡密类型：</label>
											<div class="" style="flex:1;">
												<select name="type" id="type" data-am-selected="{searchBox: 1}" style="display: none;flex:1">
													<option value="TK">天卡</option>
													<option value="ZK">周卡</option>
													<option value="YK">月卡</option>
													<option value="BNK">半年卡</option>
													<option value="NK">年卡</option>
													<!-- <option value="YJK">永久卡</option> -->
												</select>
											</div>
										</div>
										
										
										
										<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="new" id="new_label" class="am-form-label">是否可用：</label>
											<div class="" style="flex:1;">
												<select name="new" id="new" data-am-selected="{searchBox: 1}" style="display: none;flex:1">
													<option value="y">可用</option>
													<option value="n">已用</option>
												</select>
											</div>
										</div>
										<div class="am-form-group" id="post_button">
											<div class="am-u-sm-centered">
												<input type="submit" name="submit" value="导出卡密" class="am-btn am-btn-primary" style="display:block; margin:0 auto;"></input>
											</div>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
<?php
include_once 'footer.php';
?>