<?php

include '../include/pzconfig.php';

if($quanxian == 2){   //如果是用户访问就跳出提示
echo "<script>alert('您没有权限访问本页面');location.href='index.php';</script>";
}

$a = $_POST['a'];
$b = $_POST['b'];
$c = $_POST['c'];
$d = $_POST['d'];


//编写预处理sql语句
$delsql = "DELETE from denglu ";
$link->query($delsql);
$sql = "INSERT INTO denglu (username,password,yonghu,yonghumima)
VALUES ('{$a}', '{$b}', '{$c}', '{$d}' )";
$result = $link->query($sql);
//关闭连接
mysqli_close($link);
if (!$result) {
    die('修改失败');
} else {
	echo "<script>alert('修改成功');location.href='".$_SERVER["HTTP_REFERER"]."';</script>"; 
}

?>