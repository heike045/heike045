<?php

require_once 'globals.php';
include_once 'header.php';

if($quanxian == 2){   //如果是用户访问就跳出提示
echo "<script>alert('您没有权限访问本页面');location.href='index.php';</script>";
}

$username = isset($_POST['username']) ? addslashes($_POST['username']) : '';

$quanxian = isset($_POST['quanxian']) ? addslashes($_POST['quanxian']) : '';


if($username != '' && $quanxian != ''){
	$sql="select * from miyao where username='$username'";
	$query=$db->query($sql);
	$have=$db->fetch_array($query);
	if($have){
		echo "<script>alert('用户名已存在');</script>";
	}else{
		
		$sql="select * from miyao where quanxian='$quanxian'";
        $query=$db->query($sql);
        $have_quanxian=$db->fetch_array($query);
        if($have_quanxian){
            echo "<script>alert('权限已有用户占用');</script>";
        }else{
			
		$sql="INSERT INTO `miyao`(`username`,`quanxian`) VALUES ('$username','$quanxian')";
		$query=$db->query($sql);
		if($query){
			
			mkdir("../admin/upload/wenjian/".$username);  //创建文件夹
			mkdir("../admin/upload/".$username);  //创建文件夹
			
			$sql="CREATE TABLE `$username` LIKE zhanghao";
			$query=$db->query($sql);
			
			echo "<script> alert('用户添加成功');parent.location.href='miyao-index.php'; </script>";
		}
	}
}
}

?>
			<div class="tpl-content-wrapper">
				


				<div class="tpl-portlet-components">
					<div class="portlet-title">
						<div class="caption font-green bold">
							<span class="fa fa-username-plus">&nbsp;</span>添加用户
						</div>
					</div>
					
						<div class="am-g">
							<div class="tpl-form-body tpl-form-line">
							
								<form class="am-form tpl-form-line-form am-text-nowrap"  action="" method="post" id="addimg" name="addimg">
									<div id="post">
									
										<div class="am-form-group">
											
											<div class="am-form-group" style="display:flex;justify-content: flex-start;">
												<label for="num" id="num_label" class="am-form-label">用户名称：</label>
												<input style="max-width:200px;flex:1" type="text" class="tpl-form-input" name="username" value="" id="username"></input>
												
											</div>
										</div>
										
										
										<div class="am-form-group">
											
											<div class="am-form-group" style="display:flex;justify-content: flex-start;">
												<label for="num" id="num_label" class="am-form-label">权限设置：</label>
												<input style="max-width:200px;flex:1" type="text" class="tpl-form-input"  name="quanxian" value="" id="quanxian" ></input>
												
											</div>
										</div>

				
										<div class="am-form-group" id="post_button">
											
												<input type="submit" name="submit" value="添加用户" class="am-btn am-btn-primary" ></input>
											
										</div>
									</div>
								</form>
								
							</div>
						</div>
					</div>
				</div>
			</div>
			

			
			
			
			
			
			
			
			
			
			
			
<?php
include_once 'footer.php';
?>