<?php

require_once 'globals.php';
include_once 'header.php';


if($_POST['uptype']=='清空监控'){
	$src = 'api/jk-api/upload-mini/';
	$d = new RecursiveDirectoryIterator($src);
	$i = new RecursiveIteratorIterator($d);
	foreach ($i as $name => $file) {
	if (!is_dir($name)) {
		unlink($name); //删除旧目录下的文件
		echo "<script>alert('清空监控完成');parent.location.href='jiankong-index.php';</script>";
	}
	}
}

if($_POST['uptype']=='开启画面监控'){
	$sql = "update kongzhi set mingling='开启画面监控' ";
	$queryc = $db->query($sql);
	echo "<script>alert('开启画面监控完成，请稍候刷新显示');parent.location.href='jiankong-index.php';</script>";
}

if($_POST['uptype']=='关闭画面监控'){
	$sql = "update kongzhi set mingling='关闭画面监控' ";
	$queryc = $db->query($sql);
	echo "<script>alert('关闭画面监控完成');parent.location.href='jiankong-index.php';</script>";
}

?>



<title>云监控</title>

			<div class="tpl-content-wrapper">

				<div class="tpl-portlet-components">
					<div class="portlet-title">
						<div class="caption font-green bold">
							<i class="fa fa-eye"></i>   云监控
						</div>
						
					</div>

<div class="tpl-block">
<div class="am-g">


<form action="" method="post" name="form_log" id="form_log">	
	<div class="am-u-sm-centered" style="display:flex;justify-content: center;">
		<input style="margin-top:10px;padding-right:9px;padding-left:9px;border:0px;outline:none;background-color:#24b746;" name="uptype" type='submit' id="uptype" value="开启画面监控" class="am-btn am-btn-primary" ></input>
		<input style="margin-top:10px;margin-left:10px;padding-right:9px;padding-left:9px;border:0px;outline:none;background-color:#f0ad4e;" name="uptype" type='submit' id="uptype" value="关闭画面监控" class="am-btn am-btn-primary" ></input>
		<input style="margin-top:10px;margin-left:10px;padding-right:9px;padding-left:9px;border:0px;outline:none;background-color:#dd541c;" name="uptype" type='submit' id="uptype" value="清空监控" class="am-btn am-btn-primary"></input>
	</div>
</form>




<div class="refresh">   <!--局部刷新这里的内容开始-->

<br/>
<?php
echo '
<style>
.box {
    width:100%;
	background-color: #ffffff;
	-webkit-background-size: cover;
	-moz-background-size: cover;
	-o-background-size: cover;
	background-size:cover;
	-webkit-text-size-adjust:none;
	overflow:-Scroll;
	font-family: "微软雅黑";
	font-size:16px;
}
.waterfall {
    width:100%;
    overflow:hidden;
    display:flex;
    flex-wrap: wrap;

}
.waterfall li {
    border-top-left-radius:10px;
    border-top-right-radius:10px;
    margin-bottom:20px;
    overflow:hidden;
    width:49%;
    margin-right:1%;
}
.waterfall li img{
    width:100%;
}
.waterfall li div{
	color: #ffffff;
    text-align:center;
    background-color:#000000;
    border-bottom-right-radius:10px;
    border-bottom-left-radius:10px;
	display: inline-table;
	width:150px;
}
@media screen and (min-width:1024px){
    .waterfall li {
    width:150px;
    
}
}
</style>


';

echo '
<div class="box">
<ul class="waterfall">
';


$hostdir = dirname(__FILE__).'/api/jk-api/upload-mini/'; //要读取的文件夹

$url = '/admin/api/jk-api/upload-mini/'; //图片所存在的目录

$filesnames = scandir($hostdir); //得到所有的文件

foreach ($filesnames as $name) {
	    if($name === '.' || $name === '..'){
       continue;
    }
	
$name2 = basename($name);   //读取txt名字
	
$array=array('.jpg'=>'');   //替换.txt成空白1
	
$name2=strtr($name,$array); //替换.txt成空白2


echo '<li><img id="change'.$name.'" style="width:150px;height:260px;" src='.$url.$name.' >  <div>'.$name2.'</div></li>' ;


}

$shuzu = print_r($filesnames,true);


?>


</div>
</div>

</div>


<script src="layer/jquery.min.js"></script>
<script src="layer/layer.js"></script>


<script> 

setInterval(function(){  //定时器开始

var arr = '<?php echo json_encode($filesnames);?>';

var shuzu = JSON.parse(arr);

for(var i in  shuzu){
 console.log(shuzu[i])
 
 var change = document.getElementById("change" + shuzu[i])
 
 if(!!change){
   console.log('执行中')
   change.setAttribute("src","api/jk-api/upload-mini/" + shuzu[i] + "?rand=" + new Date() );
 }else{
  
 }
 }   //定时结束
},2000);

</script>

	






<?php
include_once 'footer.php';
?>