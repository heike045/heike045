<?php

include '../include/pzconfig.php';
require_once 'header.php';



if($quanxian == 2){   //如果是用户访问就跳出提示
echo "<script>alert('您没有权限访问本页面');location.href='index.php';</script>";
}


$current_page = empty($_GET['page']) ? 0 : $_GET['page'];
$page         = $current_page;
if ($current_page != 0) {
    $page = $current_page + 4;
}

//编写查询sql语句  键值为：peizhi
$sql = "SELECT * FROM `peizhi`  order by id desc limit 1";
//执行查询操作、处理结果集
$result = mysqli_query($link, $sql);
if (!$result) {
    exit('查询sql语句执行失败。错误信息：' . mysqli_error($link));  // 获取错误信息
}
$data = mysqli_fetch_array($result, MYSQLI_ASSOC);
if(empty($data)){
    $data['bbh'] = '';
	$data['gxms'] = '';
    $data['gxdz'] = '';
	$data['apkxzdz'] = '';
    $data['gxnr'] = '';
}
?>

<title>热更配置</title>

			<div class="tpl-content-wrapper">

				<div class="tpl-portlet-components">
					<div class="portlet-title">
						<div class="caption font-green bold">
							<i class="fa fa-cog"></i>   热更配置
						</div>
					</div>
					
				
						<div class="am-g">
							
								<form class="am-form tpl-form-line-form am-text-nowrap" action="peizhi-save.php" method="post" id="addimg" name="addimg">
									<div id="post">
									
										<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="num" id="num_label" class="am-form-label">云版本号：</label>
											<div class="" style="flex:1;">
												<input type="text" class="tpl-form-input" name="a" value="<?php echo $data['bbh'];?>" style="max-width:300px;flex:1;">
											</div>
										</div>
										
										
										<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="num" id="num_label" class="am-form-label">更新模式：</label>
											<div class="" style="flex:1;">
												<select name="b" data-am-selected="{searchBox: 0}" >
													<option value="<?php echo $data['gxms'];?>">当前模式：<?php echo $data['gxms'];?></option>
													<option value="APK更新">APK更新</option>
													<option value="热更新">热更新</option>
												</select>
											</div>
										</div>

										
										<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="num" id="num_label" class="am-form-label">热更下载地址：</label>
											<div class="" style="flex:1;">
												<input type="text" class="tpl-form-input" name="c" value="<?php echo $data['gxdz'];?>" style="max-width:300px;flex:1">
											</div>
										</div>
										
										<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="num" id="num_label" class="am-form-label">APK下载地址 ：</label>
											<div class="" style="flex:1;">
												<input type="text" class="tpl-form-input" name="d" value="<?php echo $data['apkxzdz'];?>" style="max-width:300px;flex:1">
											</div>
										</div>
										
										<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="num" id="num_label" class="am-form-label">更新内容 ：</label>
											<div class="" style="flex:1;">
												<input type="text" class="tpl-form-input" name="e" value="<?php echo $data['gxnr'];?>" style="max-width:300px;flex:1">
											</div>
										</div>

										
										<div class="am-form-group" style="display:flex;justify-content: flex-start;" id="post_button">
											<div class="am-u-sm-centered">
												<input type="submit" name="button" id="button" value="提交配置" class="am-btn am-btn-primary" style="display:block; margin:0 auto;"></input>
											</div>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>

<?php
include_once 'footer.php';
?>