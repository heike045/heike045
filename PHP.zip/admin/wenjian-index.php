<?php

require_once 'globals.php';
include_once 'header.php';

?>



<?php  
  
if(isset($_FILES['files'])){  
    $res =  upload_multiple_file($_FILES['files'],"upload/wenjian/");    //上传路径
    echo $res;  
    }  
  
  
function upload_multiple_file($file,$file_dir="upload/wenjian/") {  
  
    $overwrite=0;  
    $allowed_file_type= array("lr", "txt", "apk");    //上传类型
    $max_file_size = 62914560;      //限制上传大小60M   //1048576 = 1MB
  
     foreach($_FILES['files']['name'] as $fkey=> $fname){  
        
         $ext = pathinfo($fname, PATHINFO_EXTENSION);  
           if (!in_array($ext, $allowed_file_type)) {  
             
                return "不支持此文件类型上传";  
                break;  
           }  
        
       
     }  
  
    foreach($_FILES['files']['tmp_name'] as $key => $tmp_name ){  
          
                  
        $file_name = $_FILES['files']['name'][$key];  
          
          
        $file_size =$_FILES['files']['size'][$key];  
          
          
        $file_tmp_name =$_FILES['files']['tmp_name'][$key];  
          
          
        $file_type=$_FILES['files']['type'][$key];  
  
          
        if($file_size >0) {  
            if($file_size > $max_file_size){  
              
                $fsize=$max_file_size/1048576;  
                return  '文件大小必须小于： '.$fsize.' MB';  
                break;  
            
            }  
        }  
          
       
        if(is_dir($file_dir)==false){  
              
              $status =  mkdir("$file_dir", 0700);    
                 
               if($status < 1){  
                     return "无法创建目录： $file_dir ";  
                }                
              
        }  
              
        if(is_dir($file_dir)){  
              
            if($overwrite < 1){  
                
                move_uploaded_file($file_tmp_name,"$file_dir/".$file_name);  
               
            }  
               
        }  
             
   }  
      
		echo "<script> alert('文件上传成功');</script>";
      
}  
  
?>  




<title>文件管理</title>


				<div class="tpl-content-wrapper">
				<div class="tpl-portlet-components">
					<div class="portlet-title">
						<div class="caption font-green bold">
							<i class="fa fa-file"></i>   文件管理
						</div>
					</div>
			
<div class="tpl-block">
<div class="am-g">




    <form action="" method="POST" enctype="multipart/form-data">
<div class="am-u-sm-centered" style="display:flex;justify-content: center;">
		<input name='files[]' type='file' multiple style="display:block;max-width:250px;flex:1;">
		<input value='上传' type='submit' style="display:block;" class="am-btn am-btn-primary" >
</div>
    </form>


<p>   



<form class="am-form tpl-form-line-form am-text-nowrap" action="wenjian-del.php" method="post" id="addimg" name="addimg">
										<div class="am-form-group" id="post_button">
											<div class="am-u-sm-centered" style="display:flex;justify-content: center;">
						
						<!-- <input type="button" name="button" id="button" onclick="delall()" value="清空文件" class="am-btn am-btn-primary" style="display:block;"></input>   -->
					
						
						
						
											</div>
										</div>
</form>







<div class="header">
							<div class="am-u-sm-12">


									<div class="am-scrollable-horizontal">
										<table width="100%" id="adm_log_list" class="am-table am-table-hover table-main am-text-nowrap">
											<thead>
												<tr>
													<th>文件名</th>
													<th>操作</th>
												</tr>
											</thead>
											
<tbody>
											
<?php
$dir = dirname(__FILE__)."/upload/wenjian/";  //要读取的文件夹
// 以升序排序 - 默认
$a = scandir($dir);
// 以降序排序
$b = scandir($dir,1);
//print_r($b);

foreach ($a as $v) {
       
        if($v === '.' || $v === '..'){
            continue;
        }
        $v = (string)$v;//转化成字符串
        if(strpos($v,'.')){											
?>			
											
												<tr>
												
<td>
<?php

            
			echo "<li><div><a target='_blank' href='upload/wenjian/".$v."'>".$v." </a>";
?>
</td>	
			
<td>
<?php
echo '<a href="wenjian-zddel.php?wjm='.$v.'">删除</a></div></h3></li>';
            continue;
        }else{
            
            continue;
        }
        
}

?>
</td>
												</tr>
												
</tbody>
										</table>
									</div>
									
</div>   <!--局部刷新这里的内容结束-->	
									
										

						
							
						</div>
					</div>




						</div>
	
						
					</div>
			</div>


   
<script>
function delall() {
//console.log($("#btndelete").val());
if (!confirm('确认要清空文件吗？')) {
return false;
}
else {
$("#button").prop("type","submit");
}
}
</script>	



<?php
include_once 'footer.php';
?>