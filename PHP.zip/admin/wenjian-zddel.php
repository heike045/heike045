<?php

require_once 'globals.php';

$wjm = $_GET["wjm"]; //设备名

unlink ('upload/wenjian/'.$wjm);

echo "<script>alert('删除文件完成！');location.href='".$_SERVER["HTTP_REFERER"]."';</script>"; 


?>