<?php

include '../include/pzconfig.php';
include_once 'header.php';


//连接数据库
mysqli_set_charset($link, 'utf8');


//获取id
$id = $_GET['id'];
//编写查询sql语句
$sql = "SELECT * FROM `student` WHERE `id`=$id";
//执行查询操作、处理结果集
$result = mysqli_query($link, $sql);
if (!$result) {
    exit('查询sql语句执行失败。错误信息：'.mysqli_error($link));  // 获取错误信息
}
$data = mysqli_fetch_all($result, MYSQLI_ASSOC);

//将二维数数组转化为一维数组
foreach ($data as $key => $value) {
  foreach ($value as $k => $v) {
    $arr[$k]=$v;
  }
}

// echo "<pre>";
// var_dump($arr);
// echo "</pre>";

?>

<!doctype html>
<html>
	<head>
		<meta charset="UTF-8">
<title>云数据</title>

			<div class="tpl-content-wrapper">
				<div class="tpl-portlet-components">
					<div class="portlet-title">
						<div class="caption font-green bold">
							<i class="fa fa-globe"></i>   修改数据
						</div>
					</div>
	</head>




<div class="tpl-block">
<div class="am-g">


	<body>
	
	
		<!--输出定制表单-->
				<form class="am-form tpl-form-line-form am-text-nowrap" action="shujuku-xiugai-chuli.php" method="post" enctype="multipart/form-data">
					<table border="1">

<div class="am-form-group" style="display:flex;justify-content: flex-start;">
						<label for="num" id="num_label" class="am-form-label">ID ：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="id" readonly="readonly" value="<?php echo $arr["id"] ?>" style="max-width:100px;flex:1;">
								</div>
</div>

<div class="am-form-group" style="display:flex;justify-content: flex-start;">
						<label for="num" id="num_label" class="am-form-label">数据名称 ：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="name" value="<?php echo $arr["name"] ?>" style="max-width:100px;flex:1;">
								</div>
</div>	
					
<div class="am-form-group" style="display:flex;justify-content: flex-start;">
						<label for="num" id="num_label" class="am-form-label">分组 ：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="fenzu" value="<?php echo $arr["fenzu"] ?>" style="max-width:100px;flex:1;">
								</div>
</div>	
					
<div class="am-form-group" style="display:flex;justify-content: flex-start;">
						<label for="num" id="num_label" class="am-form-label">数据1：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="dt1" value="<?php echo $arr["dt1"] ?>" style="max-width:200px;flex:1;">
								</div>
</div>

<div class="am-form-group" style="display:flex;justify-content: flex-start;">
						<label for="num" id="num_label" class="am-form-label">数据2：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="dt2" value="<?php echo $arr["dt2"] ?>" style="max-width:200px;flex:1;">
								</div>
</div>								
								
<div class="am-form-group" style="display:flex;justify-content: flex-start;">
						<label for="num" id="num_label" class="am-form-label">数据3：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="dt3" value="<?php echo $arr["dt3"] ?>" style="max-width:200px;flex:1;">
								</div>
</div>	

<div class="am-form-group" style="display:flex;justify-content: flex-start;">
						<label for="num" id="num_label" class="am-form-label">数据4：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="dt4" value="<?php echo $arr["dt4"] ?>" style="max-width:200px;flex:1;">
								</div>
</div>	
					
<div class="am-form-group" style="display:flex;justify-content: flex-start;">
						<label for="num" id="num_label" class="am-form-label">数据5：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="dt5" value="<?php echo $arr["dt5"] ?>" style="max-width:200px;flex:1;">
								</div>
</div>

<div class="am-form-group" style="display:flex;justify-content: flex-start;">
						<label for="num" id="num_label" class="am-form-label">数据6：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="dt6" value="<?php echo $arr["dt6"] ?>" style="max-width:200px;flex:1;">
								</div>
</div>

<div class="am-form-group" style="display:flex;justify-content: flex-start;">
						<label for="num" id="num_label" class="am-form-label">数据7：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="dt7" value="<?php echo $arr["dt7"] ?>"style="max-width:200px;flex:1;">
								</div>
</div>

<div class="am-form-group" style="display:flex;justify-content: flex-start;">
						<label for="num" id="num_label" class="am-form-label">数据8：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="dt8" value="<?php echo $arr["dt8"] ?>"style="max-width:200px;flex:1;">
								</div>
</div>

<div class="am-form-group" style="display:flex;justify-content: flex-start;">
						<label for="num" id="num_label" class="am-form-label">数据9：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="dt9" value="<?php echo $arr["dt9"] ?>" style="max-width:200px;flex:1;">
								</div>
</div>

<div class="am-form-group" style="display:flex;justify-content: flex-start;">
						<label for="num" id="num_label" class="am-form-label">数据10：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="dt10" value="<?php echo $arr["dt10"] ?>" style="max-width:200px;flex:1;">
								</div>
</div>	



<!--
					<div class="am-form-group" style="display:flex;justify-content: flex-start;">
						<label for="num" id="num_label" class="am-form-label">私聊1：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="sl1" value="<?php echo $arr["sl1"] ?>" style="max-width:200px;flex:1;">
								</div>

						<label for="num" id="num_label" class="am-form-label">私聊2：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="sl2" value="<?php echo $arr["sl2"] ?>" style="max-width:200px;flex:1;">
								</div>

						<label for="num" id="num_label" class="am-form-label">私聊3：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="sl3" value="<?php echo $arr["sl3"] ?>"style="max-width:200px;flex:1;">
								</div>

						<label for="num" id="num_label" class="am-form-label">私聊4：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="sl4" value="<?php echo $arr["sl4"] ?>" style="max-width:200px;flex:1;">
								</div>
					</div>	

					<div class="am-form-group" style="display:flex;justify-content: flex-start;">
						<label for="num" id="num_label" class="am-form-label">私聊5：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="sl5" value="<?php echo $arr["sl5"] ?>" style="max-width:200px;flex:1;">
								</div>
					</div>	
					
					
					
					<div class="am-form-group" style="display:flex;justify-content: flex-start;">
						<label for="num" id="num_label" class="am-form-label">配置1：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="pz1" value="<?php echo $arr["pz1"] ?>" style="max-width:200px;flex:1;">
								</div>

						<label for="num" id="num_label" class="am-form-label">配置2：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="pz2" value="<?php echo $arr["pz2"] ?>" style="max-width:200px;flex:1;">
								</div>

						<label for="num" id="num_label" class="am-form-label">配置3：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="pz3" value="<?php echo $arr["pz3"] ?>" style="max-width:200px;flex:1;">
								</div>

						<label for="num" id="num_label" class="am-form-label">配置4：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="pz4" value="<?php echo $arr["pz4"] ?>" style="max-width:200px;flex:1;">
								</div>
					</div>	
					
					<div class="am-form-group" style="display:flex;justify-content: flex-start;">
						<label for="num" id="num_label" class="am-form-label">配置5：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="pz5" value="<?php echo $arr["pz5"] ?>" style="max-width:200px;flex:1;">
								</div>

						<label for="num" id="num_label" class="am-form-label">配置6：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="pz6" value="<?php echo $arr["pz6"] ?>" style="max-width:200px;flex:1;">
								</div>

						<label for="num" id="num_label" class="am-form-label">配置7：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="pz7" value="<?php echo $arr["pz7"] ?>" style="max-width:200px;flex:1;">
								</div>

						<label for="num" id="num_label" class="am-form-label">配置8：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="pz8" value="<?php echo $arr["pz8"] ?>" style="max-width:200px;flex:1;">
								</div>
					</div>	

					<div class="am-form-group" style="display:flex;justify-content: flex-start;">
						<label for="num" id="num_label" class="am-form-label">配置9：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="pz9" value="<?php echo $arr["pz9"] ?>" style="max-width:200px;flex:1;">
								</div>

						<label for="num" id="num_label" class="am-form-label">配置10：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="pz10" value="<?php echo $arr["pz10"] ?>" style="max-width:200px;flex:1;">
								</div>
					</div>	




					<div class="am-form-group" style="display:flex;justify-content: flex-start;">
						<label for="num" id="num_label" class="am-form-label">预留1：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="yl1" value="<?php echo $arr["yl1"] ?>" style="max-width:200px;flex:1;">
								</div>

						<label for="num" id="num_label" class="am-form-label">预留2：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="yl2" value="<?php echo $arr["yl2"] ?>" style="max-width:200px;flex:1;">
								</div>

						<label for="num" id="num_label" class="am-form-label">预留3：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="yl3" value="<?php echo $arr["yl3"] ?>" style="max-width:200px;flex:1;">
								</div>

						<label for="num" id="num_label" class="am-form-label">预留4：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="yl4" value="<?php echo $arr["yl4"] ?>" style="max-width:200px;flex:1;">
								</div>
					</div>	

					<div class="am-form-group" style="display:flex;justify-content: flex-start;">
						<label for="num" id="num_label" class="am-form-label">预留5：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="yl5" value="<?php echo $arr["yl5"] ?>" style="max-width:200px;flex:1;">
								</div>
					</div>	
-->


						
							<div class="am-form-group" style="display:flex;justify-content: center;" id="post_button">
								<input   class="am-btn am-btn-primary" type="button" onClick="javascript :history.back(-1);" value="返回">&nbsp;&nbsp;&nbsp;
								
								<input   class="am-btn am-btn-primary" type="submit" value="提交">&nbsp;&nbsp;&nbsp;
								
							</div>
						

						
						
						
						
						
					</table>
				</form>
			</div>
		</div>
	</body>
</html>







			
<?php
include_once 'footer.php';
?>