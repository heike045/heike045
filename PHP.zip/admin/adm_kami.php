<?php

require_once 'globals.php';
include_once 'header.php';

if($quanxian == 2){   //如果是用户访问就跳出提示
echo "<script>alert('您没有权限访问本页面');location.href='index.php';</script>";
}


$sql="select * from kami where 1";
$queryc=$db->query($sql);
$nums=$db->num_rows($queryc);
$enums=20;  //每页显示的条目数 
$page=isset($_GET['page']) ? intval($_GET['page']) : 1;
$url="adm_kami.php?page=";
$bnums=($page-1)*$enums;

$id = isset($_POST['id']) ? $_POST['id'] : '';
if($id){
	$ids = '';
	foreach ($id as $value) {
		$ids .= $value.",";
	}
	$ids = rtrim($ids, ",");
	$sql="DELETE FROM `kami` WHERE `id` in ($ids)";
	$query=$db->query($sql);
	if($query){
		echo "<script>alert('删除成功');</script>";
	}
}

$KMtype = array(
	'TK'=>"天卡",
	'ZK'=>"周卡",
	'YK'=>"月卡",
	'BNK'=>"半年卡",
	'NK'=>"年卡",
	'YJK'=>"永久卡",
);
?>

<title>卡密管理</title>

			<div class="tpl-content-wrapper">

				<div class="tpl-portlet-components">
					<div class="portlet-title">
						<div class="caption font-green bold">
							<i class="am-icon-credit-card"></i>卡密管理
						</div>
					</div>
					<div class="tpl-block">
						<div class="am-g">

							
							
								<form action="adm_kami.php" method="post" name="skami" id="skami">
									<div class="am-u-sm-centered" style="display:flex;justify-content: center;">
									<input type="text" class="am-input-group-label" name="kami" placeholder="请输入卡密" style="max-width:120px;flex:1;"></input>
									<input class="am-btn am-btn-primary" value="搜索卡密" type="submit"></input>
									
									</div>
								</form>
							


							<div class="am-u-sm-12">
								<form action="" method="post" name="form_log" id="form_log">
									<div class="am-scrollable-horizontal">
										<table width="100%" id="adm_log_list" class="am-table am-table-hover table-main am-text-nowrap">
											<thead>
												<tr>
													<th class="table-check">
														<input type="checkbox" onclick="checkAll();" class="ids" id="all"></input>
													</th>
													<!-- <th>ID</th> -->
													<th>卡密</th>
													<th>绑定应用</th>
													<th>类型</th>
													<th>状态</th>
													<th>使用设备</th>
													<th>使用时间</th>
													<th>到期时间</th>
												</tr>
											</thead>
											<tbody>
												<?php
												$kami = isset($_POST['kami']) ? addslashes(trim($_POST['kami'])) : '';
												if($kami != ''){
													$sql="select * from kami where kami='$kami' order by id desc limit $bnums,$enums";
												}else{
													$sql="select * from kami where 1 order by id desc limit $bnums,$enums";
												}
												$query=$db->query($sql);
												while($rows=$db->fetch_array($query)){
												?>
												<tr>
													<td>
														<input type="checkbox" name="id[]" value="<?php echo $rows['id']; ?>" class="ids"></input>
													</td>
													<!-- <td><?php echo $rows['id']; ?></td> -->
													<td><?php echo $rows['kami']; ?></td>
													<td><?php echo $rows['yingyong']; ?></td>
													<td><?php echo $KMtype[$rows['type']]; ?></td>
													<td><?php if($rows['new']=='n'):?><font color=red>已用<?php else: ?><font color=green>可用<?php endif; ?></font></td>
													<td><?php if($rows['new']=='n'): echo $rows['imei']; endif; ?></td>
													<td><?php if($rows['new']=='n'): echo gmdate("Y-m-d H:i:s",$rows['date']+8*3600); endif; ?></td>
													<td><?php if($rows['new']=='n'): echo gmdate("Y-m-d H:i:s",$rows['vip_time']+8*3600); endif; ?></td>
												</tr>
												<?php
												}
												?>
											</tbody>
										</table>
									</div>
									
									<div class="list_footer">
										<small>选中项：</small> <a href="javascript:void(0);" onclick="delsubmit()" class="am-badge am-badge-danger am-round">删除</a>
									</div>
									
								</form>
							
							<div style="height:20px;"></div>	
								
							</div>
							<?php if($kami == ''): ?>
							<div class="page" style="text-align:center;"><?php echo pagination($nums,$enums,$page,$url); ?></div>
							<?php endif; ?>
							
						</div>
					</div>
				</div>
			</div>
			
			
			
			
			<script>
			
			function checkAll() {
				var code_Values = document.getElementsByTagName("input");
				var all = document.getElementById("all");
				if (code_Values.length) {
					for (i = 0; i < code_Values.length; i++) {
						if (code_Values[i].type == "checkbox") {
							code_Values[i].checked = all.checked;
						}
					}
				} else {
					if (code_Values.type == "checkbox") {
						code_Values.checked = all.checked;
					}
				}
			}
			function delsubmit(){
				var delform = document.getElementById("form_log");
				delform.submit();
			}
			</script>
			
<?php
include_once 'footer.php';
?>