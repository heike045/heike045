<?php

include '../include/pzconfig.php';
include_once 'header.php';
mysqli_set_charset($link, 'utf8');

$sql="select * from student where 1";
$queryc=$db->query($sql);
$nums=$db->num_rows($queryc);
$enums=5000;  //每页显示的条目数 
$page=isset($_GET['page']) ? intval($_GET['page']) : 1;
$url="shujuku-index.php?page=";
$bnums=($page-1)*$enums;

$id = isset($_POST['id']) ? $_POST['id'] : '';
$username = isset($_POST['username']) ? addslashes(trim($_POST['username'])) : '';

?>

<html>
	<head>
		<meta charset="UTF-8">
<title>数据管理</title>

			<div class="tpl-content-wrapper">
				<div class="tpl-portlet-components">
				
					<div class="portlet-title">
						<div class="caption font-green bold">
							<i class="fa fa-globe"></i>   数据管理
						</div>
					</div>
	</head>




<div class="tpl-block">
<div class="am-g">


	<body>


					
						<form action="shujuku-index.php" method="post" name="skami" id="skami">
								<div class="am-u-sm-centered" style="display:flex;justify-content: center;">
								<input type="text" class="am-input-group-label" name="username" placeholder="输入数据名称" style="max-width:130px;flex:1;"></input>
								<input class="am-btn am-btn-primary" value="搜索数据" type="submit"></input>
								</div>
						</form>
					
<p>

					
						<form action="shujuku-index.php" method="post" name="skami" id="skami">
								<div class="am-u-sm-centered" style="display:flex;justify-content: center;">
								<input type="text" class="am-input-group-label" name="fenzu" placeholder="输入分组名称" style="max-width:130px;flex:1;"></input>
								<input class="am-btn am-btn-primary" value="搜索分组" type="submit"></input>
								</div>
						</form>
					

<p>


					
						<div class="am-u-sm-centered" style="display:flex;justify-content: center;">
							<a style="margin-left:10px;" class="am-btn am-btn-primary" href="shujuku-tianjia.php">添加数据</a> 
						</div>
					
<p>

 <!--
<?php
if($username != ''){
    $sql2 = "SELECT SUM(dt2) AS total FROM student WHERE name='$username'";
}
else{
    $sql2 = "SELECT SUM(dt2) AS total FROM student";
}
$result2 = $db->query($sql2);

if ($result2 && $result2->num_rows>0) {
    $row2 = $result2->fetch_assoc();
    echo "数据2总和: " . $row2['total'];
} else {
    echo "0数据2结果";
}
?>
<p>
<?php
if($username != ''){
    $sql2 = "SELECT SUM(dt3) AS total FROM student WHERE name='$username'";
}
else{
    $sql2 = "SELECT SUM(dt3) AS total FROM student";
}
$result2 = $db->query($sql2);

if ($result2 && $result2->num_rows>0) {
    $row2 = $result2->fetch_assoc();
    echo "数据3总和: " . $row2['total'];
} else {
    echo "0数据3结果";
}
?>


<div class="am-btn  am-u-sm-centered" >
			<label for="num" id="num_label" class="am-form-label">当前有：<?php echo $num;?> 条数据</label>
</div>		
-->	
		
			<div class="am-scrollable-horizontal">
			<table width="100%" id="adm_log_list" class="am-table am-table-hover table-main am-text-nowrap">
			
<thead>
				<tr>
					<th>数据名称</th>
					<th>分组</th>
					<th>数据1</th>
					<th>数据2</th>
					<th>数据3</th>
					<th>数据4</th>
					<th>数据5</th>
					<th>数据6</th>
					<th>数据7</th>
					<th>数据8</th>
					<th>数据9</th>	
					<th>数据10</th>	
					<th>操作</th>
				</tr>
</thead>
				

			
			
			
			
			
			<tbody>
			
				<?php
				$username = isset($_POST['username']) ? addslashes(trim($_POST['username'])) : '';
				$fenzu = isset($_POST['fenzu']) ? addslashes(trim($_POST['fenzu'])) : '';
				
				if($username != ''){
					$sql="select * from student where name='$username' order by id desc limit $bnums,$enums";
				}else{
					$sql="select * from student where 1 order by id desc limit $bnums,$enums";
				}
				if($fenzu != ''){
					$sql="select * from student where fenzu='$fenzu' order by id desc limit $bnums,$enums";
				}
		
				$query=$db->query($sql);
				while($rows=$db->fetch_array($query)){
				?>

				<tr>
					<td><?php echo $rows['name']; ?></td>
					<td><?php echo $rows['fenzu']; ?></td>
					<td><?php echo $rows['dt1']; ?></td>
					<td><?php echo $rows['dt2']; ?></td>
					<td><?php echo $rows['dt3']; ?></td>
					<td><?php echo $rows['dt4']; ?></td>
					<td><?php echo $rows['dt5']; ?></td>
					<td><?php echo $rows['dt6']; ?></td>
					<td><?php echo $rows['dt7']; ?></td>
					<td><?php echo $rows['dt8']; ?></td>
					<td><?php echo $rows['dt9']; ?></td>
					<td><?php echo $rows['dt10']; ?></td>
					
					

<td>
<input style="border:0px;outline:none;background-color:#24b746" class="am-btn-secondary am-round am-btn am-btn-xs" type="button" value="修改数据" onclick="xiugai( <?php echo $rows['id']; ?> )" />
<input style="border:0px;outline:none;background-color:#dd541c" class="am-btn-secondary am-round am-btn am-btn-xs" type="button" value="删除数据" onclick="del( <?php echo $rows['id']; ?> )" />
</td>						
				</tr>
											
		<?php
		}
		?>
											
			</tbody>
			
			
			</table>
			
			
			
		</div>
</div>
</div>
</div>



</div>
</div>


		<script type="text/javascript">
			function del(id) {
				if (confirm("确定删除这个数据吗？")) {
					window.location = "shujuku-shanchu.php?id=" + id;
				}
			}
			function xiugai(id) {
					window.location = "shujuku-xiugai.php?id=" + id;
			}
		</script>



	</body>
</html>



<?php
include_once 'footer.php';
?>