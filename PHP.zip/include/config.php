<?php
$host='127.0.0.1'; 
$dbms='mysql';    
$db_port    = 3306; 
$mysql_user = "root";
$mysql_pwd  = "mima888";
$db_name    = "yunkong";

define('DB_HOST',$host);
define('DB_USER',$mysql_user);
define('DB_PASSWD',$mysql_pwd);
define('DB_NAME',$db_name);
?>