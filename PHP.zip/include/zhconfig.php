<?php


include 'config.php';

//云账号
$dsn="$dbms:host=$host;dbname=$db_name;port=$db_port";
$conn=new PDO($dsn,$mysql_user,$mysql_pwd);  //数据库账号密码


?>