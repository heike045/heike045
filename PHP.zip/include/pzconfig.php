<?php

require_once 'globals.php';

include 'config.php';

$link = mysqli_connect($host,$mysql_user,$mysql_pwd,$db_name );//登陆数据库并进入里面的yunkong数据库


?>