<?php


require("global.php");
$sql="SELECT * FROM `option`";
$query=$db->query($sql);
$have=$db->fetch_array($query);
if($have){
    $ipon = $have['ipon'];
    $codeon = $have['codeon']; 
    $check_code = $have['check_code'];
    $regvip = $have['regvip'];
    $invvip = $have['invvip']; 
    $charge = $have['charge'];
    $diaryvip = $have['diaryvip'];
   /*
    $udata = array(
		'ipon'=>$ipon,
		'codeon'=>$codeon,
		'check_code'=>$check_code,
		'regvip'=>$regvip,
		'invvip'=>$invvip,
        'charge '=>$charge,
		'diaryvip'=>$diaryvip
	);
	$jdata = json_encode($udata);
	echo $jdata;
	*/
}else{
    exit("系统设置加载失败");
}

?>