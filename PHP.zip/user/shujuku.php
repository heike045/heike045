<?php

require_once '../include/global.php';
$link = mysqli_connect($host,$mysql_user,$mysql_pwd,$db_name );

$user = isset($_GET['user']) ? addslashes(trim($_GET['user'])) : '';

$query = "SELECT * FROM miyao WHERE username = '$user' ";
$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASSWD, DB_NAME);
$result = mysqli_query($connection, $query);

if (mysqli_num_rows($result) == 1) {
  $row = mysqli_fetch_assoc($result);
  $quanxian = $row['quanxian'] ;
} else {
  echo "<script>alert('登陆失败!');location.href='".$_SERVER["HTTP_REFERER"]."';</script>"; 
  
}


//编写查询sql语句
$sql="select * from student where fenzu='$user' ";

//执行查询操作、处理结果集
$result = mysqli_query($link, $sql);
if (!$result) {
    exit('查询sql语句执行失败。错误信息：'.mysqli_error($link));  // 获取错误信息
}
$data = mysqli_fetch_all($result, MYSQLI_ASSOC);

//编写查询数量sql语句
$sql = 'SELECT COUNT(*) FROM `student`';
//执行查询操作、处理结果集
$n = mysqli_query($link, $sql);
if (!$n) {
    exit('查询数量sql语句执行失败。错误信息：'.mysqli_error($link));  // 获取错误信息
}
$num = mysqli_fetch_assoc($n);
//将一维数组的值转换为一个字符串
$num = implode($num);


?>


<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		
		<meta name="description" content="index">
		<meta name="keywords" content="index">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="renderer" content="webkit">
		<meta http-equiv="Cache-Control" content="no-siteapp" />
		<link rel="icon" type="image/png" href="../admin/assets/img/favicon.ico">
		<link rel="apple-touch-icon-precomposed" href="../admin/assets/img/favicon.ico">
		<meta name="apple-mobile-web-app-title" content="Amaze UI" />
		<link rel="stylesheet" href="../admin/assets/css/amazeui.min.css" />
		<link rel="stylesheet" href="../admin/assets/css/admin.css">
		<link rel="stylesheet" href="../admin/assets/css/app.css">
		<link rel="stylesheet" href="../admin/assets/css/font-awesome.min.css">
		<script src="../admin/assets/js/echarts.min.js"></script>
        <style type="text/css"> 
          i.fa {
            width: 2rem;
            font-size: 2rem;
            text-align: center;
          }
        </style>
	</head>


		<meta charset="UTF-8">
<title>数据管理</title>


			<div class="tpl-portlet-components">
				<div class="tpl-portlet-components">

			
	<style>
		.button {
			display: inline-block;
			padding: 10px 20px;
			font-size: 16px;
			border-radius: 5px;
			background-color: #3BB4F2;
			color: white;
			text-align: center;
			text-decoration: none;
			margin: 10px;
			transition: all 0.3s ease 0s;
			cursor: pointer;
		}

		.button:hover {
			background-color: #3BB4F2;
		}

		.caption {
			font-size: 24px;
			padding: 10px;
			margin-bottom: 20px;
			text-align: center;
		}

		.font-green {
			color: green;
		}

		.bold {
			font-weight: bold;
		}
	</style>


	<div class="portlet-title caption font-green bold" >
					  <a class="button" href='kongzhi.php?user=<?php $user = isset($_GET['user']) ? addslashes(trim($_GET['user'])) : ''; echo $user; ?>'  >设备控制</a>
					 
					  <a class="button" href='shujuku.php?user=<?php $user = isset($_GET['user']) ? addslashes(trim($_GET['user'])) : ''; echo $user; ?>' >数据管理</a>
					 
					  <a class="button" href='zhanghao.php?user=<?php $user = isset($_GET['user']) ? addslashes(trim($_GET['user'])) : ''; echo $user; ?>' >账号管理</a>
					  
					  <a class="button" href='tuku.php?user=<?php $user = isset($_GET['user']) ? addslashes(trim($_GET['user'])) : ''; echo $user; ?>' >图库管理</a>
					  
					
	</div>
	<p>
					
					<p>
					
					
					
<div class="am-g">


					<div style="display:flex;justify-content: center;">	
							<a style="margin-left:10px;" class="am-btn am-btn-primary" onclick="tanchue('<?php echo $user; ?>')">添加数据</a> 
					</div> 


	<body>





<br/>


<div class="refresh">   <!--局部刷新这里的内容开始-->	

		
			<div class="am-scrollable-horizontal">
			<table width="100%" id="adm_log_list" class="am-table am-table-hover table-main am-text-nowrap">
			
<thead>
				<tr>
					<th>ID</th>
					<th>数据名称</th> 
					<th>数据1</th>
					<th>数据2</th>
					<th>数据3</th>
					<th>数据4</th>
					<th>数据5</th>
					<th>数据6</th>
					<th>数据7</th>
					<th>数据8</th>
					<th>数据9</th>	
					<th>数据10</th>	
					<th>操作</th>
				</tr>
</thead>
				
				
<?php foreach ($data as $key => $value) { ?>
  <?php foreach ($value as $k => $v) { $arr[$k] = $v; } ?>
  <tr>
	<td><?= $arr['id'] ?></td>
    <td><?= $arr['name'] ?></td>
    <td><?= $arr['dt1'] ?></td>
    <td><?= $arr['dt2'] ?></td>
    <td><?= $arr['dt3'] ?></td>
    <td><?= $arr['dt4'] ?></td>
    <td><?= $arr['dt5'] ?></td>
    <td><?= $arr['dt6'] ?></td>
    <td><?= $arr['dt7'] ?></td>
    <td><?= $arr['dt8'] ?></td>
    <td><?= $arr['dt9'] ?></td>
    <td><?= $arr['dt10'] ?></td>
    <td>

	<input type="button" class="am-btn-secondary am-round am-btn am-btn-xs" value="修改数据" onclick="tanchu('<?= $arr['name'] ?>' ,'<?php echo $user; ?>' ,'<?= $arr['id'] ?>')" >

	<input type="button" class="am-btn-secondary am-round am-btn am-btn-xs am-btn-danger" value="删除数据" onclick="del('<?php echo $user; ?>' ,'<?= $arr['id'] ?>')" >


    </td>
  </tr>
<?php } ?>
			
			
 

			

			</table>
		</div>
</div>
</div>
</div>
</div>
</div>
</div>   <!--局部刷新这里的内容结束-->	


   <!--局部刷新方法开始-->		
<script src="../admin/layer/jquery.min.js"></script>

<script src="../admin/layer/layer.js"></script>

<script type="text/javascript">
    $(function(){
        setInterval(function () { $(".refresh").load(location.href + " .refresh"); }, 5000);       <!--2000毫秒刷新一次-->	
    })
	
	function tanchu(name,user,id){
	layer.open({
	  type: 2,
	  title: (name) ,  //窗口标题
	  id: (name) ,
	  shade: false,
	  area: ['700px', '850px'],
	  resize:false,
	  scrollbar: false,
	  content: 'shujuku-xiugai.php?user=' + (user) +'&id=' + (id) 
	});  
	}

	function tanchue(user){
	layer.open({
	  type: 2,
	  title: '添加数据' ,  //窗口标题
	  shade: false,
	  area: ['700px', '850px'],
	  resize:false,
	  scrollbar: false,
	  content: 'shujuku-tianjia.php?user=' + (user)  
	});  
	}
	
	
</script>	
   <!--局部刷新方法结束-->	


		<script type="text/javascript">
			function del(user,id) {
				if (confirm("确定删除这个数据吗？")) {
					window.location = "shujuku-shanchu.php?user=" +user +  "&id=" + id;
				}
			}
		</script>





<script src="../../admin/../admin/assets/js/jquery.min.js"></script>
<script src="../../admin/../admin/assets/js/amazeui.min.js"></script>
<script src="../../admin/../admin/assets/js/iscroll.js"></script>
<script src="../../admin/../admin/assets/js/app.js"></script>
</body>
</html>