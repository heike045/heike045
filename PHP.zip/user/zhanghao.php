<?php

require_once '../include/global.php';
include '../include/zhconfig.php';

$user = isset($_GET['user']) ? addslashes(trim($_GET['user'])) : '';

$query = "SELECT * FROM miyao WHERE username = '$user' ";
$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASSWD, DB_NAME);
$result = mysqli_query($connection, $query);

if (mysqli_num_rows($result) == 1) {
  $row = mysqli_fetch_assoc($result);
  $quanxian = $row['quanxian'] ;
} else {
  echo "<script>alert('登陆失败!');location.href='".$_SERVER["HTTP_REFERER"]."';</script>"; 
  
}


$sql="select * from $user where 1 ";

$queryc=$db->query($sql);
$nums=$db->num_rows($queryc);
$enums=10000;  //每页显示的条目数 
$page=isset($_GET['page']) ? intval($_GET['page']) : 1;
$url="zhanghao.php?page=";
$bnums=($page-1)*$enums;

$id = isset($_POST['id']) ? $_POST['id'] : '';

if($id){
	$ids = '';
	foreach ($id as $value) {
		$ids .= $value.",";
	}
	$ids = rtrim($ids, ",");
	$sql="DELETE FROM $user WHERE `id` in ($ids)";
	$query=$db->query($sql);
	if($query){
		echo "<script>alert('删除成功');</script>";
	}
}


//导出数据库指定内容
if (isset($_POST['daochu'])) { 
	echo "<script>window.location.href='zhanghao-daochu.php?user=$user'; </script>";
}
//导出数据库指定内容

//导出数据库指定内容
if (isset($_POST['daochuwsy'])) { 
	echo "<script>window.location.href='zhanghao-daochu2.php?user=$user'; </script>";
}
//导出数据库指定内容
?>

<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		
		<meta name="description" content="index">
		<meta name="keywords" content="index">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="renderer" content="webkit">
		<meta http-equiv="Cache-Control" content="no-siteapp" />
		<link rel="icon" type="image/png" href="assets/img/favicon.ico">
		<link rel="apple-touch-icon-precomposed" href="assets/img/favicon.ico">
		<meta name="apple-mobile-web-app-title" content="Amaze UI" />
		<link rel="stylesheet" href="../admin/assets/css/amazeui.min.css" />
		<link rel="stylesheet" href="../admin/assets/css/admin.css">
		<link rel="stylesheet" href="../admin/assets/css/app.css">
		<link rel="stylesheet" href="../admin/assets/css/font-awesome.min.css">
		<script src="../admin/assets/js/echarts.min.js"></script>
        <style type="text/css"> 
          i.fa {
            width: 2rem;
            font-size: 2rem;
            text-align: center;
          }
        </style>
	</head>


<body ondragstart="return false"></body>  <!-- 禁止图片拖拽 -->

<title>账号管理</title>

			<div class="tpl-portlet-components">
				<div class="tpl-portlet-components">
				
	<style>
		.button {
			display: inline-block;
			padding: 10px 20px;
			font-size: 16px;
			border-radius: 5px;
			background-color: #3BB4F2;
			color: white;
			text-align: center;
			text-decoration: none;
			margin: 10px;
			transition: all 0.3s ease 0s;
			cursor: pointer;
		}

		.button:hover {
			background-color: #3BB4F2;
		}

		.caption {
			font-size: 24px;
			padding: 10px;
			margin-bottom: 20px;
			text-align: center;
		}

		.font-green {
			color: green;
		}

		.bold {
			font-weight: bold;
		}
	</style>


	<div class="portlet-title caption font-green bold" >
					  <a class="button" href='kongzhi.php?user=<?php $user = isset($_GET['user']) ? addslashes(trim($_GET['user'])) : ''; echo $user; ?>'  >设备控制</a>
					 
					  <a class="button" href='shujuku.php?user=<?php $user = isset($_GET['user']) ? addslashes(trim($_GET['user'])) : ''; echo $user; ?>' >数据管理</a>
					 
					  <a class="button" href='zhanghao.php?user=<?php $user = isset($_GET['user']) ? addslashes(trim($_GET['user'])) : ''; echo $user; ?>' >账号管理</a>
					  
					  <a class="button" href='tuku.php?user=<?php $user = isset($_GET['user']) ? addslashes(trim($_GET['user'])) : ''; echo $user; ?>' >图库管理</a>
					  
					  
	</div>
	<p>
					
					<p>
				
					<div class="am-g">




<table>

<form enctype='multipart/form-data' name='myform' action="zhanghao-submit.php?user=<?php echo $user; ?>" method='post'>

        <INPUT TYPE = "hidden" NAME = "MAX_FILE_SIZE" VALUE ="1000000">
<div class="am-u-sm-centered" style="display:flex;justify-content: center;">
		<input name='myfile' type='file' style="display:block;max-width:250px;flex:1;">
		<input name='submit' value='上传'  type='submit' style="display:block;" class="am-btn am-btn-primary">
</div>

</form>

</table>

<p>   


<table>

<div class="am-u-sm-centered" style="display:flex;justify-content: center;">
    <form action="zhanghao-submit.php?user=<?php echo $user; ?>&action=deleteAll" method="post">
        <input style="display:flex;justify-content: center;" type='button' value="删除所有" id="scsy" onclick="delall()" class="am-btn am-btn-primary">
    </form>
	
	<form action="zhanghao-submit.php?user=<?php echo $user; ?>&action=deleysy" method="post" >
        <input style="margin-left:10px;" type='button' value="删除已使用" id="scysy" onclick="del()" class="am-btn am-btn-primary">
    </form>
</div>

<p>   

<div class="am-u-sm-centered" style="display:flex;justify-content: center;">
	<form action="" method="post" target="_blank">
        <input name="daochu" type='submit' value="导出已使用" class="am-btn am-btn-primary">
    </form>
	
		<form action="" method="post" target="_blank">
        <input style="margin-left:10px;" name="daochuwsy" type='submit' value="导出未使用" class="am-btn am-btn-primary">
    </form>
	
</div>

</table>

<p> 


<table>

		<div class="am-u-sm-centered" >
								<input type='hidden' name='uptype' value='' id="uptype">&nbsp; <a onclick="delsubmit('del')" class="am-badge am-badge-danger am-round">选中删除</a>
		</div>

</table>




						<div class="header">
							<div class="am-u-sm-12">

								<form action="" method="post" name="form_log" id="form_log">
									<div class="am-scrollable-horizontal">
										<table width="100%" id="adm_log_list" class="am-table am-table-hover table-main am-text-nowrap">
											<thead>
												<tr>
												
													<th class="table-check">
														<input type="checkbox" onclick="checkAll();" class="ids" id="all"></input>
													</th>
												
												
													
													<th>账号</th>
													<th>密码</th>
													<th>状态</th>
												</tr>
											</thead>
											<tbody>
												<?php

												$sql="select * from $user order by id desc limit $bnums,$enums";
												
												$query=$db->query($sql);
												while($rows=$db->fetch_array($query)){
												?>
												<tr>
												
												<td>
														<input type="checkbox" name="id[]" value="<?php echo $rows['id']; ?>" class="ids"></input>
													</td>
												
												
													<td><?php echo $rows['username']; ?></td>
													<td><?php echo $rows['password']; ?></td>
													
													<td><?php if($rows['status']=='0'):?><font color=green>未使用
														<?php elseif($rows['status']=='1'):?><font color=Blue>已使用
													    <?php else: ?><font color=red>异常<?php endif; ?></font></td>
												</tr>
												<?php
												}
												?>
											</tbody>
										</table>
									</div>
									
					
										

							<?php if($username == ''): ?>
							<div class="page" style="text-align:center;"><?php echo pagination($nums,$enums,$page,$url); ?></div>
							<?php endif; ?>
							
						</div>
					</div>
				</div>
			</div>
	

<script src="../admin/layer/jquery.min.js"></script>
<script src="../admin/layer/layer.js"></script>

<script>
function checkAll() {
	var code_Values = document.getElementsByTagName("input");
	var all = document.getElementById("all");
	if (code_Values.length) {
		for (i = 0; i < code_Values.length; i++) {
			if (code_Values[i].type == "checkbox") {
				code_Values[i].checked = all.checked;
			}
		}
	} else {
		if (code_Values.type == "checkbox") {
			code_Values.checked = all.checked;
		}
	}
}
function delsubmit(){
	var delform = document.getElementById("form_log");
	delform.submit();
}
</script>
			
<script>
function delall() {
//console.log($("#btndelete").val());
if (!confirm('确认要删除所有吗？')) {
return false;
}
else {
$("#scsy").prop("type","submit");
}
}
function del() {
//console.log($("#btndelete").val());
if (!confirm('确认要删除已使用吗？')) {
return false;
}
else {
$("#scysy").prop("type","submit");
}
}
</script>	


			
<script src="../admin/assets/js/jquery.min.js"></script>
<script src="../admin/assets/js/amazeui.min.js"></script>
<script src="../admin/assets/js/iscroll.js"></script>
<script src="../admin/assets/js/app.js"></script>
</body>
</html>