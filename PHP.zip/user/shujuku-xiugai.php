<?php

require_once '../include/global.php';
$link = mysqli_connect($host,$mysql_user,$mysql_pwd,$db_name );

$user = isset($_GET['user']) ? addslashes(trim($_GET['user'])) : '';

$query = "SELECT * FROM miyao WHERE username = '$user' ";
$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASSWD, DB_NAME);
$result = mysqli_query($connection, $query);

if (mysqli_num_rows($result) == 1) {
  $row = mysqli_fetch_assoc($result);
  $quanxian = $row['quanxian'] ;
} else {
  echo "<script>alert('登陆失败!');location.href='".$_SERVER["HTTP_REFERER"]."';</script>"; 
  
}



mysqli_set_charset($link, 'utf8');


//获取id
$id = $_GET['id'];
//编写查询sql语句
$sql = "SELECT * FROM `student` WHERE `id`=$id";
//执行查询操作、处理结果集
$result = mysqli_query($link, $sql);
if (!$result) {
    exit('查询sql语句执行失败。错误信息：'.mysqli_error($link));  // 获取错误信息
}
$data = mysqli_fetch_all($result, MYSQLI_ASSOC);

//将二维数数组转化为一维数组
foreach ($data as $key => $value) {
  foreach ($value as $k => $v) {
    $arr[$k]=$v;
  }
}

?>


<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		
		<meta name="description" content="index">
		<meta name="keywords" content="index">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="renderer" content="webkit">
		<meta http-equiv="Cache-Control" content="no-siteapp" />
		<link rel="icon" type="image/png" href="../admin/assets/img/favicon.ico">
		<link rel="apple-touch-icon-precomposed" href="../admin/assets/img/favicon.ico">
		<meta name="apple-mobile-web-app-title" content="Amaze UI" />
		<link rel="stylesheet" href="../admin/assets/css/amazeui.min.css" />
		<link rel="stylesheet" href="../admin/assets/css/admin.css">
		<link rel="stylesheet" href="../admin/assets/css/app.css">
		<link rel="stylesheet" href="../admin/assets/css/font-awesome.min.css">
		<script src="../admin/assets/js/echarts.min.js"></script>
        <style type="text/css"> 
          i.fa {
            width: 2rem;
            font-size: 2rem;
            text-align: center;
          }
/* 设置输入框宽度 */
.tpl-form-input {
    width: 100%;
    max-width: 800px;
}

/* 设置输入框高度 */
.tpl-form-textarea {
    height: 150px !important;
}


/* 设置输入框可以换行 */
.tpl-form-textarea {
    white-space: pre-wrap;
}
        </style>
	</head>
	
		<meta charset="UTF-8">
<title>数据修改</title>


			<div class="tpl-portlet-components">
				

<div class="am-g">


	<body>
	
	
		<!--输出定制表单-->
				<form class="am-form tpl-form-line-form am-text-nowrap" action="shujuku-xiugai-chuli.php?user=<?php echo $user ?>" method="post" enctype="multipart/form-data">
					<table border="1">

<div class="am-form-group" style="display:flex;justify-content: flex-start;">
						<label for="num" id="num_label" class="am-form-label">数据ID：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="id" readonly="readonly" value="<?php echo $arr["id"] ?>" style="max-width:100px;flex:1;">
								</div>
</div>

<div class="am-form-group" style="display:flex;justify-content: flex-start;">
						<label for="num" id="num_label" class="am-form-label">配置名称 ：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="name" readonly="readonly" value="<?php echo $arr["name"] ?>" style="max-width:100px;flex:1;">
								</div>
</div>			
					
<div class="am-form-group" style="display:flex;justify-content: flex-start;">
						<label for="num" id="num_label" class="am-form-label">数据1：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="dt1" value="<?php echo $arr["dt1"] ?>" style="max-width:200px;flex:1;">
								</div>
</div>

<div class="am-form-group" style="display:flex;justify-content: flex-start;">
						<label for="num" id="num_label" class="am-form-label">数据2：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="dt2" value="<?php echo $arr["dt2"] ?>" style="max-width:200px;flex:1;">
								</div>
</div>								
								
<div class="am-form-group" style="display:flex;justify-content: flex-start;">
						<label for="num" id="num_label" class="am-form-label">数据3：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="dt3" value="<?php echo $arr["dt3"] ?>" style="max-width:200px;flex:1;">
								</div>
</div>	

<div class="am-form-group" style="display:flex;justify-content: flex-start;">
						<label for="num" id="num_label" class="am-form-label">数据4：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="dt4" value="<?php echo $arr["dt4"] ?>" style="max-width:200px;flex:1;">
								</div>
</div>	
					
<div class="am-form-group" style="display:flex;justify-content: flex-start;">
						<label for="num" id="num_label" class="am-form-label">数据5：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="dt5" value="<?php echo $arr["dt5"] ?>" style="max-width:200px;flex:1;">
								</div>
</div>

<div class="am-form-group" style="display:flex;justify-content: flex-start;">
						<label for="num" id="num_label" class="am-form-label">数据6：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="dt6" value="<?php echo $arr["dt6"] ?>" style="max-width:200px;flex:1;">
								</div>
</div>

<div class="am-form-group" style="display:flex;justify-content: flex-start;">
						<label for="num" id="num_label" class="am-form-label">数据7：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="dt7" value="<?php echo $arr["dt7"] ?>"style="max-width:200px;flex:1;">
								</div>
</div>

<div class="am-form-group" style="display:flex;justify-content: flex-start;">
						<label for="num" id="num_label" class="am-form-label">数据8：</label>
							<div class="" style="flex:1;">
									<input type="text" class="tpl-form-input" name="dt8" value="<?php echo $arr["dt8"] ?>"style="max-width:200px;flex:1;">
								</div>
</div>



<div class="am-form-group" style="display:flex;justify-content: flex-start;">
	<label for="num" id="num_label" class="am-form-label">数据9 ：</label>
	<div class="" style="flex:1;">
		
		<select style="max-width:150px;flex:1" name="dt9" data-am-selected="{searchBox: 0}" >
			<option value="<?php echo $arr['dt9'];?>">当前选择：<?php echo $arr['dt9'];?></option>
			<option value="是">是</option>
			<option value="否">否</option>
		</select>
		
	</div>
</div>					





<div class="am-form-group" style="display:flex;justify-content: flex-start;">
    <label for="num" id="num_label" class="am-form-label">数据10：</label>
    <div class="" style="flex:1;">
        <textarea class="tpl-form-input tpl-form-textarea" name="dt10"><?php echo $arr['dt10'];?></textarea>
    </div>
</div>



						
							<div class="am-form-group" style="display:flex;justify-content: center;" id="post_button">
								<input   class="am-btn am-btn-primary" type="submit" value="提交修改">
							</div>
						

						
						
						
						
						
					</table>
				</form>
			</div>
		</div>
	</body>
</html>







<script src="../../admin/../admin/assets/js/jquery.min.js"></script>
<script src="../../admin/../admin/assets/js/amazeui.min.js"></script>
<script src="../../admin/../admin/assets/js/iscroll.js"></script>
<script src="../../admin/../admin/assets/js/app.js"></script>
</body>
</html>