<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		
		<meta name="description" content="index">
		<meta name="keywords" content="index">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="renderer" content="webkit">
		<meta http-equiv="Cache-Control" content="no-siteapp" />

		<meta name="apple-mobile-web-app-title" content="Amaze UI" />
		<link rel="stylesheet" href="../admin/assets/css/amazeui.min.css" />
		<link rel="stylesheet" href="../admin/assets/css/admin.css">
		<link rel="stylesheet" href="../admin/assets/css/app.css">
		<link rel="stylesheet" href="../admin/assets/css/font-awesome.min.css">
		<script src="../admin/assets/js/echarts.min.js"></script>
        <style type="text/css"> 
				.parent {
					height: 200px;
					margin: auto;
					position:absolute;
					left:0;
					top: 0;
					bottom: 0;
					right: 0;	
						}


        </style>
	</head>

<title>用户登陆</title>

<div class="parent">

						<div class="am-g">
								<form action="kongzhi.php" method="get" name="suer" id="suer">
									<div class="am-u-sm-centered" style="display:flex;justify-content: center;">
									<input type="text" class="am-form-field" name="user" placeholder="             请输入用户密钥" style="max-width:200px;flex:1;background-color:white;"></input>
									</div>
									
									<p>
									<div class="am-u-sm-centered" style="display:flex;justify-content: center;">
									<input class="am-btn am-btn-primary" value="登陆" type="submit"></input>
									</div>
								</form>	
						</div>

</div>


