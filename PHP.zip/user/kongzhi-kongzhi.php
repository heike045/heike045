<?php

require_once '../admin/globals.php';


$username = $_GET["username"]; //设备名

$id = $_GET["id"]; //ID

$mingling = $_GET["mingling"]; //命令

$str = $_GET["str"]; 



if($mingling=='运行'){
	$sql="UPDATE `kongzhi` set mingling='运行' WHERE id={$id}";
	$db->query($sql);
}

if($mingling=='停止'){
	$sql="UPDATE `kongzhi` set mingling='停止' WHERE id={$id}";
	$db->query($sql);
}

if($mingling=='暂停'){
	$sql="UPDATE `kongzhi` set mingling='暂停' WHERE id={$id}";
	$db->query($sql);
}

if($mingling=='恢复'){
	$sql="UPDATE `kongzhi` set mingling='恢复' WHERE id={$id}";
	$db->query($sql);
}

if($mingling=='开启监控'){
	$sql="UPDATE `kongzhi` set mingling='开启监控' WHERE id={$id}";
	$db->query($sql);
}

if($mingling=='停止监控'){
	$sql="UPDATE `kongzhi` set mingling='停止监控' WHERE id={$id}";
	$db->query($sql);
}

if($mingling=='点击菜单按键'){
	$sql="UPDATE `kongzhi` set mingling2='点击菜单按键' WHERE id={$id}";
	$db->query($sql);
}

if($mingling=='点击桌面按键'){
	$sql="UPDATE `kongzhi` set mingling2='点击桌面按键' WHERE id={$id}";
	$db->query($sql);
}

if($mingling=='点击后退按键'){
	$sql="UPDATE `kongzhi` set mingling2='点击后退按键' WHERE id={$id}";
	$db->query($sql);
}

if($mingling=='执行点击命令'){
	$sql="UPDATE `kongzhi` set tapmingling='{$str}' WHERE id={$id}";
	$db->query($sql);

	$sql="UPDATE `kongzhi` set mingling2='执行点击命令' WHERE id={$id}";
	$db->query($sql);
}

if($mingling=='输入内容'){
	$sql="UPDATE `kongzhi` set tapmingling='{$str}' WHERE id={$id}";
	$db->query($sql);

	$sql="UPDATE `kongzhi` set mingling2='输入内容' WHERE id={$id}";
	$db->query($sql);
}


echo '<script>window.close();</script>';  //关闭当前界面

?>



