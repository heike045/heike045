<?php
require_once '../include/global.php';
$link = mysqli_connect($host,$mysql_user,$mysql_pwd,$db_name );

$user = isset($_GET['user']) ? addslashes(trim($_GET['user'])) : '';

$query = "SELECT * FROM miyao WHERE username = '$user' ";
$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASSWD, DB_NAME);
$result = mysqli_query($connection, $query);

if (mysqli_num_rows($result) == 1) {
  $row = mysqli_fetch_assoc($result);
  $quanxian = $row['quanxian'] ;
} else {
  echo "<script>alert('登陆失败!');location.href='".$_SERVER["HTTP_REFERER"]."';</script>"; 
  
}

$id = $_GET['id'];

$sql = "DELETE FROM student WHERE id={$id}";
//执行查询操作、处理结果集
$result = mysqli_query($link, $sql);
if (!$result) {
    exit('sql语句执行失败。错误信息：'.mysqli_error($link));  // 获取错误信息
}

echo "<script>alert('删除成功！');location.href='".$_SERVER["HTTP_REFERER"]."';</script>"; 


?>