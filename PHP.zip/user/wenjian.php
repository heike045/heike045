<?php  
  
require_once '../include/global.php';


$user = isset($_GET['user']) ? addslashes(trim($_GET['user'])) : '';

$query = "SELECT * FROM miyao WHERE username = '$user' ";
$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASSWD, DB_NAME);
$result = mysqli_query($connection, $query);

if (mysqli_num_rows($result) == 1) {
  $row = mysqli_fetch_assoc($result);
  $quanxian = $row['quanxian'] ;
} else {
  echo "<script>alert('登陆失败!');location.href='".$_SERVER["HTTP_REFERER"]."';</script>"; 
  
}



$fenzu = $user ;

 
$lujing = "../admin/wenjian/" . $fenzu ;
 
if(isset($_FILES['files'])){  
    $res =  upload_multiple_file($_FILES['files'],$lujing);    //上传路径
    echo $res;  
    }  


function upload_multiple_file($file,$lujing) {  
  
    $overwrite=0;  
    $allowed_file_type= array("lr", "apk", "txt");    //上传类型
    $max_file_size = 62914560;      //限制上传大小60M   //1048576 = 1MB
  
     foreach($_FILES['files']['name'] as $fkey=> $fname){  
        
         $ext = pathinfo($fname, PATHINFO_EXTENSION);  
           if (!in_array($ext, $allowed_file_type)) {  
             
                return "不支持此文件类型上传";  
			    //echo "<script> alert('不支持此文件类型上传'); </script>";
                break;  
           }  
        
       
     }  
  
    foreach($_FILES['files']['tmp_name'] as $key => $tmp_name ){  
          
                  
        $file_name = $_FILES['files']['name'][$key];  
          
          
        $file_size =$_FILES['files']['size'][$key];  
          
          
        $file_tmp_name =$_FILES['files']['tmp_name'][$key];  
          
          
        $file_type=$_FILES['files']['type'][$key];  
  
          
        if($file_size >0) {  
            if($file_size > $max_file_size){  
              
                $fsize=$max_file_size/1048576;    //1048576 = 1MB
                return  '文件大小必须小于： '.$fsize.' MB';  
				//echo "<script> alert('超过限制文件大小');</script>";
                break;  
            
            }  
        }  
          
       
        if(is_dir($lujing)==false){  
              
              $status =  mkdir("$lujing", 0700);    
                 
               if($status < 1){  
                       
                     return "无法创建目录： $lujing ";  
					 //echo "<script> alert('无法创建目录');</script>";
                       
                }                
              
        }  
              
        if(is_dir($lujing)){  
              
            if($overwrite < 1){  
                
                move_uploaded_file($file_tmp_name,"$lujing/".$file_name);  
               
            }  
               
        }  
             
        //  $file_upload_query="INSERT into user_uploads (`u_id`,`file_name`,`file_type`) VALUES('$user_id','$file_name','$file_size','$file_type'); ";  
        //mysql_query($file_upload_query);        
          
      
   }  
      
		echo "<script> alert('文件上传成功');</script>";
      
}  
  
?>  

<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		
		<meta name="description" content="index">
		<meta name="keywords" content="index">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="renderer" content="webkit">
		<meta http-equiv="Cache-Control" content="no-siteapp" />
		<link rel="icon" type="image/png" href="../admin/assets/img/favicon.ico">
		<link rel="apple-touch-icon-precomposed" href="../admin/assets/img/favicon.ico">
		<meta name="apple-mobile-web-app-title" content="Amaze UI" />
		<link rel="stylesheet" href="../admin/assets/css/amazeui.min.css" />
		<link rel="stylesheet" href="../admin/assets/css/admin.css">
		<link rel="stylesheet" href="../admin/assets/css/app.css">
		<link rel="stylesheet" href="../admin/assets/css/font-awesome.min.css">
		<script src="../admin/assets/js/echarts.min.js"></script>
        <style type="text/css"> 
          i.fa {
            width: 2rem;
            font-size: 2rem;
            text-align: center;
          }
        </style>
	</head>



<title>文件管理</title>

<div class="tpl-portlet-components">
			<div class="tpl-portlet-components">
			
	<style>
		.button {
			display: inline-block;
			padding: 10px 20px;
			font-size: 16px;
			border-radius: 5px;
			background-color: #3BB4F2;
			color: white;
			text-align: center;
			text-decoration: none;
			margin: 10px;
			transition: all 0.3s ease 0s;
			cursor: pointer;
		}

		.button:hover {
			background-color: #3BB4F2;
		}

		.caption {
			font-size: 24px;
			padding: 10px;
			margin-bottom: 20px;
			text-align: center;
		}

		.font-green {
			color: green;
		}

		.bold {
			font-weight: bold;
		}
	</style>


	<div class="portlet-title caption font-green bold" style="height: 80px;">
					  <a class="button" href='kongzhi.php?user=<?php $user = isset($_GET['user']) ? addslashes(trim($_GET['user'])) : ''; echo $user; ?>'  >设备控制</a>
					 
					  <a class="button" href='shujuku.php?user=<?php $user = isset($_GET['user']) ? addslashes(trim($_GET['user'])) : ''; echo $user; ?>' >数据管理</a>
					 
					  <a class="button" href='zhanghao.php?user=<?php $user = isset($_GET['user']) ? addslashes(trim($_GET['user'])) : ''; echo $user; ?>' >账号管理</a>
					  
					  <a class="button" href='tuku.php?user=<?php $user = isset($_GET['user']) ? addslashes(trim($_GET['user'])) : ''; echo $user; ?>' >图库管理</a>
					  
					  <a class="button" href='wenjian.php?user=<?php $user = isset($_GET['user']) ? addslashes(trim($_GET['user'])) : ''; echo $user; ?>' >文件管理</a>
	</div>
	<p>
					
					<p>
					
			
<div class="tpl-block">
<div class="am-g">




    <form action="" method="POST" enctype="multipart/form-data">
<div class="am-u-sm-centered" style="display:flex;justify-content: center;">
		<input name='files[]' type='file' multiple style="display:block;max-width:250px;flex:1;">
		<input value='上传' type='submit' style="display:block;" class="am-btn am-btn-primary" >
</div>
    </form>


<p>   



<form class="am-form tpl-form-line-form am-text-nowrap" action="wenjian-del.php?user=<?php echo $fenzu; ?>" method="post" id="addimg" name="addimg">
										<div class="am-form-group" id="post_button">
											<div class="am-u-sm-centered" style="display:flex;justify-content: center;">
						
						
						
											</div>
										</div>
</form>



<div class="header">
							<div class="am-u-sm-12">

									<div class="am-scrollable-horizontal">
										<table width="100%" id="adm_log_list" class="am-table am-table-hover table-main am-text-nowrap">
											<thead>
												<tr>
													<th>文件名</th>
													<th>操作</th>
												</tr>
											</thead>
											
<tbody>
											
<?php
$hostdir='../admin/wenjian/'.$fenzu; //要读取的文件夹

$url = '../admin/wenjian/'.$fenzu; //图片所存在的目录

$filesnames = scandir($hostdir); //得到所有的文件

// print_r($filesnames);exit;
//获取也就是扫描文件夹内的文件及文件夹名存入数组 $filesnames

foreach ($filesnames as $name) {
	    if($name === '.' || $name === '..'){
       continue;
    }										
?>			
											
												<tr>
												
<td>
<?php

            echo "<li><div><a target='_blank' href='../admin/wenjian/".$fenzu."/".$name."'>".$name." </a>";
			
?>
</td>	
			
<td>
<?php
	echo '<a href="wenjian-zdsc.php?wjm='.$name.'&user='.$fenzu.'">删除</a></div></h3></li>';
}
?>
</td>
												</tr>
												
</tbody>
										</table>
									</div>
									
							

						
							
						</div>
					</div>





	






						</div>
						</div>

			


   
<script>
function delall() {
//console.log($("#btndelete").val());
if (!confirm('确认要清空文件吗？')) {
return false;
}
else {
$("#button").prop("type","submit");
}
}
</script>	


<script src="../admin/assets/js/jquery.min.js"></script>
<script src="../admin/assets/js/amazeui.min.js"></script>
<script src="../admin/assets/js/iscroll.js"></script>
<script src="../admin/assets/js/app.js"></script>
</body>
</html>