<?php

require_once '../include/global.php';
$link = mysqli_connect($host,$mysql_user,$mysql_pwd,$db_name );

$user = isset($_GET['user']) ? addslashes(trim($_GET['user'])) : '';

$query = "SELECT * FROM miyao WHERE username = '$user' ";
$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASSWD, DB_NAME);
$result = mysqli_query($connection, $query);

if (mysqli_num_rows($result) == 1) {
  $row = mysqli_fetch_assoc($result);
  $quanxian = $row['quanxian'] ;
} else {
  echo "<script>alert('登陆失败!');location.href='".$_SERVER["HTTP_REFERER"]."';</script>"; 
  
}


mysqli_set_charset($link, 'utf8');


$name = $_POST['name'];
$fenzu = $_POST['fenzu'];
$dt1 = $_POST['dt1'];
$dt2 = $_POST['dt2'];
$dt3 = $_POST['dt3'];
$dt4 = $_POST['dt4'];
$dt5 = $_POST['dt5'];
$dt6 = $_POST['dt6'];
$dt7 = $_POST['dt7'];
$dt8 = $_POST['dt8'];
$dt9 = $_POST['dt9'];
$dt10 = $_POST['dt10'];


	//编写预处理sql语句
	$sql = "INSERT INTO `student` VALUES(NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	//预处理SQL模板
	$stmt = mysqli_prepare($link, $sql);
	// 参数绑定，并为已经绑定的变量赋值
	mysqli_stmt_bind_param($stmt, 'ssssssssssss', $name, $fenzu, $dt1, $dt2, $dt3, $dt4, $dt5, $dt6, $dt7, $dt8, $dt9, $dt10);
	

	if ($name) {
		// 执行预处理（第1次执行）
		$result = mysqli_stmt_execute($stmt);
	
	
	if ($result) {
    echo "<script>alert('添加成功！');location.href='".$_SERVER["HTTP_REFERER"]."';</script>"; 
} else {
    if(mysqli_errno($link) == 1062){
        echo "<script>alert('添加失败！已经存在相同的名称！');location.href='".$_SERVER["HTTP_REFERER"]."';</script>";
    }else{
        exit('添加数据sql语句执行失败。错误信息：' . mysqli_error($link));
    }
}

	}



	//关闭连接
		mysqli_close($link);

  ?>

