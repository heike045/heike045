<?php

require_once '../include/global.php';
include '../include/zhconfig.php';
include '../include/config.php';


$user = isset($_GET['user']) ? addslashes(trim($_GET['user'])) : '';
$fenzu = $user ;
$query = "SELECT * FROM miyao WHERE username = '$user' ";
$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASSWD, DB_NAME);
$result = mysqli_query($connection, $query);

if (mysqli_num_rows($result) == 1) {
  $row = mysqli_fetch_assoc($result);
  $quanxian = $row['quanxian'] ;
} else {
  echo "<script>alert('登陆失败!');location.href='".$_SERVER["HTTP_REFERER"]."';</script>"; 
  
}


if(!$conn) die("error : mysql connect failed");


if($_GET['action'] == 'deleteAll'){
    $sth = $conn->prepare("delete from $fenzu ");
    $result= $sth->execute();
	echo "<script>alert('删除所有数据成功!');location.href='".$_SERVER["HTTP_REFERER"]."';</script>"; 
}

if($_GET['action'] == 'deleysy'){
    $sth = $conn->prepare("delete from $fenzu where status = 1");
    $result= $sth->execute();
	echo "<script>alert('删除已使用数据成功!');location.href='".$_SERVER["HTTP_REFERER"]."';</script>"; 
}



if(is_uploaded_file($_FILES['myfile']['tmp_name'])) {
    //有了上传文件了
    $myfile=$_FILES["myfile"];
    //设置超时限制时间,缺省时间为 30秒,设置为0时为不限时
    $time_limit=60;
    set_time_limit($time_limit); //
    //把文件内容读到字符串中
    $fp=fopen($myfile['tmp_name'], "rb");
    if(!$fp) die("file open error");



    //输出文本中所有的行，直到文件结束为止。
    while(! feof($fp))
    {
        $a  = fgets($fp);//fgets()函数从文件指针中读取一行
		
	// 添加判断，如果行为空白行，则跳过
    if (empty($a)) {
        continue;
    }
		
		
        $tmpArr = explode('----',$a);
        if(empty($tmpArr[0]) || empty($tmpArr[1])){
            continue;
        }
		$tmpa = $tmpArr[0];
		$tmpb = $tmpArr[1];
        $sth = $conn->prepare("insert into $fenzu 
    (`username`,`password`) 
    values ('$tmpa','$tmpb')");

        $result= $sth->execute();
    }



	echo "<script>alert('上传成功!');location.href='".$_SERVER["HTTP_REFERER"]."';</script>"; 
}
else {
	echo "<script>alert('你没有上传任何文件!');location.href='".$_SERVER["HTTP_REFERER"]."';</script>"; 
}
?>

