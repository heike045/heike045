<?php


$fenzu = isset($_GET['fenzu']) ? addslashes(trim($_GET['fenzu'])) : '';

// 连接数据库
include '../../../include/config.php';
$conn = mysqli_connect($host,$mysql_user,$mysql_pwd,$db_name);

$sql = "SELECT username FROM miyao WHERE quanxian='$fenzu' ";
$result = mysqli_query($conn, $sql);

// 处理结果集
if (mysqli_num_rows($result) > 0) {
    // 输出数据
    while($row = mysqli_fetch_assoc($result)) {
        $fenzu2 = $row["username"];
    }
} 


//获取外网IP
$file = file_get_contents('http://ip6.me/');
$pos = strpos( $file, '+3' ) + 3;
$ip = substr( $file, $pos, strlen( $file ) );
$pos = strpos( $ip, '</' );
$ip = substr( $ip, 0, $pos );
//获取外网IP



$dir = "../../../admin/upload/".$fenzu2;

foreach (glob('../../../admin/upload/'.$fenzu2.'/*.jpg') as $txt){

    $dqmz = basename($txt);   //读取文件名字

    $array=array('.jpg'=>'');   //替换.jpg成空白1

    $qchz=strtr($dqmz,$array); //替换.jpg成空白2

    echo $qchz."----http://$ip/admin/upload/".$fenzu2."/".$qchz.".png";

    $file = $dir.$dqmz;	

    if(file_exists($file)){
         if(rename($file, $dir."/".$qchz.'.png')){
            // echo $file.' 重命名成功！';
        } else{
            // echo $file.' 重命名失败！';
        }
    } else{
        // echo '不存在！';
    }

    break;   //退出foreach循环

}



?>