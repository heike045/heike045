<?php

$fenzu = isset($_GET['fenzu']) ? addslashes(trim($_GET['fenzu'])) : '';


// 连接数据库
include '../../../include/config.php';
$conn = mysqli_connect($host,$mysql_user,$mysql_pwd,$db_name);

$sql = "SELECT username FROM miyao WHERE quanxian='$fenzu' ";
$result = mysqli_query($conn, $sql);

// 处理结果集
if (mysqli_num_rows($result) > 0) {
    // 输出数据
    while($row = mysqli_fetch_assoc($result)) {
        $fenzu2 = $row["username"];
    }
} 



$temp = explode(".", $_FILES["file"]["name"]);
$extension = end($temp);     // 获取文件后缀名
//echo "\n上传文件名: " . $_FILES["file"]["name"] . "\n";
//echo "文件类型: " . $_FILES["file"]["type"] . "\n";
//echo "文件大小: " . ($_FILES["file"]["size"] / 1024) . " kB\n";
//echo "后缀: ". $extension."\n";
if ( $extension == "png"||$extension == "jpg")   //只获取后缀png或者bmp的文件
{
    if ($_FILES["file"]["error"] > 0)
    {
        echo "错误：: " . $_FILES["file"]["error"] . "\n";
    }
    else
    {
      
        if (!unlink("../../../admin/upload/".$fenzu2."/".$_FILES["file"]["name"]))
          {
          //echo ("Error deleting\n");
          }
        else
          {
          //echo ("Deleted\n");
          }
        
       // echo "文件临时存储的位置: " . $_FILES["file"]["tmp_name"] . "\n";
        
        // 判断当前目录下的 upload 目录是否存在该文件
        // 如果没有 upload 目录，你需要创建它，upload 目录权限为 777
        if (file_exists("../../../admin/upload/" .$fenzu2."/" . $_FILES["file"]["name"]))
        {
            echo $_FILES["file"]["name"] . " 文件已经存在。 ";
        }
        else
        {
            // 如果 upload 目录不存在该文件则将文件上传到 upload 目录下
           if( move_uploaded_file($_FILES["file"]["tmp_name"], "../../../admin/upload/" .$fenzu2."/" . $_FILES["file"]["name"]))
           {
               echo "上传成功";
           }
          //  echo "文件存储在: " . "upload/" . $_FILES["file"]["name"];
        }
    }
}
else
{
    echo "非法的文件格式";
}

?>