<?php

$fenzu = isset($_GET['fenzu']) ? addslashes(trim($_GET['fenzu'])) : '';

// 连接数据库
include '../../../include/config.php';
$conn = mysqli_connect($host,$mysql_user,$mysql_pwd,$db_name);

$sql = "SELECT username FROM miyao WHERE quanxian='$fenzu' ";
$result = mysqli_query($conn, $sql);

// 处理结果集
if (mysqli_num_rows($result) > 0) {
    // 输出数据
    while($row = mysqli_fetch_assoc($result)) {
        $fenzu2 = $row["username"];
    }
} 

?>


<?php

    $name = $_GET["name"]; //用户名

	include '../../../include/config.php';

    //连接数据库
    $connect = mysqli_connect($host, $mysql_user, $mysql_pwd, $db_name, $db_port);
    if (!$connect) {
        die("连接数据库失败: " . mysqli_connect_error());
    }
	$sql = "select * from student where name='{$name}' and fenzu='$fenzu2' ";

	$result=mysqli_query($connect,$sql);
    $rows=mysqli_fetch_array($result);
	if(!empty($rows)){
		echo "{$rows['dt1']}----{$rows['dt2']}----{$rows['dt3']}----{$rows['dt4']}----{$rows['dt5']}----{$rows['dt6']}----{$rows['dt7']}----{$rows['dt8']}----{$rows['dt9']}----{$rows['dt10']}";    //获取name后返回name底下的值内容

	}
	
	mysqli_close($connect);
?>
