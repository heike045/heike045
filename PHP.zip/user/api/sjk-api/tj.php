<?php

$fenzu = isset($_GET['fenzu']) ? addslashes(trim($_GET['fenzu'])) : '';


// 连接数据库
include '../../../include/config.php';
$conn = mysqli_connect($host,$mysql_user,$mysql_pwd,$db_name);

$sql = "SELECT username FROM miyao WHERE quanxian='$fenzu' ";
$result = mysqli_query($conn, $sql);

// 处理结果集
if (mysqli_num_rows($result) > 0) {
    // 输出数据
    while($row = mysqli_fetch_assoc($result)) {
        $fenzu2 = $row["username"];
    }
} 

// 关闭数据库连接
mysqli_close($conn);

?>


<?php
    $name = $_GET["name"]; 
    $dt1 = $_GET["dt1"]; 
    $dt2 = $_GET["dt2"];
    $dt3 = $_GET["dt3"];
    $dt4 = $_GET["dt4"];
    $dt5 = $_GET["dt5"];
    $dt6 = $_GET["dt6"];
    $dt7 = $_GET["dt7"];
    $dt8 = $_GET["dt8"];
    $dt9 = $_GET["dt9"];
    $dt10 = $_GET["dt10"];

    include '../../../include/config.php';

    $connect = mysqli_connect($host, $mysql_user, $mysql_pwd, $db_name, $db_port);
    if (!$connect) {
        die("连接数据库失败: " . mysqli_connect_error());
    }

    $sql = "select * from student where name='{$name}' and fenzu='{$fenzu2}' ";

    $res = $connect->query($sql)->fetch_row();
    if (empty($res)) {
        //数据库没有该值，插入数据库
        $upsql = "insert into student (name,fenzu,dt1,dt2,dt3,dt4,dt5,dt6,dt7,dt8,dt9,dt10) values ('{$name}','{$fenzu2}','{$dt1}','{$dt2}','{$dt3}','{$dt4}','{$dt5}','{$dt6}','{$dt7}','{$dt8}','{$dt9}','{$dt10}')"; 
        echo "提交完成";
    } else {
        //如来有数据，更新status的值
        $upsql = "update student set name='{$name}' , fenzu='{$fenzu2}' , dt1='{$dt1}' , dt2='{$dt2}' , dt3='{$dt3}', dt4='{$dt4}', dt5='{$dt5}', dt6='{$dt6}', dt7='{$dt7}', dt8='{$dt8}', dt9='{$dt9}', dt10='{$dt10}' where name='{$name}' and fenzu='{$fenzu2}'  ";
        echo "修改完成";
    }
    
    $update_res = $connect->query($upsql);

    mysqli_close($connect);
?>
