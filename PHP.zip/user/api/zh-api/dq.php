<?php

$fenzu = isset($_GET['fenzu']) ? addslashes(trim($_GET['fenzu'])) : '';
$username = $_GET["username"]; //用户名


// 连接数据库
include '../../../include/config.php';
$conn = mysqli_connect($host,$mysql_user,$mysql_pwd,$db_name);

$sql = "SELECT username FROM miyao WHERE quanxian='$fenzu' ";
$result = mysqli_query($conn, $sql);

// 处理结果集
if (mysqli_num_rows($result) > 0) {
    // 输出数据
    while($row = mysqli_fetch_assoc($result)) {
        $fenzu2 = $row["username"];
    }
} 




// 锁表
$sql = "lock table $fenzu2 write";  
$result = mysqli_query($conn, $sql);

// 查询数据库
$sql = "select * from $fenzu2 where username='{$username}'";
$result = mysqli_query($conn, $sql);

// 读取一条记录
$row = mysqli_fetch_assoc($result);

if(empty($row)){
	 echo "无此账号";
}else{
	// 显示记录
	echo "密码：" , "{$row['password']}";    //获取username后返回usernamedi底下的password值内容

	// 解锁表
	$sql = "UNLOCK table";
	$result = mysqli_query($conn, $sql);
}

// 关闭数据库连接
mysqli_close($conn);

?>