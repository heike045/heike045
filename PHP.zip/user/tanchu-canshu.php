<?php

require_once '../include/global.php';

$link = mysqli_connect($host,$mysql_user,$mysql_pwd,$db_name );

$user = isset($_GET['user']) ? addslashes(trim($_GET['user'])) : '';

$query = "SELECT * FROM miyao WHERE username = '$user' ";
$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASSWD, DB_NAME);
$result = mysqli_query($connection, $query);

if (mysqli_num_rows($result) == 1) {
  $row = mysqli_fetch_assoc($result);
  $quanxian = $row['quanxian'] ;
} else {
  echo "<script>alert('登陆失败!');location.href='".$_SERVER["HTTP_REFERER"]."';</script>"; 
}


$current_page = empty($_GET['page']) ? 0 : $_GET['page'];
$page         = $current_page;
if ($current_page != 0) {
    $page = $current_page + 4;
}



$query = "SELECT * FROM miyao";
$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASSWD, DB_NAME);
$result = mysqli_query($connection, $query);

// 遍历结果集
$found = false;
while ($row = mysqli_fetch_assoc($result)) {
  if ($row['username'] === $user) {
    $found = true;

    // 在找到用户时执行内部查询
    $inner_connection = mysqli_connect(DB_HOST, DB_USER, DB_PASSWD, DB_NAME);

	$sql = "SELECT * FROM `miyao` WHERE `username` = '$user' ORDER BY `id` DESC LIMIT 1";

    $inner_result = mysqli_query($inner_connection, $sql);
    if (!$inner_result) {
      exit('查询sql语句执行失败。错误信息：' . mysqli_error($inner_connection));  
    }
    $data = mysqli_fetch_array($inner_result, MYSQLI_ASSOC);
    if (empty($data)) {
      $data['canshu1'] = '';
      $data['canshu2'] = '';
      $data['canshu3'] = '';
	  $data['canshu4'] = '';
	  $data['canshu5'] = '';
	  $data['canshu6'] = '';
	  $data['canshu7'] = '';
	  $data['canshu8'] = '';
    }
    
    break;
  }
}



?>



<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		
		<meta name="description" content="index">
		<meta name="keywords" content="index">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="renderer" content="webkit">
		<meta http-equiv="Cache-Control" content="no-siteapp" />
		<link rel="icon" type="image/png" href="../admin/assets/img/favicon.ico">
		<link rel="apple-touch-icon-precomposed" href="../admin/assets/img/favicon.ico">
		<meta name="apple-mobile-web-app-title" content="Amaze UI" />
		<link rel="stylesheet" href="../admin/assets/css/amazeui.min.css" />
		<link rel="stylesheet" href="../admin/assets/css/admin.css">
		<link rel="stylesheet" href="../admin/assets/css/app.css">
		<link rel="stylesheet" href="../admin/assets/css/font-awesome.min.css">
		<script src="../admin/assets/js/echarts.min.js"></script>
        <style type="text/css"> 
          i.fa {
            width: 2rem;
            font-size: 2rem;
            text-align: center;
          }
/* 设置输入框宽度 */
.tpl-form-input {
    width: 100%;
    max-width: 800px;
}

/* 设置输入框高度 */
.tpl-form-textarea {
    height: 300px !important;
}


/* 设置输入框可以换行 */
.tpl-form-textarea {
    white-space: pre-wrap;
}

        </style>
	</head>




			<div class="tpl-content-wrapper">

				<div class="tpl-portlet">
					
					
				
						<div class="am-g">
							
								<form class="am-form tpl-form-line-form am-text-nowrap" action="canshu-sava.php?user=<?php echo $user;?>" method="post" id="addimg" name="addimg">
									<div id="post">
									
											<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="num" id="num_label" class="am-form-label">直播间ID ：</label>
											<div class="" style="flex:1;">
												<input type="text" class="tpl-form-input" name="f" value="<?php echo $data['canshu1'];?>" style="max-width:150px;flex:1">
											</div>
											
										</div>
									<!--	
										<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="num" id="num_label" class="am-form-label">发言间隔 ：</label>
											<div class="" style="flex:1;">
												<input type="text" class="tpl-form-input" name="g" value="<?php echo $data['canshu2'];?>" style="max-width:150px;flex:1">
											</div>
										</div>
									-->
										<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="num" id="num_label" class="am-form-label">发言轮数 ：</label>
											<div class="" style="flex:1;">
												<input type="text" class="tpl-form-input" name="h" value="<?php echo $data['canshu3'];?>" style="max-width:150px;flex:1">
											</div>
										</div>
									
											<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="num" id="num_label" class="am-form-label">心心点赞 ：</label>
											<div class="" style="flex:1;">
												<input type="text" class="tpl-form-input" name="k" value="<?php echo $data['canshu6'];?>" style="max-width:150px;flex:1">
											</div>
										</div>
									
									
										<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="num" id="num_label" class="am-form-label">是否间隔 ：</label>
											<div class="" style="flex:1;">
												
												<select style="max-width:150px;flex:1" name="i" data-am-selected="{searchBox: 0}" >
													<option value="<?php echo $data['canshu4'];?>">当前选择：<?php echo $data['canshu4'];?></option>
													<option value="是">是</option>
													<option value="否">否</option>
												</select>
												
											</div>
										</div>
										
									
									
										<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="num" id="num_label" class="am-form-label">是否关注 ：</label>
											<div class="" style="flex:1;">
												
												<select style="max-width:150px;flex:1" name="j" data-am-selected="{searchBox: 0}" >
													<option value="<?php echo $data['canshu5'];?>">当前选择：<?php echo $data['canshu5'];?></option>
													<option value="是">是</option>
													<option value="否">否</option>
												</select>
												
											</div>
										</div>
									
									
									
									
									
										<div class="am-form-group" style="display:flex;justify-content: flex-start;">
											<label for="num" id="num_label" class="am-form-label">是否心心 ：</label>
											<div class="" style="flex:1;">
												
												<select style="max-width:150px;flex:1" name="l" data-am-selected="{searchBox: 0}" >
													<option value="<?php echo $data['canshu7'];?>">当前选择：<?php echo $data['canshu7'];?></option>
													<option value="是">是</option>
													<option value="否">否</option>
												</select>
												
												
											</div>
										</div>
									

<div class="am-form-group" style="display:flex;justify-content: flex-start;">
    <label for="num" id="num_label" class="am-form-label">发言内容：</label>
    <div class="" style="flex:1;">
        <textarea class="tpl-form-input tpl-form-textarea" name="m"><?php echo $data['canshu8'];?></textarea>
    </div>
</div>

										

										
										<div class="am-form-group" style="display:flex;justify-content: flex-start;" id="post_button">
											<div class="am-u-sm-centered">
												<input type="submit" name="button" id="button" value="保存参数" class="am-btn am-btn-primary" style="display:block; margin:0 auto;"></input>
											</div>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>

</div>





<script src="../admin/assets/js/jquery.min.js"></script>
<script src="../admin/assets/js/amazeui.min.js"></script>
<script src="../admin/assets/js/iscroll.js"></script>
<script src="../admin/assets/js/app.js"></script>
</body>
</html>