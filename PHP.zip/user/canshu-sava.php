<?php

require_once '../include/global.php';
$link = mysqli_connect($host,$mysql_user,$mysql_pwd,$db_name );

$user = isset($_GET['user']) ? addslashes(trim($_GET['user'])) : '';

$query = "SELECT * FROM miyao WHERE username = '$user' ";
$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASSWD, DB_NAME);
$result = mysqli_query($connection, $query);

if (mysqli_num_rows($result) == 1) {
  $row = mysqli_fetch_assoc($result);
  $quanxian = $row['quanxian'] ;
} else {
  echo "<script>alert('登陆失败!');location.href='".$_SERVER["HTTP_REFERER"]."';</script>"; 
  
}


$f = $_POST['f'];
$g = $_POST['g'];
$h = $_POST['h'];
$i = $_POST['i'];
$j = $_POST['j'];
$k = $_POST['k'];
$l = $_POST['l'];
$m = $_POST['m'];
$n = $_POST['n'];
$o = $_POST['o'];


//编写预处理sql语句
$sql = "UPDATE miyao SET canshu1='$f', canshu2='$g', canshu3='$h', canshu4='$i', canshu5='$j', canshu6='$k', canshu7='$l', canshu8='$m' WHERE username='$user'";
$result = $link->query($sql);

// 关闭连接
mysqli_close($link);

if (!$result) {
    die('提交失败');
} else {
    echo "<script>alert('提交成功');location.href='".$_SERVER["HTTP_REFERER"]."';</script>"; 
}

?>
