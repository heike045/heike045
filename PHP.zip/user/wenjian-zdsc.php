<?php

require_once '../include/global.php';

$user = isset($_GET['user']) ? addslashes(trim($_GET['user'])) : '';

$query = "SELECT * FROM miyao WHERE username = '$user' ";
$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASSWD, DB_NAME);
$result = mysqli_query($connection, $query);

if (mysqli_num_rows($result) == 1) {
  $row = mysqli_fetch_assoc($result);
  $quanxian = $row['quanxian'] ;
} else {
  echo "<script>alert('登陆失败!');location.href='".$_SERVER["HTTP_REFERER"]."';</script>"; 
  
}


$wjm = $_GET["wjm"]; //设备名

$user = $_GET["user"]; //设备名

unlink ('../admin/wenjian/'.$user.'/'.$wjm);

echo "<script>alert('删除文件完成！');location.href='".$_SERVER["HTTP_REFERER"]."';</script>"; 


?>